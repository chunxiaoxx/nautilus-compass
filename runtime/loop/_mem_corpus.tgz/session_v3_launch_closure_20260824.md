---
name: v3-launch-closure-20260824
description: "V3.0 上线冲刺 C1-C3 全收口——pkl 卡死真根因(非原子写非\"不落盘\")/main ff 推送/云 repo 切 main 残留两个坑(stage1a 分叉线已备份,/opt daemon 分叉待统一)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-25T03:11:34.909Z
---

# V3.0 上线冲刺收口(2026-08-24 · 接 HANDOFF_20260824_V3_launch)

## 已完成(全部独立验证)

1. **pkl 补丁(第一件)**:真根因 ≠ 交接说的"缓存只在内存不落盘"——落盘存在,但**非原子写截断**(c096d6883da3.pkl 74MB "Ran out of input")+ **re-embed 中途被 kill 进度全丢**。修法:① `_pkl_write_atomic`(tmp+os.replace,3 处)② 每 `COMPASS_PKL_FLUSH_EVERY=50` 文件周期 flush。commit `0447367`(repo)+ 同款点补丁打云 /opt(备份 daemon.py.bak_20260824)。清损坏 pkl 重启→warmup failed=0→主项目 C--Users-chunx(2976 md)重建完成(22.9MB)。
2. **C1 回归门 ✅**:云 9876 双查询均 ok+命中 <1s(飞书单选 0.771 命中 tribal-feishu 记忆;loop state 0.661)。
3. **C2 ✅**:分支 compass/convergence-enforcement-20260707(0447367)+ tag v3.0.0 推上远端;main 从 81feef2 **fast-forward** 到 0447367(无强推)。
4. **C3 ✅**:云 /home/ubuntu/nautilus-compass 切 main=0447367,compass-mcp-tcp 重启 active,9877 握手响应(unauthorized=健康,需 token)。

## 云上残留(后续会话要处理)

- ~~云 daemon.py(/opt)分叉待统一~~ → **✅ 8/25 统一完成**:Stage1a /status(5min 滑窗/overload 计数/pkl 体积/psutil)移植进 repo(`af45dd1`),scp 同版到 /opt,云 daemon 跑 repo 单源。**过程中挖出并发 setdefault 竞态老 bug**(两线程各持 cache dict,稀疏 pkl 覆盖致条目丢失→347% CPU 反复 re-embed+33 次 tmp ENOENT)→ v3.0.3 per-project 锁+唯一 tmp 名修复(`f3063e1`)。终验:recall 0.9-1.1s 命中、/status 通、CPU 5.4%、零 flush fail。旧 68-commit 分叉线备份 `cloud-stage1a-backup-20260824`。
- 云 repo 换轨过程:stash 了 BLOGPOST impact counters(已有 _cloud_backfill_20260824 存档);untracked mcp_http_server.py 与 main 版逐字节一致后删除。
- 损坏 pkl 留存:`/home/ubuntu/c096d6883da3.pkl.corrupt_20260824`(可事后删)。

## 下一步(交接第三件,8/24 续推结果)

- **N3 三框重启+ingest:未动,球在三框**(云端 C--Users-chunx 2987 md 中无任何 platform/v5/fde agent_type obs)。
- **C4 ✅**:worktree 55→15。判据:已合并 或 最后提交<2026-08-09 → 移除 worktree 目录;**未合并分支 commit 引用全保留**(零丢失,可随时 checkout 复活)。保留:main + c2-*/g1-* 等近两周 codex 线。
- **V3.1-A act-on 9.87%→40%:读数结论=当前不可测**。verification_log 实测:14d 仅 241 次调用、2 alerts(率 0.8%),30d 11 alerts,90d 0.7%——v2 高精度警报本身就稀疏,样本不足以测 act-on 率。建议判据改为"alert→24h 内人 acknowledges 的比率,按季度汇总"或直接撤该 KPI(警报稀疏=特性非缺陷)。
- **V3.1-B 博文:未发**(对外发布,留用户确认;草稿 paper/BLOGPOST_memory_evidence_20260824.md 已就绪)。

B1 蒸馏判据 8/29 V5 广播后走。

## 8/24 下午增量:V5 自报"PROVEN"但证据全缺席(系统性)

- V5 两广播:`distill_proven`(1.5B 0/8→8/8,1.5B distilled>7B base,v3 80 轨迹旋钮)+ `g2b1_qc_full86`(71/86 OK)。数字漂亮,但 **proof 实物全部未落盘**:distill_v3_results/、ops/gpu_4090.md、distill7b.py、_g2b1_consistency_check.py、4 份 result.txt、g2b1 题池(genopt_live 0 dir)——本地/cloud/core 三处均无。DB 仅 9 条 g2b1 verdict。
- compass 已发验收请求广播(V5 repo `53bf6da`):要求三选一落盘证据,过则重放收录 PROVEN;建议 V5 建"广播前 proof 路径 repo 内自检"。
- 状态:~~CLAIMED-AWAITING-EVIDENCE~~ → **✅ 8/25 验收通过,PROVEN 收录**(证据押送 compass main `_v5_proof_deposit/`,commit 12b6964→3536353):distill 四项读数独立复算逐项一致(0/4·0/8 → 4/4·8/8;cross 8/10→9/10);g2b1 三仓计数精确复现+本机 n=3 双门抽查(2 OK+1 坏=V5 坏单同题);core result 文件截断(23 vs 24 OK,小瑕疵待重导)。L4a 合约核销,验收回执 v5 repo `064122a`。**remote 谜底:同机双 clone(V5 agent 用 `C:\Users\chunx\nautilus-v5`,compass 用 `Projects\nautilus-v5`)——跨框引用 commit 前先对 clone 路径**。中心环"蒸馏那一步"首次出证(边界:单族族内泛化/pass@5)。下一步球在 V5:拒采 80/族→混训→照格式押送再验收。
- 另:LOOP_STATE 8/24 增量已三仓逐字一致(genopt 自铸停/income 废弃);canonical 提交在 core `soul-distill-deploy` 分支 `28790870b`,待平台合 main。

关联 [[HANDOFF_20260824_V3_launch]] [[session-contract-dogfood-bridge-20260822]]

## 8/25 终章:V3.1-B 博文已发布

- **dev.to article 4483447 上线**(公网 200):https://dev.to/chunxiaoxx/benchmarks-cant-tell-you-if-agent-memory-helps-your-team-a-paired-control-can-1igm ·frontmatter 落账 `bf24527`
- **DEVTO_API_KEY 位置 = 云 `~/nautilus-v5/.env`**(marketing 渠道 `dev-to-publish` 注册);发布调用须带自定义 User-Agent(默认 Python-urllib 被 dev.to CDN 拦)
- Show HN 帖稿 `paper/publish_20260825/show_hn_draft.txt` 就绪,**需 HN 账号手工发**(无官方发帖 API)
- V3.0/V3.1 至此:CHANGELOG 全兑现,V3.1 表仅剩 N3(等三框 ingest)

## 8/25 渠道发布终态

- **dev.to ✅**(article 4483447,公网 200)
- **GitHub ✅**:Release v3.0.0《从记忆库到进化引擎》上线(published 2026-08-25T14:44Z,公网 200,含博文链接)——用**本机 gho_ token**(gh CLI);云端 .env 的 GITHUB_TOKEN/X_OAUTH2 全 401 过期(新旧备份都试过)
- **X ❌ 卡凭据**:云端 X_OAUTH2_ACCESS_TOKEN 及两枚旧 token 全 401,需用户重取;帖稿 `paper/publish_20260825/x_post_draft.txt` 就绪
- **Show HN ❌**:无官方 API,等用户手工(`show_hn_draft.txt`)
- arXiv 三部曲:另案,未动

## 8/25 下午:V3.0 双基准评测(全独立实测)

- **①eval_recall 回归 ✅**:P@1 0.972/MRR 0.982(基线 0.969/0.980,持平略升)——daemon 大改零回归。本机跑法=`PYTHONPATH=C:/pylibs`(torch 短路径配方);git-bash nohup 会随 shell 死,长任务用 harness 后台。
- **②LongMemEval-S 30 题(云, m3-rerank, gemini-flash subject) 端到端 26.7%(8/30)**;拆解:**检索命中 80%(24/30)**,命中仍答错 16=subject LLM 短板非 compass。分类:multi-session 0.8 / single-session 系全 0 / temporal 0。⚠️ 与 PyPI "56.6%" 旧 claim 口径不符(旧 subject/judge 配置),**待用户拍板:改两段式声明(检索 80%/端到端 26.7%)发 3.0.1,或保留旧 claim**。数据:云 `.cache/longmemeval_acc_m3_rerank_subset30_1787675871*`。
- 渠道核验:PyPI=3.0.0 ✅(release.yml 自动);GitHub tag+Release ✅;npm 从未发布(package.json 2.3.0 陈旧待对齐/删)。

## 8/26 感知层三件套+补召回(C)

- **B 命中计数**:HUD `🧠今日Nhit/1h M`(verification_log 实算)——首日读数 97hit/天,价值首次可见
- **A session 战报**:stop_hook 写 `~/.claude/.cache/compass-last-session.txt`
- **D 池瘦身**:lifecycle 默认 ON(`00e0603`),仅影响带 forget_at 条目(compass 项目 50 条中 1 条,零误伤面)
- **C 中途补召回**:`mid_session_hook.py` v0.7 早已写好但**从未接线**(同 HUD poller 病:建好即死)。已接 PostToolUse(matcher *,每 30 调用+>20min 静默刷新),烟测 exit=0。**教训入册:本仓"未接线的好代码"已两例(HUD poller、mid_session),部署检查项=不止写代码,还要核 settings.json 接线**
