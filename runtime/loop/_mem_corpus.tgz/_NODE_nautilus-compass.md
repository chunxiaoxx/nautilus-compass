---
name: nautilus-compass — 项目知识图谱节点
type: project-node
project: nautilus-compass
role: 记忆员 + "体检医生"（持 PoI 账本 + liveness framework，多框 RSI/FDE 编排里的独立裁判）
drift: green
synthesized_from:
  - session_e2c01ab4  # 2026-07-02 liveness-framework 合并 + 探针误诊修复（worktree）
  - session_00b61b64  # 2026-07-07 独立裁判探针 / income 188 从 verdict 复现
  - session_9c3b69dc  # 2026-07-07 MCP 断线根因 + 标准远程 MCP 上线
  - session_b2b522dd  # 2026-07-07 收敛执法日报 + PR 审计连环发现
last_synthesized: 2026-07-14
tags: [nautilus-compass, probe, grounding, anti-theater, ssot-drift, mcp, fde, tdd, false-diagnosis]
reinforce_count: 24
---
# nautilus-compass 项目知识图谱节点

compass 是多框（V5 / platform-soul / FDE）编排里的**独立裁判 + 记忆员**：持 PoI 账本、liveness framework，
职责是用探针拿真值去审别的框（和自己）有没有"剧场化"。它的第一原则反过来最常咬到它自己。

---

## 复发模式（Anchors，附出现次数）

- **#1 「自报不算，能独立复现才算」（4/4 会话）** — 项目立身之本，也是最高复发教训。
  income 不读 `agent_survival.total_income` 自报字段，从底层 verdict 行 `sum(round(score))` 重算才算真值。
  推广到极致：**连自家 README 也是"自报"**（session b2b522dd 三次拿陈旧 README 当现状而误判卖点）。
  回答"能干啥/闭没闭"类问题必 MEASURE（跑 audit_kpi / grep 接线 / 查 live log），禁止抄文档。

- **#2 「探针/结论红灯先证伪自己，别默认被测物有病」（≈4/4）** — 去伪比抓病更高频有效。
  session e2c01ab4：2 个 RED 探针全是探针自己设计错（阈值不合理 + 幻觉不存在的符号名，连续三次幻觉）。
  session 00b61b64：「psql creds 失败」是伪命题（真因是 SQL 把 agent_id 整数传成字符串）。
  session 9c3b69dc：「MCP 超时=服务死」误判，真因是 host 过载。写"检查代码含某标记"断言前**必先 grep 真源码确认标记存在**。

- **#3 「件数 ≠ 价值 / 活着 ≠ 可观测 ≠ 有产出」（≈3/4）** — 剧场识别的核心尺子。
  引擎 last cycle 停在 2026-06-03、24h 内 0 cycle，但 `agent_tool_calls` 还在涨 → agent 活着但空转。
  飞书 29 行交付表 = seed 假数据（sha256 全 `a1b2c3d4`、行重复），真交付 0/11。
  `/api/health`=200 ≠ 探针能读真值。护栏 fire（drift alert）时**不硬执行"全都做"**。

- **#4 「复用已实现的，改动前先 grep 仓库找旧实物」（≥2/4）** — 反重造。
  标准远程 MCP 早有实物（`compass_http.py`/`gateway.yaml`/`mcp_server.TOOLS`），DB 连接配方早在
  `fde_verdict_reconcile.py`/`_poller.db_connection` 现成。照抄已验证的邻近模式（平台 HR agent 的 FastMCP+nginx）。

- **#5 「SSOT drift = 精神分裂病根」（≥2/4）** — 跨框副本 stale 会让人按过期框架继续干、正撞用户红线。
  session 9c3b69dc：compass 注入副本是 7/3 版，缺 core canonical 7/5 收口指令（D 暂停扩张、锁 11 题）。
  修法：**canonical 先改，再 verbatim 拷副本，零 drift**。参见 [[compass-daemon-split-brain-部署漂移]]。

---

## 矛盾与陷阱（会话间不一致 / 被推翻的结论）

- **陷阱 A — "income" 是多义词，别混口径。**
  · verdict-derived = **188**（session 00b61b64：external_verified∧overall_pass 的 2 条 = 98+90，canonical C 口径）
  · agent_survival 权威实测 = **504**（session b2b522dd）
  · 早先 SSOT 散文值 = 98/188（7/6 one-off）。
  这些不矛盾但**度量不同**（累计 pass 铸币额 vs 存活总账 vs 单轮）；引用 income 必须带口径和时间，否则自造矛盾。

- **陷阱 B — MCP 状态在会话间翻转。**
  session 00b61b64：`/compass-mcp/`=502（upstream 挂）；旧记忆疑"服务死"。
  session 9c3b69dc 推翻：服务健康，真因=cloud 2 核机被泄漏 sshd（PID 63067，1000+ fd、92%CPU 烧 20 天）拖到 load~5，
  SSH 握手偶发 >30s 破客户端超时。kill 后 load 5→2、握手 <0.4s。**并已迁标准远程 MCP 根治隧道脆弱**。

- **陷阱 C — RED 探针 ≠ 系统缺陷。** 不要照搬"framework 报 2 RED = 系统 2 处缺陷"（session e2c01ab4 早期误判）。
  当轮全部 RED 都是探针设计缺陷（阈值 + 幻觉符号）。

- **陷阱 D — 陈旧 README 数字全错。** drift act-on rate README 说 0.012、实测 **0.178**（stop_hook 接 auto_ack 后跳 15 倍）；
  MCP 工具数 README 徽章 7 / 子 agent 说 16 / 实数 **17**。子 agent 报的数也要自验，不 propagate 未自验数字。

- **陷阱 E — 跨框推断易错，须标置信度。** platform-soul 自己 7 处推断被后续证伪（docker 镜像"空"v1→v2 自我推翻）；
  "inbound 静默"多因搜索路径太窄，别当 grounded 结论。

- **陷阱 F — conv2d oracle 曾是错的。** `output=acc` 在 in_c 循环内是赋值非累加，C_in>1 只留最后通道；
  修成 `+=`（numpy 交叉验证）。**基于旧 oracle 的所有 conv2d pass@k/escapes 判定作废需重算。**

---

## 决策时间线

- **2026-06-03** — 引擎 last engine_cycle。此后 cron 0 执行 = 实质停摆起点。
- **2026-06-05** — README 基线（后来成为"陈旧文档"误判源头）。
- **2026-06-22** — v2.3.0：4-tier 生命周期 + PoI 闭环已接进生产 recall（推翻"未激活"说）。
- **2026-06-30 → 07-02** — liveness-framework worktree 3-way merge 进 main（9cd70eb），修 3 探针 GREEN，rebase+push，发 **Release v2.3.1**。
- **2026-07-04** — 泄露 API key `sk-c16301…` 最早进 git 历史（repo PUBLIC）。
- **2026-07-05** — core canonical 下 SSOT 收口指令：D 暂停扩张、锁 11 题交付（compass 副本一度缺失）。
- **2026-07-06** — income 98 首次 one-off 收敛（未自持）。
- **2026-07-07（三场并发会话）**
  · 独立裁判探针成形：ssh-tunnel 读生产 DB，income 188 从 verdict 独立复现。
  · MCP 根因坐实（过载 sshd）+ 标准远程 MCP 上线 `nautilus.social/compass-mcp/`；补 SSOT 7/5 drift。
  · 收敛执法日报 + PR #49（P0 key 删除 + Lint 27×F401 转绿 + conv2d 修复）；挖出两本账背离、飞书假交付。

---

## 当前真实状态（grounded，不信中途乐观声明）

- **引擎实质停摆**：last cycle 2026-06-03，24h 内 0 cycle（总 49）。agent 活着但空转——tool calls 累计 329320+ 仍涨，
  income delta watch 首跑即 FLAT(+0)，**无自产**。settle 路由全 404（`send_to_agent 218/0`、`claim_bounty 16/0`），自循环 settle=0。
- **真交付 0/11**（飞书 29 行是 seed 假数据，非成果）。自治率实测 ≥4 条 autonomous verdict（高于 SSOT 自报 3）。
- **income**：verdict-derived 188 / agent_survival 实测 504（口径见陷阱 A）。
- **探针能力**：ssh-tunnel（SSH alias `cloud`）+ psycopg2 + `.soul_db_secret` 可读生产 6 表；
  **唯一缺口 = `agent_survival` 总额 + ledger 类 permission denied**，已发 GRANT 请求走 dogfood 合约通道，待授权后补直读。
- **MCP**：标准远程 MCP 已上线并公网验证（init 2.3.0 / tools/list=17 / recall 真往返 / 无 token→401），复用 nautilus.social 现有 TLS 零新证书；
  旧 SSH 隧道 + 桥待退役（隧道本 session flap 两次，是被根治对象）。**①③ 独立裁判全程不依赖 MCP**，MCP 挂不阻塞裁判。
- **liveness framework** v2.3.1 已进 main，3/3 探针 GREEN；drift act-on rate 实测 0.178。
- **安全/CI**：P0 泄露 key 用户判"不 rotate、删代码即可"；系统性 Lint 红（27×F401）已 `ruff --fix` 转绿——
  这是 5 个 dependabot PR 卡一个月的真根因，非各 PR 自身问题。
- **交付球权**：PR #49 未 merge。球在 V5（2 条 7/9 合约：fake_success 部分兑现、evaluate_artifacts 未做）与 FDE（11 题内容）。
  compass 减法清单软砍 8 项、16 个 _OUTBOUND 归档、outreach 4 cron 待拍板。
- **判断**：compass 的裁判能力本身已 grounded 可用；但它裁判的对象（引擎自产/自持增长）**尚未真活**，
  须 V5 修 agent 执行管道（cron 真执行 + 动作真 settle）才谈自持。

---

## 可复用技法总表（本项目高价值沉淀）

| 技法 | 要点 |
|---|---|
| 独立探针铁律 | 能复现的才算真值：income 从 verdict 行 `sum(round(score))` 重算，天然抗剧场/抗自报 |
| 红灯先证伪探针 | grep 真源码确认探针查的符号/字符串真存在，再断"被测物有病"；LLM 会反复幻觉不存在的标记 |
| 端口活但握手超时→查 host 负载 | LISTEN≠能及时应答；先直连底层端口探针(<1s?)排除服务死，再看 load 找拖累源 |
| 复用已实现的 | 改动前 grep 仓库找旧实物，照抄已验证的邻近模式（HR 的 FastMCP+nginx / 现成连接配方） |
| 多读路径并探 | DB(ssh-tunnel) + 公开 HTTP control-plane 双探；连接失败逐环实测(secret→ssh alias→psycopg2→GRANT) |
| TDD + effect 注入 | fake conn/cursor 覆盖 GREEN/STALE/GAP/RED 分支不依赖网络；完成后必 live 真连跑一次 |
| watermark-delta | `record_and_diff_income` + `--watch` 记上次值报 delta，真实反映引擎有无自产 |
| 诚实报 GAP | 无 grant 就报 GAP + needs GRANT + 回退 verdict-derived，exit≠0 是诚实的 |
| 飞书 IP 白名单破解 | 走 cloud 白名单 IP 转发本地 app 凭据；值只在 shell 插值、不落盘、不入上下文（`ops/feishu_read_via_cloud.py`，顺修 Windows GBK/UTF-8 bug） |
| 删死件双重防误删 | grep refs 先排除自造引用（减法清单文档自引用），确认真代码/cron/config=0 才删；删后 py_compile + 冒烟跑活链 |
| canonical 先改再同步副本 | 跨框 SSOT 改动先改 core canonical，再 verbatim 拷副本，零 drift |
| 护栏 fire 不硬执行"全都做" | 先 acknowledge，给不做的依据，只推荐关键路径件——除非用户在风险知情下明确拍板 |
| dev/production 阈值分离 | freshness 类探针给 dev 宽容差 + 注释保留 production override flag，避免 dev 长期假红 |
| cutover 防 clobber | 改 `~/.claude.json` 用幂等 re-apply 脚本、外科式只改一项、备份先行（session 退出会刷回旧内存配置） |
| 内容级铁证识别假数据 | sha256 全假值 / 重复 ID / 模板反馈 = seed，行数≠真交付 |
| 合约通道 dogfood | `contract_close_*.md` frontmatter `status: consumed`（显式 status 始终生效）；scanner 复核 outstanding/consumed |
| 中间件隔离测试 | `StreamableHTTPSessionManager` 每实例只能 run 一次，auth 测试用一次性小 app 挂中间件，别共用模块级 session_manager |
| worktree 清理 | cwd 在 worktree 内无法删自身，先 cd 主仓再 `git worktree remove/prune`；Windows 文件锁致残留空目录可接受 |

---

## 交叉引用

- 会话记忆：[[session_00b61b64]] · [[session_9c3b69dc]] · [[session_b2b522dd]] · [[session_e2c01ab4]]
- 同项目历史：[[session_554f5d90_compass_daemon_p0]] · [[session_20260707_compass_infra_repair_and_sync]] · [[session_20260603_paradigm_b_probe_design]] · [[compass-daemon-split-brain-部署漂移]]
- 兄弟项目节点：[[nautilus-v5-fake-success-contract]]（球权对手 / conv2d oracle + key rotate outbound）· [[nautilus-v5-root-a-b-脑身融合]] · [[nautilus-v5-rsi-棘轮两层修]] · [[nautilus-core-platform-soul-scoreboard]]（记分牌上游 / verifier correctness）· [[session_20260616_fde_flywheel_capstone]] · [[session_37d970aa_guoshu_rebzj_drift]]
