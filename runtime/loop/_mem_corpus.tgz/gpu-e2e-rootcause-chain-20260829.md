---
name: gpu-e2e-rootcause-chain-20260829
description: "GPU e2e 500 四层根因链(429限流/reranker权重损坏/漏ZMM_SSU_UTTERANCE/bge路径不认)+教训:抄env必须逐项diff·权重必须验载·API必须退避"
metadata:
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-28T16:55:45.779Z
---

2026-08-28/29 · e2e 500 从 cloud 搬 GPU 4090PLUS 的四层根因链（每层都独立验证修复）：

1. **judge 429 限流**：8 分片并发打 newapi，47% judge 调用 429 被外层 except 判 INCORRECT。修复=指数退避重试 429/5xx（commit ce848f5）+ 降 4 分片。
2. **reranker 权重损坏**：wget 残留(997KB) + ModelScope 续传混合成 2.27G 怪物，CrossEncoder 抛 `incomplete metadata, file not fully covered`——eval 加载段 try/except 静默吞掉→reranker=None→context 取前 3 条无关 utterance→模型答 "no information"。**最快修复路径=本机 HF cache 有干净版直接 sftp**（先找本地再下载）。修后必跑 score 区分度验证（相关句 vs 无关句应差 3 个量级）。
3. **🔴 抄 env 漏 `ZMM_SSU_UTTERANCE=1`**（最隐蔽）：run_shard.sh 从 cloud e2e500_shards.sh 抄时漏此项——它同时控制 reranker 加载条件、utterance context 入口、tr 日期修复。漏了则全部旁路落回 build_context。**教训：跨机抄 env 必须逐项 diff，不能凭记忆重打**。
4. **bge-m3 路径不认**：daemon 只认 `~/.cache/modelscope/hub/models/BAAI/bge-m3` 或 HF id；GPU 机的 bge-m3 在 /root/models/bge-m3 → 落 HF id → 匿名限速卡死（6 分钟无输出+GPU 15MiB）。修复=显式 `ZMM_EMBEDDER_MODEL` 指本地路径。reranker 同理（ZMM_RERANKER_MODEL）。

**GPU vs cloud 性能**：嵌入 GPU 化后 ~30-60s/题 vs cloud 660s/题；4 分片 500 题 ~4h。

**其他教训**：
- HF 匿名直连晚高峰会整体劣化（5.6MB/s→停滞）；ModelScope 稳但 0.5-1.5MB/s；断点续传可跨工具续（kill 后重跑 snapshot_download 接着传）
- pgrep/pkill -f 在远程 exec 里也会自匹配自己的 bash -c 命令行（REMAIN=1 假象）；用 `ps -eo pid,cmd | grep '[x]' | awk` 精确 kill
- MSYS 路径转换会把 /root/... 转成 C:/Program...（`MSYS2_ARG_CONV_EXCL="*"` 前缀）；本地 /tmp 文件 paramiko upload 要用 Windows 完整路径
- 实例 IP 会换线（js3.blockelite.cn→223.109.239.32 移动/180.127.11.166 电信），连不上先试 IP 直连
- CLI connect 拿实例初始密码需 `--include-sensitive`；但用户改过密码后 initial_password 无效

关联 [[e2e-context-fix-and-tr-diagnosis-20260828]] [[gpu-instance-reuse-not-rent]]
