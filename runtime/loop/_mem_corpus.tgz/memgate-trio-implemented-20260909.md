---
name: memgate-trio-implemented-20260909
description: "#48 记忆门三件套实现完成(daemon 仓 feat/memory-gate-trio 分支,未部署)——fact_status/dedup_check/沿链一跳+J4 基线 GREEN,9/15 窗口合入"
metadata: 
  node_type: memory
  type: project
  verified_at: 2026-09-09
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-09T15:48:49.110Z
fact_status: measured
---

# 记忆门三件套实现完成(9/9 · 未部署,9/15 窗口合入)

**交付**(daemon 仓 `feat/memory-gate-trio` 分支 b982327+9cb9e7e,worktree
`~/.claude/plugins/nautilus-compass-memgate`):修复一 fact_status 写入门
(parse_memory_file 读出+recall 带出+hook 亮牌,只标注不过滤);修复二 dedup_check
action(BGE 三档 merge≥0.9/gray 0.75-0.9/unique,纯函数可单测,session_writer
写前探测 merge 只标 merge_target 不自动改写,fail-open);修复三 [[name]] 沿链
一跳(chain_extra 独立字段 cap5 不污染主列表)。15 单测绿+J4 回归门基线 GREEN。

**Why:** RSI 试验环 #1(预注册判据四条冻结于 compass 仓
docs/plans/2026-09-09-rsi-trial1-preregistered.md);流程=实现→回归→非实现者
复算→合入。

**How to apply:**
- 9/15 窗口:生产 worktree 切/合 feat/memory-gate-trio(3912205 已固化 9/1 WIP,
  合入零冲突)→受控重启→跑 `python ops/regression_gate.py`(对照基线)→J1-J3
  读数回填预注册档→非实现者复算。
- 测试实例隔离:`COMPASS_DAEMON_PORT=9877` 起 daemon(PORT 已 env 化)。
- 改判据只许更严;session_writer 自动合并被否(污染原条目),走 merge_target 标注。
- 守护红线:**勿在发布/值守期间直接改生产 worktree 的 daemon.py**——watchdog
  5min 内会拉起半成品;一律 worktree。
- 相关:[[memory-audit-seven-operators-20260907]] [[compass-roadmap-20260907]]
  [[verifypack-v02-built-20260909]] [[daemon-9876-watchdog-rootcause-20260908]]


**9/14 预演定案**:直接 merge feat/memory-gate-trio 到 main **不可行**(10 文件冲突,根因=3912205 WIP 快照与 main 安全序列平行演进)。9/15 改走 **cherry-pick 路线**:成品分支 `merge-ready-0915`(memgate worktree,=main+1121328+de0552b,conftest.py 唯一冲突已解=两段保留),15 单测绿+J4 gate GREEN(9878 实测,生产未碰)。runbook:生产 checkout merge-ready-0915,勿直接 merge。⚠️9877 端口被 P1 SSH 隧道占(9/15 停),测试实例用 9878。报告:docs/plans/2026-09-14-merge-rehearsal.md(fba41ec)
