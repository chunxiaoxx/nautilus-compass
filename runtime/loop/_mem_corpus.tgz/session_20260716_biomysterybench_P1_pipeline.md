---
name: session_20260716_biomysterybench_P1_pipeline
description: BioMysteryBench P1 端到端跑通:VCF→变异临床意义模板,build/solve 管线雏形,独立盲解坐实 PAH/Phenylketonuria 唯一+36工具+无泄露
metadata:
  node_type: memory
  source_session: 2026-07-16 compass BioMysteryBench P1
  type: project
  originSessionId: 18a77e1b-1920-42a2-be4e-5cb76091e10d
---

# BioMysteryBench P1 端到端跑通(2026-07-16)

承接 [[session_20260716_biomysterybench_scaffold]](脚手架+验证器+500设计)。P1 = 证 1 模板端到端,**不铺量**。

## 成果(独立验证非自报 · commit 5da3719)
`vtf/fde_benchmarks/biomysterybench/` 下新增 `build_problem.py` + `solve_problem.py` + `_P1_out/`(问题+溯源)。
- 题 `bmb_vendor_000001` = **VCF→变异临床意义**模板:1 个隐藏 ClinVar Pathogenic 变异(**PAH / Phenylketonuria**)+ 17 个 Benign/VUS 干扰,全部真实 ClinVar 记录 + 真实 GRCh38 坐标(`canonical_spdi`),组装匿名 VCF(剥 rsID→'.'/INFO→'.'/基因名/致病性),18 变异跨 10 染色体,答案埋中间。
- 验收 4 项全达成:① 1 行 problems.csv + data/*.zip ② bmb_validator **0 REJECT/0 WARN/exit 0** ③ **盲解**(solve_problem 只读 zip)→ `PAH|Phenylketonuria`,致病命中**唯一=1**,**36 次工具**(VEP18+ClinVar18,≥10 门),无泄露 ④ 脚本=管线雏形。

## 可复用工具链(已实连,别重造)
- **建题真值源** = NCBI ClinVar E-utilities(Biopython Entrez):`esearch db=clinvar term='{gene}[gene] AND {clinsig}[clinsig]'` → `esummary retmode=json` → `germline_classification.description`(致病性)+ `trait_set[].trait_name`(病名)+ `variation_set[0].canonical_spdi`(权威 GRCh38 坐标)。⚠️ `[clinsig]` 过滤不精确,须代码里按 description 精筛;`single_nucleotide[vartype]`/`single_gene[prop]` 过滤器**无效清空结果**,别用,SNV 靠 SPDI len==1 筛。
- **解题工具链**(允许域名内):① Ensembl VEP REST `rest.ensembl.org/vep/human/region/{chr}:{pos}-{pos}:1/{alt}` → 基因+most_severe_consequence(colocated rsID 常空,别依赖)② ClinVar 坐标查 `esearch term='{chr}[chr] AND {pos}[chrpos38]'` → 分类+病名。
- SPDI→VCF:`NC_000012.12:P0:ref:alt` → CHROM=12, POS=P0+1(0-based→1-based), REF=ref, ALT=alt。NC_000023→X, 000024→Y。
- 环境:Windows `python`(3.13.12)+ Biopython 1.87 实连 NCBI+Ensembl。**WSL 网坏别用**;小数据模板无需本地重工具/cloud box。

## 难度守恒的关键设计(P2 复用)
答案选 **missense**(非 stop_gained),让它藏在良性 missense 干扰项里(9/17 干扰也是 missense)→ 模型不能靠"挑 impactful 后果"蒙,**必须逐个查 ClinVar** → 守住 20-30min/多工具。我们知解法所以 131s,模型不知所以慢(DESIGN 的"难度来自模型摸不出工具链"被实证)。唯一性靠策展:干扰池硬校验 `cls not in {Pathogenic, Likely pathogenic}`。

## 教训
- rubric 初稿 HGVS 写错(臆想 c.782G>T,ClinVar 真值 `c.965C>A p.Ala322Asp`,基因组 G>T 负链→cDNA C>A)。**核对 ClinVar title 救了事实错**——rubric 里的坐标/HGVS 必回查真值,别凭记忆。
- 盲解 18 变异含网络+限速 >120s,长于单 bash timeout,用后台跑。

## 续:2 模板 / 批产 / 本地镜像 / 500 环境结论(2026-07-17 · commit 11eac21+ee47a38)
- **VCF 模板参数化**:`build_problem.py --answer-gene` 自动挑 Pathogenic missense + 排除同基因干扰。新增 #2 `bmb_vendor_000002` ATP7B/Wilson disease(0 REJECT·盲解唯一·36 工具)。
- **第 2 模板 = 序列→基因/病(BLAST)**:`build_seq_problem.py`/`solve_seq_problem.py`,对齐买方 qes1 的 BLAST 范式,小数据(蛋白 KB)。#3 `bmb_vendor_000003` HEXA/Tay-Sachs:10 条真 RefSeq 蛋白剥头,判别子=**溶酶体定位**(可核查唯一,不靠模糊"有没有病")。盲解 10 blastp 全干净、唯一=1、**墙钟 1204s 压中 20-30min 档**。⚠️ 远程 `NCBIWWW.qblast` 会瞬时 `ssl.SSLError DECRYPTION_FAILED_OR_BAD_RECORD_MAC`(代理抖动)→ solve 加退避重试。qblast vs swissprot ≈ 63s/条。
- **本地镜像(Windows 原生·零 GPU·零 WSL·消 Entrez 限速)**:`build_local_clinvar.py` 把 clinvar.vcf.gz(白名单 ftp.ncbi 下载·192MB)用 Bio.bgzf 解析→SQLite(**420万条/413MB/建库 67s**,INFO 取 CLNSIG/GENEINFO/CLNDN)。`local_clinvar.lookup`/`qc_vcf_local.py`。**实测本地 0.20ms vs 远程 2715ms = ~13583× 提速,结果 5/5 一致**;#1/#2 本地 QC 各 3ms 唯一=1。→ 500 题唯一性 QC ≈ 1.5s(远程 16+h)。`_localdb` gitignore(可复现)。
- **500 生产环境结论(用户问)**:**任何阶段不需要 GPU**——重计算在 NCBI/Ensembl 服务器,本机只 Python;BLAST 也远程。生产机 = 1 台普通 CPU 机 + 本地镜像库(ClinVar 已建 · 待:VEP offline cache ~25GB · 本地 BLAST+ SwissProt ~90MB)。死守小数据模板避 TB 级。门槛在策展+QC,不在算力。
- **WSL 决策(live 探针坐实)**:网坏根因 = `.wslconfig` `networkingMode=mirrored`+autoProxy+dnsTunneling(6/3 为 SWE-bench Docker 设)+ docker-desktop 运行冲突;resolv.conf/路由其实都在。**删重建治不了本**(仍读同 .wslconfig)。用户拍 **Windows 原生**——BLAST+ 有 win64、ClinVar Python 解析、snpEff Java 可替 VEP,彻底绕开 WSL,不动 SWE-bench/docker。真要 Linux 走 NAT 一条配置改。/mnt/c 挂载正常(可 Windows 下载→WSL 离线读)。
- 通用词泄露坑:答案含 "disease" 撞 question 措辞 → build 期加泄露断言(镜像验证器),两模板改 disorder/condition 措辞。

## 试点交付(2026-07-17 · commit 169fed7)
`make_delivery.py`(可复用投递打包器):合并各题目录→买方格式单一包(problems.csv N 行+data/*.zip),**硬断言 answer_key/_source_manifest 不进买方包**。`_DELIVERY/`=3 题合并·验证器复验 0 REJECT/0 WARN·答案+溯源留 `_INTERNAL_provenance.json`(勿投递)。`DELIVERY_NOTES.md`=验收证据+数据真实性溯源(每变异 VCV accession/每序列 NP_ accession)+500 无 GPU 结论。买方载体最终可上飞书表+网页,当前文件形态。P4 批产交付直接复用此打包器。

## 提交前对照买方文档审查(2026-07-17 · commit 7b1731a)
🔴 铁律实践:审查必对**买方原文档**(`~/Downloads/BioMysteryBench 数据要求【外部】.pdf` + 样例 `biomysterybench.zip` 里 `bio/qes.xlsx`=qes1),不对我自己的 bmb_validator(那是自报转译)。逐条对照修 5 处:
- **F1(关键)**:问题原点名了 VEP/ClinVar/BLAST 产品 → 削"模型自主选工具链"难度且不合 qes1 风格(qes1 只问"What cancer…"不点工具)。改用**工具类别**措辞(变异注释/数据库检索/序列比对=买方 §2 自己列的类别),既保难度又满足"需工具"信号。
- **F2(关键)**:VCF 变异 18→30 消 §5"难度过低"退回风险(30 变异远程盲解 60 次交互/唯一=1 确认;`--n-distractors` 默认 29,干扰基因池扩到 35)。
- F3 allowed_domains 补全 14 白名单(qes1 即列全 14)· F4 答案格式统一 `GENE|Condition` · F5 data zip 改纯数据(去 README,qes1 是纯数据 zip)。
- 买方关键口径复核:§2"真实**或构建**的数据"→ ClinVar 组装 VCF 合规(非造假);§4 目标 20-30min/>10 工具交互;§5 拒收=难度低/无需工具/泄露/无法加载/答案模糊/不符风格。
- 全复验:合并 3 题 0 REJECT/0 WARN;本地 QC 唯一;#1 远程盲解 60 交互。**试点交付包 `_DELIVERY/` 正式就绪**(problems.csv 3 行+data/*.zip;_INTERNAL_provenance 勿投递)。

## 正式投递上双载体(2026-07-17 · commit 6f24f15)
charter 交付载体 = 飞书多维表格 + 网页,两者都上了:
- **飞书**:`ops/feishu_bmb_deliver.py` 复用 `feishu_read_via_cloud` 的 **cloud 白名单 IP 代理**(家宽直读飞书报 99991401,必经 cloud egress 43.160.239.61;现成模块只读,扩了 create-table+batch-create-records 写能力)。凭据 `~/.claude/.cache/.fde_api_secrets.env` FEISHU_APP_ID/SECRET,ssh env 传。建专属投递表:base `RGDKbrtZ1aMcEOsZ2GcczeFknNg` / table **`tblgEfCYYVdwo5tO`**(BioMysteryBench_投递_试点_20260717),3 行=买方 5 列+内部答案/数据包/验收列,**读回验证 3 行答案正确**。⚠️ RGDK base 是 v06 培训链管理表(v06_交付总表 tblwz7PQZrZW3UzO 等 schema 不同),BioMysteryBench 另建专属表不混塞。
- **网页**:`_DELIVERY/BioMysteryBench_投递_试点.html`(build-html-dashboard skill 生成,交互筛选+排序+canvas+空状态,真数据核验,5.8KB 离线可开)。
- 🔴 保密:飞书/网页/题面全零甲方名。买方消费格式仍是 problems.csv+data/*.zip 文件;飞书+网页是 charter 呈现/追踪载体。

## 做实体量:埋进 3000 真实变异(2026-07-17 · commit 62fc98e)
用户质疑"6KB 太小,符合条件吗"——查买方文档**无大小要求**(只难度/唯一/需工具),但直觉对:比 qes1(721MB)轻太多,观感+难度稳健性风险。修法=**把致病变异埋进 3000 个真实 ClinVar 背景变异**(非造假撑大):
- `fetch_background_local(n, exclude_gene)` 从**本地 ClinVar SQLite** 拉 Benign/Likely benign/VUS SNV(排除 pathogenic/conflicting/同基因/答案坐标),瞬时零限速真数据。`--n-background` 默认 3000。VCF 未压缩 99KB/题(真实 exome 子集),发送包 6KB→45KB。
- **副作用是好的**:3000 变异 brute-force 逐个不可行 → 逼模型用批量注释工具(VEP 批+ClinVar 筛)= 更贴买方"需真工作流",难度更强。唯一性靠本地 QC 全扫 3001 变异(致病命中=1)复核——不跑 6000 次远程盲解(不现实)。
- 🔴 **bug 教训**:`make_delivery.py` 原 `shutil.rmtree(_DELIVERY)` 把整个交付目录清了→**误删手写的 DELIVERY_NOTES.md/网页**(git 恢复)。改成只清 `data/*.zip` 保留手写件。**打包器别 rmtree 混放手写+生成物的目录**。
- 买方发送包 = `_DELIVERY/BioMysteryBench_delivery_20260717.zip`(只 problems.csv+data/*.zip,内部泄露自检✅)。渠道待用户告知(伊洛→买方投递方式我不知)。

## 买方反馈:题干去 AI 感/模板化(2026-07-17 · commit 30f000a/afa5e62)
买方反馈:「题目描述有 AI 感和模板化,建议看原 BioMysteryBench 出题格式,自然简单语言不需背景介绍」。**反馈准确,不辩护**。根因=我题干过度工程化:一堆背景铺垫("variant calls from one individual's panel…")+ "Investigate using…工具" + "Answer strictly in format GENE|Condition"。**买方样例 qes1 就一句:"What cancer is found in this sequenced dataset?"**——无背景/无工具说明/无格式模板。
- 修:三题题干重写为 qes1 风格自然一句直问(VCF 题干池跨题轮换措辞治模板化);rubric 精简为"The answer is X / Y. Accept …别名. Score 1.0/0.0"(值本身,不堆坐标/工具)。答案格式移入 rubric(qes1 亦如此,题面不写格式)。
- 🔴 **验证器按买方偏好校准**:bmb_validator 删掉 `no_answer_format`+`maybe_no_tool` 两条 WARN——它们与买方"自然语言不写格式/工具"偏好**直接矛盾**(且买方 qes1 本身触发它们)。工具需求靠供应商真解坐实,格式靠 rubric。校准后交付 0 REJECT/0 WARN。
- **泄露坑复现**:题干池含"disease-causing"撞"Wilson disease"答案→建题断言抓到→池改"pathogenic for an inherited disorder"。**答案含通用词(disease)时,题干一律用 disorder/condition**。
- 数据未变(仅题面)→ 解题性/唯一性不受影响。发送包重打 44KB。飞书重推自然题干版=表 `tblTHVqUNmIkNMiB`(旧 tblgEfCYYVdwo5tO 作废)。
- 教训沉淀:**FDE 题干 = 自然一句直问(qes1 范式),不要 AI 式背景铺垫+工具说明+格式模板**。这条对所有 FDE 出题通用(不止 BioMysteryBench)。

## 优化+产第4题(2026-07-17 · commit 4889fd4/d011e82 · 用户切 Fable5)
- **对照买方文档再优化**:#2 题干"陈述+祈使"两句→改单句疑问(qes1 是单句直问);题干池 3→6 句(治模板化,id 1/2/4 各不撞——**教训:池太小 id%len 会撞车**)。rubric 已贴合(值+别名+全对全错+anti-cheat)不再动。
- **产第4题 = "持续产出"验证**:`bmb_vendor_000004` GALT/Galactosemia(VCF 管线换基因即出,`--answer-gene GALT`)。独立验证:本地全扫 3001 变异致病唯一=1 + 远程 VEP/ClinVar 坐实答案 `c.396C>G p.His132Gln Pathogenic Galactosemia`。**VCF 管线是持续产出引擎:换基因秒出题+本地 QC 秒验唯一**。
- 现状:**4 题/2 模板**(VCF×3=PAH/ATP7B/GALT + 蛋白序列×1=HEXA)。合并验证器 0 REJECT/0 WARN;发送包 65KB 无泄露;飞书 4 题版=表 `tblqpv36rz23tE9T`;网页 4 条。
- ⚠️ 飞书表 proliferation:每次改内容重推=新表(v1 tblgEfCYYVdwo5tO→v2 tblTHVqUNmIkNMiB→v3 tblqpv36rz23tE9T),旧表作废。**未来该加 update-record 或 delete-old,别一直新建**。
- 下一题产出方向(未拍):继续 VCF 换基因(快),还是补新模态(RNA-seq→组织/宏基因组→物种·增买方 8 类型覆盖·反单调)。买方反单调批次→到量时须铺模态。

## 下一步(未拍优先级)
镜像本地 SwissProt BLAST + VEP cache(序列/VCF 题 QC 全本地秒级)→ P2 扩模板覆盖买方 8 类型+反单调 → P3 编排(断点+配额)→ P4 批产+抽样真解 QC。管线可招生信专家复用(compass 建工厂·专家产内容)。

关联 [[session_20260716_biomysterybench_scaffold]] · [[FDE_BUSINESS_CHARTER]] · FDE 第三类 benchmark
