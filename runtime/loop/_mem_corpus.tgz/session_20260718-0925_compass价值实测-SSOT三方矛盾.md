---
name: compass价值实测·SSOT三方矛盾
description: 7/18 用 compass 八探针实测自身价值:当场揪出 v5/core/live-DB 三份真值段互相打架,续发 7/18 收敛执法日报
type: discovery
concept: how-it-works
drift: green
drift_signals: []
agent_type: claude-code
user_id: u_local
ingested_via: mcp
proof_of_recall: fail
proof_of_recall_reason: agent_type_mismatch
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 47
---

# compass价值实测·SSOT三方矛盾

## 上下文
7/18 用 compass 八探针实测自身价值:当场揪出 v5/core/live-DB 三份真值段互相打架,续发 7/18 收敛执法日报

## 内容
用户问"回归 compass 本身能力,价值如何"→ 按铁律不复述文档,实跑八探针坐实:
1) convergence 记分牌(ssh cloud→:8000):income 703 与 7/15 持平=近3天零增长,揭穿"income 自动持续涨"陈旧叙事。live=703/67/60-of-67。
2) ssot_consistency(141040c)实跑:承重锚两文件三 repo 全漂移。核心发现=三份"单一真相"真值段互相打架:live-DB 67/60 vs core 65/58 vs v5 66/59(都落后 live);且 core 说题池枯竭"仍在"、v5 说"已缓解"直接矛盾(各对一半:mint-skip 已落但题池空)。
3) drift_check 有用但幻觉了 3 个不存在的锚文件名(anchor_user_strategic_compass.md 等 glob 证不存在)——先证伪探针铁律逮到。
4) governance_audit(14d/132文件)0 假闭环。5) profile 30d/1229session 漂移 1220green。6) session_search 挖出前例"能力被陈旧文档咬"=复发模式,今日我又中一次(开局用陈旧副本报 delivery 0/11)。

关键洞见(非显然):点时刻同步合约会"到期即过期"——SSOT 是连续病,治它靠 141040c 连续探针 gating recall + canonical 改动自动传播,不是重开点合约。
已做(in-turf):compass 副本 LOOP_STATE 07-15→07-18(c4ef94f);7/18 收敛执法日报(fe4d64f);ingest 亮牌进 v5。
待他框:v5 同步副本+丢 11 题旧目标;CHARTER 三方漂移待 canonical(compass memory)持有者裁。
turf 诚实:本会话前段我一直在产 BioMysteryBench 生物题=FDE 造B turf,非 compass 存B turf(§0-B 四尺度)。用户"回归 compass 本身能力"是对的纠偏。
