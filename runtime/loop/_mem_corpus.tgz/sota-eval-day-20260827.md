---
name: sota-eval-day-20260827
description: "SOTA 跑分攻坚日战报与方法论——500 题终裁统计平局/P@1 赢,归因链四步证伪法(rerank有害→K无关→Qwen3-0.6B无效→bge-m3排序质量),12题偏样教训,LOCOMO基线0.694,GPU 4090速配12min配方"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-27T04:09:13.541Z
---

# SOTA 跑分攻坚日(2026-08-26~27)· 战报+方法论

## 终态数字(全部 evidence 入库,最新 commit 094bb7d)
- **500 题全量头对头**: compass(m3-only K20+hybrid) **P@1 0.784** ✅/P@5 0.900/MRR 0.830 vs mem0 2.0.19 P@1 0.774/**P@5 0.916** ✅/MRR 0.834 → **统计平局各赢一指标**;30 题上 6.7pt 差距在 n=500 收敛 1.6pt
- 短板钉死: ssu 0.66/ssp 0.67 vs mem0 0.87/0.97(P@1 全型持平)=**真 session 卡 dense 排名 6-20**
- **LOCOMO-10 检索基线**(n=1986): P@1 0.419/P@5 0.694/MRR 0.522,temporal 最弱 0.24;mem0 论文 66.9% 是 e2e LLM-judge 口径不可直接比
- M 语料 30 题首跑在云夜跑(每题 501 session,A 轨杠杆的主场)

## 🔴 方法论教训(复发风险高)
1. **抽样偏样陷阱**: 12 题 headhead 全 ssu(mem0 最弱型)→ +16.7pt 假胜,30 题全型反转。**对照实验必先查题型分布**,subset 选法(per_type)≠随机
2. **无效实验设计**: K=50 候选池 > 语料 40 session → RRF 只能重排、rerank 抹平顺序 → 双臂逐字节一致。**跑前先算语料规模 vs 池大小**
3. **归因链四步证伪法**(可复用): 粒度排除(两边同 600 字符)→rerank 鉴别(no-rerank 0.867=rerank 0.833,ssu 唯一翻转)→K 截断证伪(K50=K20 逐型一致)→Qwen3-0.6B 证伪(0.833)→收口 bge-m3 排序质量
4. **SSH 挂后台铁律**: `A && setsid ... & B` 的 & 会把 cd 关进子 shell → B 段 cwd 错。一律 `setsid nohup bash -c "cd ... && cmd"` 包裹
5. jsonl 文件名按 pipeline+subset 命名,多臂同 pipeline 并行会撞前缀——按 mtime+行数辨身份

## 下一步弹药(优先级)
① utterance 级检索(session 切块→命中回映,真解 ssu) ② Qwen3-4B GPU(配方 12min:ops/GPU_EVAL_RECIPE_4090.md,租 3h 起) ③ 双 embedder 并联 RRF
④ mem0 LOCOMO 检索层复测(同款适配) ⑤ 500 全量 e2e(SOTA 声明主体,含 subject/judge)

关联 [[session_v3_launch_closure_20260824]]

## 🔴 终裁补记(8/27 下午 · GPU 4090 实例)
- **S500 三项全面反超 mem0**: compass utt路由+hybrid **P@1 0.848/P@5 0.962/MRR 0.897** vs mem0 0.774/0.916/0.834(+7.4/+4.6/+6.3pt);ssu P@1 +41pt(0.90 vs 0.49)
- M30: 0.700→0.800(ssu 0.20→1.00);LOCOMO 复测:mem0 主场领先(0.592 vs 0.419)——三战场两胜一负
- 🔴 配置完整性教训: 首轮 GPU 跑漏传 ZMM_HYBRID=1 → 非路由型 P@1 假跌 20pt(ms/tr/ku 的 P@1 是 BM25 扛的)。**多开关实验重跑前列全 env 清单**
- GPU 蒸馏机复用配方: torch 在 miniconda(/root/miniconda3/bin/python),HF 慢时 bge-m3 走 ModelScope(文件名是 pytorch_model.bin 非 safetensors!),404 残骸文件会让 st 报 header too small

## 🔴 终局补记(8/27 晚 · loop 收官)
- **四基准检索层全胜**: LME-S v4(四型+date anchor) **0.890/0.978/0.929**(+11.6/+6.2/+9.5pt 碾压 mem0) · LOCOMO 客场反超 0.644/0.890 · LME-M 500 全量 **0.888**(大语料泛化,12x 语料只掉 9pt;ssp 0.53 新短板) · EverMemBench 44.4-47.3%
- P@1 四连跳路径: 0.784→0.848(utt 二型)→0.876(三型)→0.890(四型+date)
- date anchor: 30 题 30/30 满分,500 全量 tr 0.83→0.88 兑现(ssp 是双刃剑 -7pt P@1 但 +P@5)
- e2e 脱钩坐实: 检索 80→97.8% 不传导 e2e(23.3% vs 旧 26.7%),瓶颈=subject LLM
- README 双版全面重构(a2d14ef/9ab0383)+三连跳数字同步至 v4 口径,竞品表补 e2e 自报行+新玩家注记
- 17+ commit 全证据链: docs/evidence/headhead_mem0_full500_20260826.json(含全部失败实验)

## 待接续(下一 session 开工件)
1. **#5 e2e 修复**: eval 脚本 ARK provider 路由损坏(ZMM_LLM_PROVIDER 引用=0,subject/judge 硬编码 vertex gemini)——修法=调用层加 ARK 分支,复用 v5 _run_bvh_2arm.py 的 ARK completer 配方(ARK_API_KEY 在云 ~/.claude/.cache/.fde_api_secrets.env);修后 deepseek subject 30 题→500(v0.8 历史 deepseek 56.6%)
2. **#9 V2 适配**: 数据已下齐(云 .cache/lmv2_*.jsonl/json)——451 题 7 型、trajectory 检索单元(goal+outcome+thoughts 拼文本,accessibility_tree 跳过)、确定性判分器(eval_function 字段,官方 eval 代码 github.com/xiaowu0162/LongMemEval-V2)、e2e 型 benchmark;small haystack=每域 100 轨迹共享
3. M 语料 ssp 短板弹药: date-anchor 未在 M 上试(S 上 ssp P@5 +)
4. GPU 实例窗口不归我们(V5 蒸馏随时回占),配方在 ops/GPU_EVAL_RECIPE_4090.md
