---
name: d13-judge-retry-verdict-20260831
description: "d13 刀3 定案(8/31):LoRA 检索增强双域未过门路线关闭,d12 现役·doubao judge token 预算陷阱(4096 被 reasoning 吃满=系统性压0)·上游源码 GitHub 直拉省租机·双进程并行写文件事故教训"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-31T11:52:29.047Z
---

# d13 judge-retry 定案(2026-08-31 · commit 2ddb649)

**结论:刀3(LoRA 检索增强)全量验证双域未过门 → 路线关闭定案,d12 检索栈维持现役。**
ent 0.3081→**0.4076**(86/211,+0.46pt vs d12 0.403)· web 0.2875→**0.3667**(88/240,持平)· 门线 d12+5pt 双落。重判 100 题(ent40+web60)成功率 100%,max 合并只升不降。全文 `vtf/_compass_lmev2_out/d13/D13_FIXATION_20260831.md` 定案区块。

## 三条可复用技法

1. **doubao reasoning judge token 预算陷阱**:judge 配置 `reasoning_effort=medium + max_completion_tokens=4096` 时,难判断题 reasoning 吃满全部预算 → `content=''`(finish_reason=length)→ 记 0。**零分集中在难题 = 系统性偏 0 的有偏估计**,重试无效(结构性非瞬时)。修复 = 放开判断空间:low + 16384。判 LLM judge 大面积 empty content 先查这个,别当限流。
2. **"源码只在保留盘"先查上游官方 repo**:judge prompt 抢救原地解决——`xiaowu0162/LongMemEval-V2`(GitHub)原版 `evaluation/qa_eval_metrics.py` 含全套 checker,本地 patch 证实不改 prompt → 直接 import 上游模块调 checker = 管线同款结构性保证,省掉保留盘租机。**抢救类任务先 grep 上游**。
3. **后台任务"stopped 无完成记录"≠进程死**:上轮重判进程实际存活,与新进程并行写同一 results 文件(22 题重复判分)。**续跑前先查进程表**(powershell Get-CimInstance 按 CommandLine 匹配),结果文件合并每题取首次(时间最早,无选择偏差)。本次重复判分一致率 19/22=86% 意外成为 judge 稳定性证据。

## 敏感性检验口径(定案鲁棒性)

3 个分歧题即使全部反向翻转:ent ≤0.417 / web ≤0.375,均远低于门线 → 定案不变。双进程事故不影响结论。

关联 [[lmev2-three-knives-tuning-20260830]] [[gpu-651799-expiry-incident-20260831]] [[feedback-ark-coding-plan-not-metered-api]]
