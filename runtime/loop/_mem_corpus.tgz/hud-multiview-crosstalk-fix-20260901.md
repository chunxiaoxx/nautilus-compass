---
name: hud-multiview-crosstalk-fix-20260901
description: "HUD statusline 多窗口串台修复(v3.0.11·commit 2a359aa):claude-hud 段缓存曾全局单份不带 cwd 键,4 窗口互相覆盖=目录/仓库显示混乱+节流窗内空段;修=per-cwd 分桶+独立节流+md5 稳定 hash"
metadata:
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-01T15:51:09.226Z
---

# HUD statusline 多窗口串台修复(2026-09-01 · v3.0.11)

用户报"底部 HUD 显示的工作目录和仓库混乱、信息不齐全"。根因(`compass_hud_wrapper.py` 的 claude-hud 段):

1. **串台**:`hud_out_cache.txt` 全局单份、不带 cwd 键——用户同时开 4 个 Claude Code 窗口(compass/v5/core/flywheel 实测),各窗渲染互相覆盖缓存 → A 窗口显示 B 窗口的 repo/目录/分支 = "混乱"。
2. **缺段**:60s 全局 spawn 节流 + 30s 缓存门槛——缓存过期但节流未到时 hud 段整个消失 = "信息不齐全"。

修复(v3.0.11 · commit 2a359aa):
- 缓存按 cwd **分桶**:`{cwd: {ts, hud}}`,各窗各存各的;旧单份格式自动废弃重建。
- 节流 **per-cwd** 独立(`.last_spawn.<md5(cwd)[:8]>`),不再互抢名额。
- ⚠️ gotcha:文件名里的 hash 必须用 `hashlib.md5`——Python `str hash()` 跨进程随机化(PYTHONHASHSEED),同一 cwd 每个进程算出不同值,文件名会漂移。
- `.in` 中转文件同按 cwd 分(消 spawn 竞态)。

**验证**:4 个真实窗口的桶内容各归各、与键一致、零串台;双 cwd 冷启动各自独立填充。注意:冷键首渲染只有 🧭 段(claude-hud 段后台 ~4s 后填充)属预期。

关联 [[daemon-auth-and-hf-offline-20260901]] · [[compass-daemon-pylibs-rootcause-20260830]]
