---
name: bc1-launch-eve-20260926
description: BC1 发布前夜 31h 会话主 log——mem0 三臂对照/判因两轮勘误/战略总纲/五件批/子进程配方
metadata: 
  node_type: memory
  type: project
  originSessionId: 09bcfcba-392a-4334-9087-6ea8f23b88f4
  modified: 2026-09-26T10:13:23.524Z
fact_status: inferred
---

2026-09-25 17:00 → 9/26 晚 31 小时会话(BC1 T-1 发布前夜),32 轮 loop 记录:

**主战果**
- mem0 三臂对照:direct 16/18 / 默认 11/18 / 关压缩(infer=False) 18/18——**写入语义压缩=丢分元凶的因果证据(+7)**;给社区修复=审计场景关压缩;发布页+中文稿升级三臂版
- T3 首个外部 mini 完约:独立 claude 进程复算判 RED→抓 6 处转写错→勘误→交付(issuecomment-5844451314)
- τ-bench 判因 29 题:参数值级 16(支付政策违反 4)/结果传达失败 5/漏多混合 7——靶向题四类 9/29 出卷
- 战略总纲两版(d6df73f4→788c78f9):BC1 降格组件/Assay=组织唯一商业面/裁判位空位/Jev 三层+Laya 四件融合
- 用户五件批:Assay 命名/知乎渠道/TypeSafe proof 立项/新会话发布/开户
- 向量对拍:bge-m3 不换(另档);执法器自签名+误报三态账;宪法判例一(禅心自指)

**可复用配方**
- 子进程 claude(独立复算员):`env -u *_PROXY claude -p "<指令>" --model sonnet --dangerously-skip-permissions`——**必须清 socks 代理+显式 model**(Happy 的 GLM env 会污染,报 unrecognized_model 但 fallback 可用)
- curl 直抓竞品官网=绕过搜索配额的调研通道(WebFetch 被企业策略挡时)
- MiKTeX 中文:用 ctex 包(非 CJKutf8,后者缺字体全 ￿)
- 飞书发文件:scripts/feishu_send_file.py(现成,chats→send 两步)

**红灯教训(复发模式)**
- **机械判因必须覆盖判分器全部判定门**:τ-bench 两道门(终态 hash+outputs 答案串),只验一门→5 题误判"评测器嫌疑",v5 复核推翻→实为"结果传达失败"(做对没说对)
- 判分器副作用:verify_bc1 每跑重写 scorecard_public.json 正本——快照恢复防护必须做(两处管线已加)
- 函件地址簿:daily→vc_daily 正名前 4 函沉底(862 因此 P1 无回音)——发函前核地址存在
- qdrant_local 运行时库勿入 git(目录级 add 误吞 61 文件,已清+ignore)

相关:[[t3-miniclaim-20260924]] [[emb-bakeoff-bge-stays-20260925]] [[minimax-coding-plan-provider]] [[bc1-and-loop-day-20260923]]
