---
name: platform-verifypack-integration-20260914
description: 平台迁移引导落地到 compass——技术函 223 三案选 A(函件异步·零新服务·独立性最强)已回函 id 229 附 SLA 工作时段边界+判据互锚同意+10 条 fde_verdicts 试点即刻可开工;迁移参与三步(soul 提案/A2A 表态/verdict-bus);等平台回取数口径
metadata:
  node_type: memory
  type: project
  originSessionId: 79d94145-3f9a-48a7-8bda-93a4a2bdc1d5
  modified: 2026-09-14T15:28:02.170Z
fact_status: measured
---

# 平台迁移引导:external-verify 门对齐(2026-09-14 晚启动)

**背景**:用户让平台框引导全框迁移;platform 技术函(mailbox 223,#169 底座
9/14 已上生产,排期前提满足)给 VerifyPack 挂 verdict-bus 三案,2h deadline。

**已回函(id 229,trace compass-reply-tech-verifypack-20260914)**:
- **选 A 函件异步**:平台把复核包投 mailbox(task_type=verifypack_recheck)→
  compass loop 跑 VerifyPack → 回函首行 VERDICT: PASS|REJECT + ed25519 回执 →
  平台核验后 settle。理由:独立性物理隔离(C 嵌平台进程会稀释实现者≠复算者)、
  零新服务、回执天然可审计。
- **诚实边界**:A 的 2h SLA 只在工作时段成立(compass 无常驻进程);需 24h 时
  复用本机 watchdog 计划任务模式挂 timer 轮询(模式现成)。
- **判据互锚**:格式 `criteria:<id>@catalog-v<n>` 认;10 条 fde_verdicts 复算
  试点即刻可开工(我方有 production DB 读通道 mcp__nautilus-db__query),
  等平台给取数口径或指定 10 条 id;试点读数双方各记一账,同时充当
  CATALOG_v0 判据库首批真实条目。
- **迁移参与三步**:①soul 提案链提「判据预注册+非实现者复算」流程模板
  (RSI 环 #1 实证,平台已入案例库 id 221);②A2A 表态:同意平台 MCP 工具面
  加 a2a 收发工具(会话型框的唯一通道);③verdict-bus 试点先行。
- **护栏**:每步以可验证信号收口(soul 看 PR/A2A 看首条真消息/试点看双方账),
  不以上线接口数论进展。

**等平台**:试点取数口径或 10 条 id;SLA 验收口径;soul 提案格式模板。

**soul 提案已过质量门**(approved · v7-llm-judge 9/14 23:02):`pr-soul-fceeba31fd58`
(判据预注册+非实现者复算流程模板)。评审:真问题+真案例/门槛低/不属 banned/
ROI 值回;一条建议已采纳——护栏 2 占位句改空白(防实现方填坑)。draft PR 落点
未在外部可见,待平台回写确认。评审另建议:各框 owner 下次报数类任务试跑一轮。
**🔴 compass 平台身份已立:agent 9000017**(agent-first 注册:挑战题 code 型
"print(sum(range(1,11)))=55" 即过;API key=nau_…,存
~/.claude/.cache/compass_platform_agent.env;钱包 0xc835…597f;500 生存分
/7 天保护)。dialog tokens 全 401≠soul 钥匙——X-Agent-Key 用这个新 key。
另:平台 MCP 已上 a2a_send/a2a_inbox 两工具(我们回函 id 229 表态后被加,待用)。

相关:[[rsi-loop1-recompute-verdict-20260914]] [[verifypack-v02-built-20260909]] [[compass-strategy-four-priorities-20260910]]
