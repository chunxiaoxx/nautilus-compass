---
name: gpu-651799-expiry-incident-20260831
description: GPU 651799 8/31 停机事故全案+续费通道真相(renew_instance API 一直可用·参数=Container_name)·新实例实测 652509/lyg0063 2080Ti 已续至 9/1 14:15·web 240/240+ent166+V5 双 adapter 全部固化·d13 ent 211 题重跑中
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-31T02:32:00.094Z
---

# GPU 651799 到期事故(2026-08-31 02:42)+ 处置完案

**经过**:实例 651799(4090PLUS,lyg0245)自动续费失败——账户余额 52.17 元 < 日租金 63.30 元(缺 11.13)。02:42:18 到期 Status=8 停机,当时 d13 评测 web 240/240 已完成、ent 166/211。SSH 即断。

## 🔑 续费通道真相(2026-08-31 10:20 实测·修正早前错误认知)

- **API 续费端点一直存在**:`POST /openapi/v2/instance/renew_instance`,参数 `{'instance_name': <Container_name>, 'unit': 'day', 'pack_time': '1'}`(ai_galaxy_compute SDK 的 `client.call()` 直调;**instance_name 用列表项的 `Container_name` 字段**,不是数字 Id——用 Id 报 no row found)。
- 651799 当时 04:13 报 "no row found" **不是端点关闭,是实例记录已被平台摘除**(停机+自动续费失败→进释放流程后 Container 没了,无从续起)。**教训修正:到期前(状态仍 Status=1)API 续费随时可行**——当时应立即手动续费而不是等自动续费重试。
- 探测端点是否存在:用 `instance_name='nonexistent_probe_xyz'` 试调,报 "no row found"=端点在,HTTP_404=端点不在。零风险。
- 成功实证(652509):续 1 天扣 21.90(2080Ti 日租),Due_time 精确 +24h,余额 46.40→24.50。
- 平台自动续费(InstanceAutorenew)与手动续费独立;到期时间字段:列表项 `Due_time`(unix)+ `InstanceAutorenew.NextCheckAt`(自动检查时刻)。

## 新实例(用户重租,实测勘误)

- **实测 Id=652509 · lyg0063 · RTX 2080 Ti 11G**(早记 "650640/lyg1116" 有误,以此为准)· js1.blockelite.cn:17332 · Due_time 已续至 **2026-09-01 14:15** · **自动续费仍开着(SubscribeStatus=1,每日 13:15 检查扣 ~21.9)——d13 ent 完成拉回后应退租或提醒用户关自动续费,防止空扣**。
- 镜像=8/30 深夜系统盘快照,带回了:knife3/bge-m3-lmev2(2.2G)·LongMemEval-V2 代码·cfg·ark.env/judge.env·旧 d13 产物(web 全量+ent 166)·**V5 两个 adapter(dpo_out_c+distill7b_out 各 78M)**;数据盘 /root/data 是空新盘(外挂盘不随镜像走)。

## 已固化资产(全部双保险)

- d13 web 域 `vtf/_compass_lmev2_out/d13/compass_web_small/`(240/240 全判分,aggregated overall_full_set=**0.2833** vs d12 0.367 = **-8.4pt,刀3 LoRA 检索器 web 域 NEGATIVE**,预期 +8-12pt 落空;分型 procedure 64.3%/gotchas 66.7% 好,static 16.7%/dynamic 11.8% 崩,abstention 20.8% 回落)。confound 已排除(d12 原版 bge-m3,d13 LoRA 版,零混线)。commit **37aac93**。
- **V5 双 adapter 权重**:`vtf/_rescue_652509/v5_adapters.tar.gz`(146,650,826 B,sha256 `9942ae44e4c60720de2c702c7f0e287304712f782a59fc4ceb075c9ba612af70` 与远端一致;18 分片 readfile 拉回合并;含 dpo_out_c+distill7b_out 各 adapter_model.safetensors)。不入 git(体积),本地+镜像双份。
- ent 旧 166 行快照 `vtf/_compass_lmev2_out/d13/ent166_snapshot.jsonl` + 远端 /root/ent166_snapshot.jsonl。
- ⚠️ ent 题数口径:**实测 211 题**(runtime materialized+进度条 x/211);flywheel 口径 192 有误,判读以 211 为准。

## d13 ent 重跑(进行中,652509)

- 8/31 ~10:00 点火,nohup 全量 211 题(命令见 session 记录;judge=doubao-seed-2-0-pro-260215 走 coding plan 端点)。速率波动 ~64s-5min/题(judge-retry "empty response" 三连败频发拖累;**"attempt 3/3 failed" 的题判分处理方式待最终统计披露**)。预计 8/31 深夜~9/1 晨出全量,09-01 14:15 到期覆盖充足。
- 完成后:拉回 ent aggregated+per_question(211)→ d13 完整判定(两域+预注册判据+批次披露:ent=8/31 重跑批次,web=8/30 批次)→ 更新 GOAL_SSOT N5 → commit → 通知可退租。

**教训**:①到期前 24h 无监控告警(supervisor 应加 due_time 探针+余额<日租预警;发现时若 Status 仍活,立即 API 手动续费,勿信自动续费会重试)②大产物随完成即拉回 ③跨框共用 GPU 账户余额监控是组织级盲区。

关联 [[gpu-instance-reuse-not-rent]] [[lmev2-three-knives-tuning-20260830]]
