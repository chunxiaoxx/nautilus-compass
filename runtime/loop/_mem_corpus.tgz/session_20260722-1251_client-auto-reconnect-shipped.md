---
name: client auto-reconnect shipped
description: MCPClient transparent reconnect + backoff
type: feature
concept: problem-solution
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# client auto-reconnect shipped

## 上下文
MCPClient transparent reconnect + backoff

## 内容
mcp_client.MCPClient wraps I/O errors (ConnectionReset / BrokenPipe / timeout) with exponential backoff reconnect and re-runs initialize before replaying the request. Hard failures like bad-token surface immediately as MCPClientError.
