---
name: e2e-context-fix-and-tr-diagnosis-20260828
description: e2e +30pt 定案(0.267→0.567)+tr 型根因(context 无日期)+GPU 机网络拓扑(直连 HF 唯一快路)
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-28T11:53:35.505Z
---

2026-08-28 SOTA 冲刺日续:三线并进全部落地。

**e2e context 修复定案**:30 题配对同判据(doubao subject×glm judge) **0.267→0.567(+30pt,2.13×)**。根因=600 字符 context 截断切掉答案 turn;修复=四型 utterance context+anchor_all+reranker context 重排。分型:ssu 0→1.00/ssa 0→0.80/ms 0.6→0.8/ssp 持平/ku 0.4→0.2(噪声)/**tr 0→0(新短板)**。evidence `docs/evidence/e2e_context_fix_20260828.json`。

**tr 型根因诊断**(jsonl 逐题看 model_answer):模型明说 "no record of the date" 而检索命中全对——**utterance context 只标 Session 序号不带日期**,时序问题无日期可算。修复一行:`build_ssu_context(dates=...)` chunk 头加 YYYY-MM-DD(commit d33f7fe)。500 全量 4 分片已带此修复重启。

**GPU 机(智星云)网络拓扑**(血泪 5 试):pypi.org 被墙 SSL 握手失败→清华源;ModelScope 限速 3-6MB/s 后停滞;hf-mirror xet 协议 401(HF_HUB_DISABLE_XET=1 才走 mirror 代理)+CDN 超时;cloud→GPU 公网 77KB/s(不可行);**huggingface.co 直连 32MB/s 是唯一快路**(js1/js3 机房 github/HF 都通,别惯性套 mirror)。cloud 直连 HF 40MB/s(cloud 中转无用武之地)。

**操作教训**:pkill -f 会自匹配 ssh exec 的命令行(又一次);paramiko exec 含 nohup 后台链时 channel 不 EOF 导致本地挂起(启动与查询分开发);MSYS 路径转换吃掉 remote 绝对路径参数(MSYS2_ARG_CONV_EXCL=*)。

**进行中**:GPU 4090PLUS 48G 部署 LME-V2(vllm reader Qwen3.5-9B+compass_chunk_hybrid 后端已 smoke OK);e2e 500 全量 cloud 4 分片(~25h,4 核 724s/题慢,可搬 GPU);LME-V2 judge 可换 newapi glm(evaluator_base_url 官方参数)。

**2026-08-29 终版**:e2e 500 全量定案 **42.6%(213/500)**——ssu 95.7/ssp 80.0/ku 73.1(近天花板)vs ssa 25.0/ms 22.6/tr 15.8(跨 session 聚合=公开短板,答案散 3+ session>3 utterance context)。30 题轮 ms/ssa "0.8"=n=5 小样本噪声。tr 15.8=日期修复(原 0.000)首证。evidence `docs/evidence/e2e_500_full_20260829.json` · raw 留 GPU /root/e2e_results_500.tar.gz · 落地页生产已上(commit 7c9f789)。workbuddy 反馈包 v1 全消化(P0-P3,v3.1.0 tag,44a9e52)。
