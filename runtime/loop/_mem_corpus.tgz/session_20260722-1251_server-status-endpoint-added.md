---
name: server/status endpoint added
description: operator dashboard · thread-safe counters
type: feature
concept: pattern
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# server/status endpoint added

## 上下文
operator dashboard · thread-safe counters

## 内容
Unauthenticated aggregates only: active/total connections, auth_failures, messages_handled, uptime_seconds. Backed by a _threading.Lock-guarded dict. TCP loop bumps per-conn / per-msg.
