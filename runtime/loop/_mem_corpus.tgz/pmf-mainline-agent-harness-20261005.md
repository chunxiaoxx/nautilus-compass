---
name: pmf-mainline-agent-harness-20261005
description: 用户拍板 PMF 主线——compass=unipat 在 agent 领域:harness 基准评测+对比测试+榜单+卖数据卖轨迹+归因提升;飞轮=具身侧 unipat
metadata: 
  node_type: memory
  type: project
  originSessionId: c62a754e-c031-437d-a37a-0d217fbf3144
  modified: 2026-10-04T15:55:39.129Z
fact_status: inferred
---

2026-10-05 用户拍板(与 [[architecture-mainline-20261004]] 并行,互为商业/架构两面):**compass 对话框 = unipat 模式在 agent 领域的直接工作;飞轮对话框 = 具身智能数据领域的 unipat。紧紧围绕此主线实现 PMF。**

四件事:①纳入主流基准评测集+自建基准集;②测自己也对比测各 harness+发榜单+对比分析;③向 agent 企业卖数据卖轨迹;④最重要的是知道如何提升 harness 解决问题的能力。

**Why:** 公式"智能=压缩×验证×因果倒置"的商业化形状=评测产生错误信号→归因告诉厂商错在哪→判例/轨迹/基准把信号变成可复用资产。平台卖的不是分数,是"错误信号的可执行形式"。

**How to apply:** 正本 docs/soul/mainline_architecture_20261004.md 第五节(PMF 四件事×现役资产映射+缺口:榜单未开张/轨迹售卖未建/归因报告未制式化)。执行纪律:测量线免费+装订线收费不混淆;自家参与 compare 同规受测;榜单开张前必先预注册判据。首批被测画像=VISTA(visual harness,arXiv 2610.02200,RHAE=100)。**首件已落地(10/5 用户拍)**:榜单开张判据 v1(docs/metering/LEADERBOARD_PREREG_CRITERIA_V1_20261005.md,sha16=282a268ca84ecf72,不变式六条+纳入五门+双轨 A 汇编/B 认证),知会函 3117;下件=A 轨首期数据面(3-5 个可寻址成绩条目过五门)。
