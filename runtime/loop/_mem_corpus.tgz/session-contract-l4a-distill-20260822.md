---
name: session-contract-l4a-distill-20260822
description: "✅CONSUMED 8/25 · compass 派发 · L4a 权重蒸馏首跑合约(T4+qwen QLoRA,正负皆是产出)· compass 独立验收 PROVEN(单族弱边界)"
metadata: 
  node_type: memory
  contracts: 
    - contract_id: cnt_l4a_distill_20260822
      from: compass-dialog
      to: nautilus-v5-claude-code
      action: T4 上 qwen 小模型 QLoRA 蒸馏首跑:带溯源燃料 + held-out 前后对照 + 结果落档 TASK_L4A_distill_first_run.md
      due: 2026-08-29T22:00:00+08:00
      done_when: 蒸馏跑完 + 对照表产出 + compass 独立可复算(正负均可核销)
      why: "用户 8/22 拍板解除 A800 守势,大胆开工小心判读;战略 v2 §5-L4a"
      status: CONSUMED
      consumed_at: 2026-08-25
  type: feedback
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-30T04:47:12.398Z
---

# L4a 蒸馏首跑合约(2026-08-22 派 · 用户拍板)· ✅CONSUMED 8/25

- **核销依据(2026-08-30 补登 · 独立验证通过)**:蒸馏 v3 首跑 8/25 完成,compass 独立复算逐项一致——1.5B base 0/4·0/8 → distilled 4/4·8/8;7B 跨族 base 8/10 → adapter 9/10。证据押送 compass 仓 main `_v5_proof_deposit/`(commit 3536353,含 distill_v3/),n=3 双门抽查含同坏题复现。三态判定 **PROVEN(单族族内泛化/pass@5 口径弱边界)**。后续 v4/v5/d6 多轮扩展见 LOOP_STATE_SSOT 增量记录(混训配方负、修复类全线关闭、仅协议格式域存续)。
- 任务书:nautilus-v5/TASK_L4A_distill_first_run.md。
- 关键:燃料必须带溯源(薛美雪 A 类首条 + automint);对照协议不可省;Repair 也核销。
- 关联 [[convergence-state-snapshot-20260821]]。
- ⚠️ 账面备注:due 8/29 的逾期告警是状态未及时回写的假逾期——实际 8/25 已验收,SSOT 8/25 二次增量当时已写"合约已核销"。教训:验收完成即回写合约状态,不等下个 session。

