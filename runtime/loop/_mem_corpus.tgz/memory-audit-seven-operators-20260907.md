---
name: memory-audit-seven-operators-20260907
description: compass 七算子审计(9/7)——写无gate/读介质异构/选不挡错/合并无触发/组合缺位属实;两处修正(衰减在schema未在使用·gate在燃料线缺记忆线);三修复冻结至9/15窗口
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-07T14:52:35.924Z
---

compass 记忆系统七算子审计(2026-09-07,用户转来)评审定案:

**采纳(已 grep 核实属实)**:写●无记忆线 gate(错误记忆先入库)/读◐介质异构(符号写 md、连续读 BGE,结构被压平,top-k 固定)/选●最强但时间戳门槛假设新=对、drift 测人格不测事实正误/合并◐无触发器(单 SSOT 靠人记)/组合○[[链接]]是装饰非机制/评估◐无 per-memory 召回计数与采纳读数。

**两处修正(审计未见的仓内事实)**:
1. 「忘=有删除无衰减」→ 衰减机制在 schema:daemon ingest 原生 `tier(working/episodic/semantic/procedural)+decay_rate+forget_at`(v1.7.1)。真实病=机制在使用缺位(memory 写入不标 tier/decay)——修法是激活不是新建。
2. 「写入无 gate」→ fuel 管线有完整 QC 门(N2 周批 Gate B·control-先失败·14 天过期),缺位仅在 memory md 直写线——修法是把燃料线的门借过来。

**三个最高杠杆修复(冻结至 9/15 窗口执行,与旧入口退役同批动 daemon)**:
1. 写入 gate 前置:frontmatter `fact_status: measured|inferred|heard` + 写入纪律(纯纪律部分即刻内化:本人写 memory 起自觉标注,零代码)
2. 写入查重触发合并:新 memory 写入前 BGE 查重 cosine>0.9 → 触发合并/覆盖而非新建(改 daemon/recall.py)——同时机制化单 SSOT
3. 召回沿链一跳:recall 结果 [[name]] 自动展开一层不递归,把链接变机制(改 daemon)

**Why**: 审计判断正确但时机错位——防跑偏五钉 #3 功能面冻结(发布前 30h 动生产召回链路=用 9/8 发布赌重构);9/15 窗口本来就要动 daemon(退役),三修复合并进去一次改完一次验证。
**How to apply**: 9/15 退役 runbook 起草时把三修复列为同批项;日常写 memory 自觉标 measured/inferred(第 1 条纪律部分即刻生效)。相关:[[daemon-auth-and-hf-offline-20260901]] [[gmail-verify-production-20260906]]

**+理论上游(同日第二篇,判据库框架)**:七算子=写/读/选/合并/忘/组合/评估;核心命题「写地址空间决定遗忘命运」(灾难性遗忘=介质选型架构级必然)——position paper v2 头号素材(9/10 后迭代,发布前不动);四系统=ICL 寄存器/compass+Waddle 内存/SSI 磁盘/晋升管道=层间总线/评估算子=总线仲裁器,「行业各自造介质没人造总线」。两处精确化(我提):①ICL 非无门而是无状态门(softmax 前向内竞争不跨 episode);②compass「评估最前置」是四家相对(写侧无 gate),最前置的也只装了半个仲裁器。

**+综合分析五推进(同日第三轮)**:①方程补预算项 `Δ状态=f(新,旧,g)|预算`——ICL 不写=免费选项,与 write-path economics 接轨;②MMU 类比展开:9/15 三修复=dirty bit(fact_status)/去重页(查重合并)/prefetch(沿链一跳),修复清单升格架构叙事;③组合算子四家皆缺的机理=唯一需读取时引擎在场(运行时计算非存储操作),Waddle 做出因架构定义里写了 LLM 当引擎;修复#3=脚手架非组合本身;④可证伪判据须双假设:分层晋升 vs 重训/蒸馏即记忆(SSI 若成分层不需),2027 裁两者;⑤定位句候选「not another memory vendor — first productization of the arbitration layer」(介质红海/仲裁器空位;三实例=判分卫生学/drift/QC 门)→白皮书 v2。矛盾解:「评估最前置」vs「写入无 gate」=同一事实两面,修复清单本质=让产品配得上理论声明。
