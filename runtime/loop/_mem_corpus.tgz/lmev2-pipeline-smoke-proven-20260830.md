---
name: lmev2-pipeline-smoke-proven-20260830
description: LME-V2 评测管线 GPU 机全链路打通(六坑定案)——BGE 线程竞态须单 worker/newapi 审查拦截题干换 ARK judge/32k context 硬要求;续租一键复跑命令在 TRANSFER_RUNBOOK
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-29T22:15:58.767Z
---

# LME-V2 管线 smoke 全通(2026-08-30 · GPU 机 651799)

3 题烟测全绿:haystack 索引→memory 检索→reader 生成→judge 打分→aggregated_metrics.json 落盘。1.5B smoke 模型 0% 正确=预期(smoke 只验管线非分数)。正式 reader 全量 451 题待续租跑。

**三个复发级陷阱(跨 session 必读)**:
1. **BGE meta tensor 竞态**:torch 2.10+sentence-transformers 组合下,`SentenceTransformer` 构造在 ≥2 线程并发时 100% 报 `Cannot copy out of meta tensor`,主线程单发恒 OK。任何"多线程里懒加载 embedding 模型"的代码在此环境都要单线程化(`--prompt-workers 1`)。
2. **newapi 中转内容审查**:judge 端点 newapi.07211996.xyz 对 LME-V2 web 域题干(模拟 reddit 帖)返回 `Your request was blocked`(PermissionDeniedError);短文本过、实际题干稳定挂,机上/本机一致。**换 ARK doubao-seed-2-0-pro-260215 实测放行**。排查技法:同 key 同端点 curl 短文本 vs 实际内容对照。
3. **假完成形态**:vLLM max_model_len(16384) < harness max_tokens(20000) 时 reader 全 400 但 harness "Using empty response and continuing"→ Scoring 照样 3/3 全绿、0 分假完成。**看 aggregated_metrics 的 count_non_abstention 才算数**(=0 即 reader 全空)。

其它:vLLM 起服需 `apt install python3.10-dev`(triton 编 cuda_utils.c);openai SDK 需 ≥2.x 新版(PromptCacheOptions);48G 卡显存 vLLM 0.70 留 14G 给 bge-m3。

一键复跑命令全文:`vtf/TRANSFER_RUNBOOK.md` "LME-V2 管线 smoke 全通定案"节(commit d5 段)。关联 [[gpu-e2e-rootcause-chain-20260829]] [[gpu-instance-reuse-not-rent]]。
