---
name: aegis-compass-competitor-20260907
description: 竞品 Aegis Compass(9/7 用户发现)——coding agent 记忆+治理层 $20/mo·动作门最强/记忆门弱·定位句修正为「arbitrate what agents remember」·Compass 第三次撞名
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-07T15:06:14.253Z
---

竞品 Aegis Compass(aegisplatform.ai/compass/,2026-09-07 用户发现)调研定案:

**是什么**:coding agents(Claude Code/Cursor/Codex)的记忆与上下文层——episodic memory+26 语言活符号图+**治理三件套**(agent 加密身份/动作前 policy engine 挡写 .env·外传·越界 rm/防篡改审计链)+EU AI Act Art.14 合规。定价 Solo $20/mo(7 天试用)/Teams per-seat/企业可选自托管。早访问审核制(48h 回复)。

**七算子过秤**(框架首次实战):动作门 ●(policy+身份+一键暂停)、组合 ◐(符号图 call-chain=组合的图版,我们没有的实体底座)、评估 ◐(审计链=事后证据)、写/读未披露细节、合并/忘 ○。**零 benchmark、零判分卫生、云服务为主(本地只给企业)**。

**三个战略判断**:
1. 定位句修正:「first productization of arbitration layer」不成立——Aegis 已产品化**动作总线**仲裁器。我们的独占空位=**记忆总线**(什么记忆可信/晋升/拒绝:判分卫生学+QC 门+fact_status)。对句:**Aegis arbitrates what agents do; nautilus-compass arbitrates what agents remember.** → 白皮书 v2/position paper v2 核心对比轴。
2. 框架第三修正(反哺理论):「选」算子拆 **select-action(动作门) vs select-memory(记忆门)**——Aegis 前者强后者弱(policy 挡不住知识污染),我们相反(drift 动作门弱/记忆门全)。9/15 修复#1(fact_status 写入门)=补记忆门的关键子。
3. 市场验证+定价锚:agent memory+治理 $20/mo 有人买单(我们 Modified MIT 100 付费上限的市场参照);**Compass 第三次撞名**(CompassBench 上海AI Lab/CompassMem arXiv/Aegis Compass)——不改名,但对外一律 nautilus-compass 全名;评论区备关系澄清(零关系,同名不同层)。

**Why**: 发布前 30h 发现同类收费产品,影响定位叙事与评论区应答,不影响主帖叙事(他们零成绩零检索科学)。
**How to apply**: ①§6 应答模板已加 Aegis 条目;②position paper v2 竞品矩阵加一行;③对标定价决策(开放注册后)参考 $20/mo;④符号图组合能力=我们组合算子 roadmap 的候选(compose over code entities)。相关:[[memory-audit-seven-operators-20260907]] [[license-modified-mit-20260904]] [[benchmark-naming-licensing-20260902]]
