---
name: benchmark-naming-licensing-20260902
description: "自建基准(LME-V2 451题)对外发布立项 N6:命名两连撞(CompassBench=上海AI实验室·ATLAS=李飞飞WorldLabs 9/2发布)·候选 CompassMemBench/CompassMem·license 初审绿(webarena MIT/ServiceNow CC-BY-4.0)·T0T1T2 路线·判分卫生学协议已立"
metadata:
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-02T15:30:16.611Z
---

# 自建基准发布立项 N6(2026-09-02 · commit 4fe80d3)

## 命名定案:NautilusMem(2026-09-02 用户拍板 · 查重净)

四连撞史(实证,勿再踩):
- **CompassBench 已被占用**:上海 AI 实验室 OpenCompass 团队的 [CompassBench](https://github.com/open-compass/CompassBench)——同在评测领域,弃。
- **ATLAS 弃因**:李飞飞 World Labs **2026-09-02 当天**发布 Atlas(全模态空间智能世界模型),搜索淹没+归属错乱+蹭名嫌疑。
- **CompassMem 也被占用**:arXiv 2601.04726 的 event-centric 记忆框架(LoCoMo 上评测、被后续论文当 baseline),同域直接冲突。
- **chunxiaomem**:查重必净但国际传播性弱+个人名系统×个人名基准加重裁判观感;个人品牌留在作者署名位。
- **终选 NautilusMem**:我们自己的品牌(nautilus-compass 唯一 nautilus 命中),鹦鹉螺螺旋=记忆层层沉淀;查重净已验证。

## License 初审结论(发布包可含数据)

- webarena:代码 MIT(web-arena-x org)
- ServiceNow:数据集惯例 CC BY 4.0 + 代码 MIT(如 insight_bench)
- CC BY 4.0 允许改编再分发(带署名)→ 451 题可随包开源,发布包需 DATA_LICENSE 归属清单;终审要落到具体数据集的 LICENSE 文件。

## T0/T1/T2 路线(GOAL_SSOT N6 行)

- **T0 发布版**(9/12 与营销帖合流):命名+license 终审+协议定版+harvest 可安装+HF/GitHub 发布
- **T1 评测升级**(9-10 月):前瞻/反事实/任务落地/容量压力,451→~1k 题;前瞻题判分可程序化
- **T2 训练飞轮**(Q4):Fuel 出口(SFT 对=轨迹→gold 摘要卡;RL reward=判分器)+评测自举 demo=arXiv 骨架;与蒸馏线经验衔接(SFT 教协议格式/RL 教策略)
- 协议草案 `docs/compassbench/PROTOCOL.md`(judge 预算≥16384/双口径强制/成绩卡 config 节——全部源自亲踩坑)

## 用户方向意志(战略级)

- 自建基准不是负债是**定义权资产**:"agent 轨迹工作记忆"是公开基准空白(LongMemEval 等全是对话记忆)
- 升级方向带世界模型视角(记忆=状态压缩器,前瞻/反事实题测因果结构非表皮)+SFT/RL 飞轮(评测即造燃料)

关联 [[d14-abstention-verdict-20260902]] · [[lmev2-three-knives-tuning-20260830]]
