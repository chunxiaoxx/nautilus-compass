---
name: tribal-feishu-select-id
description: 
type: discovery
concept: pattern
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# tribal-feishu-select-id

## 上下文


## 内容
飞书 Bitable 单选字段改 options 时,必须把 API 返回的原对象带 id 透传(property.options 里每项保留服务器分配的 id),只有全新名字才从 max(existing id)+1 续新 id。只发 name 列表会被重建全部 id,所有既有行引用静默丢失(2026-06-12 实证事故)。
