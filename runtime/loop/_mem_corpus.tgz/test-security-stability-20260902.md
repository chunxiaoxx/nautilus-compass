---
name: test-security-stability-20260902
description: "9/2 测试+安全+稳定性专项:全量pytest复活(1581绿·mcp_durable 15失败=契约迁移非回归·tests/缺__init__坑)+漏网客户端#8(pytest探测器抓出)+auth_failed读数的pytest噪声陷阱+探针键名bug(scopes≠scope)+watchdog v3(auth探测段exit0顺序坑)+版本四处对齐3.1.1"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-02T05:27:22.981Z
---

# 测试+安全+稳定性专项(2026-09-02 · commits 0bfdb19/505efc3/4972b04)

## 1 · 全量 pytest 复活(四个月盲区 → 1581 绿)

- **tests/ 缺 `__init__.py` = 包导入全崩**:`from tests.eval_recall import x` 报 ModuleNotFoundError,3 个收集错误挡住全量。修复=建空 `tests/__init__.py`(+`tests/hooks/__init__.py`)。pytest 无包时只把 tests/ 本身入 sys.path,包式导入全挂。
- 孤儿测试(tests/hooks/test_inbound_select.py,被测 hook 已不存在)归档 `_archived_tests_20260902/` 带 README+复活条件。
- ⚠️ **pytest 的 exit code 经管道会被 tail 吃掉**:后台跑 `pytest | tail` 显示 exit 0 但实际 1 failed 20 次也可能发生——判红绿必看输出摘要行,不看退出码。

## 2 · mcp_durable 15 失败 = 契约迁移,非实现回归(考古定谳)

- 链条:8/24 `f01f9f0`(wire 剥顶层 `_eid`——CC 2.1 严格客户端见协议外字段即弃连)+ `b29d0f7`(云桥重构删 `_strip_eid_and_track`/`_inject_last_event_id`,换 v1.9 pending 模型)→ 测试没跟迁。
- **现行 v1.9 契约**(测试已钉):wire 帧无 `_eid`;断线零丢失=json-rpc id 追踪(note_request/note_reply/pending_lines);重连 `connect(replay=True)` 重放 init(重注 authToken)+**幂等只读静默重发**+**非幂等写回 -32603**(云端 ingest 无幂等键,盲重发=重复写入)。幂等重发后**留在 pending**(重发≠已答,note_reply 才清)。
- server 端 Last-Event-ID replay 代码仍在(桥不再依赖),replay 帧带原 `_eid` RAW 发出——resume_handshake 直连覆盖。
- 顺手提取 `_strip_top_level_eid()` 纯函数(原主循环内联段,测试性重构)。

## 3 · auth_failed 探测器两个陷阱

- **pytest 噪声**:测试套件含预期 DENY 用例,跑全量时 daemon.log 每秒 2-3 条 auth_failed 爆发——**时点与 pytest 运行窗完全重合**。定性前先对时点,勿当漏网客户端。
- **漏网客户端 #8**:repo 版 mcp_server.py `daemon_call` 连本地 9876 无 token(pytest 全量抓出;9/1 记录"repo 版连云端不需修"系误判——它 DAEMON_HOST=127.0.0.1)。已修,proof_of_recall 5 绿。

## 4 · 探针键名 bug(scopes ≠ scope)

- 云端 tokens.json 结构:`{"scopes": [...]}`(复数)。探针 `v.get('scope','FULL')` 缺键返默认值 FULL → 把收窄完好误报成 10 个全权。
- 教训:**缺键默认值 = 未验证即断言最坏/最好**。探针遇缺键应报 UNKNOWN,不设兜底断言值。与"红灯先证伪自己"同源。

## 5 · watchdog v3 的 exit 0 顺序坑

- 原脚本段 2 成功路径 `if (Test-Forward) {...; exit 0}` 提前退出 → 尾部新段永远不跑。且**不能简单删 exit 0**:删了成功路径会掉进失败分支(去拉起远程+重生隧道)。
- 正解:探测段放段 2 **之前**。计划任务直接指向 repo 版 `ops/compass_forward_watchdog.ps1`,改 repo 即生效无需同步。

## 6 · 版本四处对齐(3.1.1)

- 漂移史:pyproject/package.json=3.0.1 · server=3.1.0(8/29 只改一处造新漂移) · plugin.json=2.3.0。
- 改版本必四处齐改:pyproject.toml / package.json / .claude-plugin/plugin.json / mcp_server.py SERVER_VERSION(有 test_version_sync 守着,改前跑它)。

关联 [[daemon-auth-and-hf-offline-20260901]] · [[hud-multiview-crosstalk-fix-20260901]]
