---
name: Compass 独立裁判探针 — income 188 从 verdict 独立复现
description: "psql creds 失败"是伪命题,compass_sub 能读生产 DB;income 188 = sum(round(score)) of external_verified∧pass;引擎 cycle 停摆一个月被独立坐实
type: discovery
concept: 独立验证优于自报 — 从 verdict 行复现 income,不信 agent 自报
drift: green
source_session: C--Users-chunx-Projects-nautilus-compass/00b61b64-e3fc-417e-8ef1-f820f523a60e.jsonl
date: 2026-07-07
tags: [nautilus-compass, probe, grounding, postgres, ssh-tunnel, income, verdict, fde, mcp, tdd, anti-theater]
related: [[session_554f5d90_compass_daemon_p0]], [[session_37d970aa_guoshu_rebzj_drift]]
reinforce_count: 26
---
# Compass 独立裁判探针 — income 188 从 verdict 独立复现

## 上下文
Goal:让已跑通一次的收敛闭环(7/6 income 98)从 one-off → 自持可重复。7/7 fresh,agent 自审揭穿剧场:`fde_claim_produce` 是 fake-success 工厂(1233 actions / 0 settled;cron 220+ cycle 0 执行)。compass ① = 拿回查 DB/verdict/income 真值的探针能力(现有 `liveness_audit.py` 三探针全查本地文件 = 瞎)。

## 关键发现
- **"psql creds 失败" 是伪命题(误诊平反)**:canonical 标 DB 连不上。实测 `compass_sub` 走 ssh-tunnel(SSH alias `cloud`)+ psycopg2 + secret 文件 `.soul_db_secret` → **连生产 `nautilus_production` OK**,之前报错只是 SQL 把整数 agent_id 传成字符串。连接配方在 `fde_verdict_reconcile.py`/`_poller.db_connection` 已现成实现。
- **另一条独立读路径**:`GET /api/platform/control-plane`(200,公开无需 token)返 `data.pulse`:external_verified_total=4、verdicts_total=3682/pass 3179、`last_cycle_at=2026-06-03`。verdict GET 被拒也是伪命题。
- **income 188 可独立复现(核心交付)**:`sum(round(score))` of `external_verified ∧ overall_pass=True` 的正好 2 条 = JobShop round(97.6047)=98 + QAOA round(90.3195)=90 = **188 exact**。不信 agent 自报,直接从 verdict 行推。TSP 97.63 verified 但 overall_pass=False(Rejected 未铸)、gate-probe 未铸 —— 全对上 canonical C 口径。
- **"引擎停摆一个月/cron 0 执行" 是真的(剧场坐实)**:`engine_cycle_outcomes` last=2026-06-03,24h 内 0 cycle(总49);但 `agent_tool_calls` last=now、total 329320 → **agent 活着但空转**(调工具不落 cycle 不入 income)。
- **权限边界钉死**:compass_sub 可读 6 表(agent_tool_calls/agents/engine_cycle_outcomes/fde_verdicts/platform_improvement_proposals/poi_credit);`agent_survival`(income 总额)+ ledger 类 **permission denied** = 唯一真缺口。
- **MCP 502 是 server 端 upstream 挂**(`/compass-mcp/`=502 而 `/api/health`=200),apply 脚本只改 client 配置(已对)修不了。关键:**①③ 全程没用 MCP**,真值走 ssh-tunnel + control-plane,MCP 挂不阻塞独立裁判。

## 可复用技法
- **独立探针铁律:能复现的才算真值**。income 不读 agent 自报字段(`agent_survival.total_income`),从底层 verdict 行 `sum(round(score))` 重算 → 天然抗剧场/抗自报。
- **连接失败先逐环实测**(secret 有无 password → ssh alias 通不通 → psycopg2 装没装 → GRANT),别信 canonical 的"连不上"结论。多条读路径并探(DB + 公开 HTTP control-plane)。
- **TDD + effect 注入 fake conn/cursor**:探针模块 12/12→19/19,覆盖 GREEN/STALE/GAP/RED 分支,不依赖网络;完成后必 live 真连跑一次(verification-before-completion)。
- **诚实报 GAP 不假 GREEN**:agent_survival 无 grant 就报 GAP + needs GRANT + 回退 verdict-derived,exit≠0 是诚实的。
- **watermark-delta 语义**:"income 持续涨" ≠ 快照,给探针加 `record_and_diff_income` + `--watch`(记上次值报 delta);live 实测首跑 FIRST(记188)→次跑 FLAT(+0),真实反映引擎停摆无自产。
- **跨对话框合约通道(dogfood)**:向 platform-soul 请求 `agent_survival` GRANT,镜像既有 `contracts:` frontmatter 格式写 session memory,跑 contract.py scanner 验证被 surface(260文件9roots,当前唯一 outstanding)。

## 教训
- "1233 actions / 0 settled" 是自报剧场的教材:自报数字必须有独立探针背书才可信。
- backend `/api/health`=200 ≠ 探针能读真值;活着和可观测是两回事。

## 下一步
- 等 platform-soul 授 `agent_survival` GRANT 补 income 总额直读缺口。
- ③ 探针盯 income delta 的落点:不塞进 10s 契约的 `live_state_check.py`(探针需 ssh-tunnel >10s),独立 cron。
- 4 commit 未 push(按 R4);V5 turf 修 agent 执行管道(cron 真执行 + 动作真 settle)才谈自持增长。
