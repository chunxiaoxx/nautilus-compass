---
name: p1-host-migration-http-20260906
description: P1 宿主迁移 HTTP 直连 9/6 启动——4 dialog token 全绿·hr/fde 已切·platform/compass 被内部工具卡住·隧道 9/15 硬停
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-06T03:37:32.074Z
---

P1 旧入口退役(9/15)宿主迁移 9/6 执行记录:

**验证结论(全部实测)**:
- 4 个宿主 dialog token(hr/compass/platform/fde)HTTP 直连 `https://compass.nautilus.social/mcp/` recall 全绿(HTTP 200)
- **行为等价**:TCP 桥(scope=user)与 HTTP(注入持有者)两侧都命中同一空间 `C--Users-chunx`——4 宿主共享空间是现状固有,迁移不引入混仓
- HTTP 面 tools/list=8 自助工具(drift_check/drift_history/feedback_log/ingest_obs/profile/recall/session_search/thread_recall);历史用量(工具漂移日志)只有 proof_of_impact×3 超出面外
- 协议配方:POST /mcp/ + `Authorization: Bearer cmp_…` + `Accept: application/json, text/event-stream`,JSON-RPC tools/call(probes.py 同款)

**已迁(全部完成)**:4 框 .mcp.json 全部切 HTTP——caishen-ai、nautilus-fde-phase3(上午)+ nautilus-core、nautilus-compass(视口开通后)。归档框 v5.archived 不动。

**视口开通(9/6 下午,commit ce456dc)**:卡点根因=`_scopes_from_value` 把 tokens.json 的语义 scopes list(9/1 收窄后 list 元素=tools.*/read:*/write:*)一律归一 `read:*/write:*`,洗掉 tools.* 标志→内部 token 被误判自助面。修复=list 元素全为语义串(startswith read:/write:/tools./resources. 或 ==admin)则原样采用。**连环坑两个**:①第一版判定 `":" in s` 被 `resources.read`(点号)绊倒,compass/platform 仍 8 面——语义串判定必须枚举已知前缀;②tokens.json 补 scopes:compass/platform dialog 缺 read:* 被 _check_scope 拒 recall,给两把补 `read:*`+`write:C--Users-chunx`(与 hr/fde 对齐)后通。**验证纪律**:recall 判据只看 JSON-RPC "result" 字段=假绿(HTTP 200 包 forbidden body),必须查 body 含 forbidden;最终三重复验全绿(4 dialog token tools=17+recall 真通+governance_audit 通 / 自助仍 8+直调拒+probes.py FOUR-GREEN / TCP 桥活会话 recall 正常)。tokens.json/文件备份:mcp_http_server.py.bak.pre_semantic_scopes_20260906、tokens.json.bak.pre_dialog_scopes_20260906。

**退役清单 9/15**:本地 9877 隧道(PID 查 ssh -L 9877)+ 18770→8770 隧道 + 云端 8770 服务本体 + 云端 compass-mcp-tcp.service。**隧道未杀**——活会话的 stdio 桥进程仍 ESTABLISHED 连着 9877,等会话自然重启;全部宿主已切 HTTP,9/15 可无痛停。

**Why**: 9/15 三个旧入口同日停,宿主不迁则 recall 全断;HR 桥 python3.13 vs python 的 SyntaxWarning 无害。
**How to apply**: 动宿主 MCP 配置前先跑 token×HTTP 实测脚本(模式在 /tmp/verify_dialog_tokens.py 思路);tools/list 面差异是迁移隐形杀手。相关:[[daemon-auth-and-hf-offline-20260901]] [[security-workbuddy-token-scoping-20260830]]
