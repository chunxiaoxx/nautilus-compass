---
name: judge-corpus-p2-baseline-20260930
description: "判分器语料1454+P2v1基线66.2%地板全链——judge自报三陷阱(is_correct复写/M2等价改写误伤/特征含被检输出作弊通道)/qid分组防泄漏切分/架构天花板定谳(冻结encoder+线性头≈语义匹配,85%需LoRA)"
metadata: 
  node_type: memory
  type: project
  originSessionId: e01698b5-ca0c-4d79-8423-11cb0e107d82
  modified: 2026-10-03T14:14:59.733Z
fact_status: inferred
---

2026-09-30 SSI×Jev 提案 P1→P2 一日全链:语料 labelled 52→**1454**,P2 v1 基线 66.2% 地板落地。

**语料四源**(tools/verdict_corpus_exporter.py,manifest 可溯):
- rejudge 500:双层复算升级(预注册 REJUDGE_RECOMPUTE_PREREG;J1 机械 M1 数值 0/85+J2 隔离盲判 48/50=96%)
- LME 官方规则 902(d12/d14 per_question:answer_gold+透明 eval_function,非 LLM 自报)
- BC1 36(v1 审计 13pass+5U 含 T12 真值错误金样本/v2 重考)+T3 盲评 8+F15 8
- 切分:qid 分组防泄漏(d12/d14 同题必须同折,leak-check=0),train1162/dev143/test149,sha16 冻结

**judge 自报三陷阱**(全部当日实证,复用价值最高):
1. is_correct=_parse_judge(judge_raw)=同源复写冒充真值(500"一致"假象)→必须独立复算才可标
2. 机械探针 M2 子串规则对等价改写系统性误伤('five'≠'5'/人称/括号,49 冲突全假阳)→红灯先分诊 M1/M2 再定谳
3. **训练特征含被检判分器输出(judge_output)=作弊通道**——判分器要从工件独立判对错;剔除后校准反而大改善(ECE 0.137→0.045)

**P2 v1 定谳**:冻结 bge-m3+三态头=架构天花板(66.2%>随机 50%>多数类 52%,距 85% 判据为架构差非学习差);U 态全库仅 7 条(dev 零 U)不设门;**85% 路径=LoRA/预训练推理(v2,需 GPU,先查保留盘纪律)**。

**How to apply**:errata 是 U 态与错判样本活水——🔴勘误(10/4 platform 三源复核):此前"18890 行 gold tier"系把 ASSAY 登记处端口号(serve port=18890)误读为行数;实况=assay_errata.jsonl 全文 1 条+判分相关存量约 4-10 条(E1-E4+宽松口径活性类),远低于 100 触发线,首训练单等增量活水不凑数;宪章 1776 已申报语料为数据类资产(他人用按 40% 计)。[[ssi-jev 提案 docs/plans/SSI_JEV_DYNAMIC_JUDGE_PROPOSAL_20260930.md]] [[judge-lessons-20260926]] [[rsi-deep-implications-20260916]]
