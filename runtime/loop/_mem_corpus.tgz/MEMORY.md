- [🔴探针文件名盲区 10/5](probe-filename-blindspot-g1-20261005.md) — G1 材料 56h"未出"=按指令坐标 summary.json 探空,实际叫 infer_summary.json;探材料必先 ls 目录实文件名;探空≠阴性
- [🌅10/5 凌晨冲刺:北极星+smoke PASS](day-log-20261005-northstar-sprint.md) — 四框对齐落定+L1 三件判据冻结提前交(3154)+14B smoke 五门全绿(200步86s/22.4G,管线可行性已证,升格另立预注册)+turbo 29G 完成+XERJ Issue#1138;compat 三坑(peft×transformers5/lab padding/pgrep 锚定)留档
- [🎯PMF 主线拍板 10/5](pmf-mainline-agent-harness-20261005.md) — compass=unipat 在 agent 领域(harness 基准评测/对比发榜/卖数据卖轨迹/归因提升),飞轮=具身侧 unipat;正本 mainline 第五节;首批被测画像 VISTA;榜单开张前必预注册判据
- [🏛️架构主线拍板 10/4](architecture-mainline-20261004.md) — 用户拍板"智能=压缩×验证×因果倒置"(compass+assay+jev)列为主线持续推进,与具身方向锚并行;正本 docs/soul/mainline_architecture_20261004.md(M1-M6 滚动清单)
- [🔴发函脚本框归属 10/3](platform-mail-script-boundary.md) — compass 发函一律 scripts/platform_mail.py;nautilus-core 的 send_letter.py 是 platform 框的(误用=署名冒名 2657 事故+ack 假失败);附智星云余额探针/信箱 API 只回未读特性
- [🔴教训:分析文档代替实质推进 10/3](feedback-analysis-vs-action-mode-20261003.md) — 用户严肃纠正:连续提问被我回以六份分析+审批流,实质推进仅1.5件;修复=问题分型响应(分析/推进/拍板)+options只用于真分叉+轮次自检换问"实质诉求推进了吗"
- [⚖️判分两线定价拍板 10/3](judging-two-line-pricing-20261003.md) — 用户拍板:判读永久免费(不设付费优先)+装订收费(判例集/认证/协议植入,只做判后事);SKU1 $99-299 废除;判例集 v1=装订首物含判据张力如实段
- [判分机构五演全弧+收官 10/3](g1-pusht-judging-arc-20261003.md) — G1 U→三修→差分终判+配对帧归因 Wilcoxon p=0.00986(混杂大半坐实)+rollout 主判据地板 PARTIAL-U(coverage p≈0.48 不显著,负结果照报);终判条件三条回档主;注入不传导仍挂账
- [动态权重 SSI×JEV 线立档 10/3](ssi-jev-p3-pipeline-20261003.md) — P3 管道+REG-100 零翻转门设计档+J8 申报起草未发+delta_0001=14 校准(200门槛悬案)+ledger 用 .json 制式;判官邀请死线 10/5 13:16+GPU 余额 21h 红灯+CI ruff N6
- [📖周综合 9/27-10/3:三线对照盘点](week-review-20260927-1003.md) — 232 commits;P0-full 闭环 P1=BGE;G1 首演 U 态+证据三层立档;rsi-bench 协议输出首例;daemon 假部署抓出;具身采集线无直接产出
- [判分第三课:证据三层标注 10/3](judging-evidence-tiers-20261003.md) — 实测/推断/不可验强制标注+upgrade_path;G1 推断冒充实测教训;正本 docs/metering/JUDGING_EVIDENCE_TIERS
- [gtaras7 价值校准:降格为闭环 reference 10/3](gtaras7-value-recalibration-20261003.md) — 用户拷问 9 星个人仓库≠里程碑;投入收缩短回函+一次 rerun;主打叙事转 rsi-bench/登榜项目
- [P0-full 定谳:BGE 82.94% 胜出+两探针教训 10/2](p0-full-verdict-20261002.md) — F2 大幅 PASS;fill_diagonal 屏蔽金标对=检索评测经典陷阱(hit 恒 0 伪装 RED);P1 走 BGE 轻量件(拍板);turbo=Qwen3.5 架构待 venv
- [rsi-bench 提案被采纳落地 10/2](rsibench-adoption-20261002.md) — 协议输出首例(PR#2 replay 认证+收据+UNVERIFIABLE 墙);四件套样例包=本周交付;对方长评被删只锚公开实物
- [📖10/2 全日主log:gtaras7勘误闭环 10/2](day-log-20261002-gtaras7-erratum.md) — 方法论被对方采纳进其evals(组织级里程碑);10/1假部署抓出(cmdline验证纪律);点火A系列三RED转P0-full依据;2026旗舰全MoE化单40G卡无解;升格-疲劳相关定律(战略函不在疲劳端写)
- [🧭组织原则:开放利他·上善若水 10/2](org-principle-open-altruistic-20261002.md) — 无竞争对手、对外皆师友;两线分离:合作线(付费披露式 builder 内容)默认开放可收钱,测量线免费中立零利益——禁把独立性外溢成拒绝合作的姿态(cognee 婉拒教训已补函重开)
- [📖六天复盘:五病七模式 10/1](retrospect-6d-patterns-20261001.md) — 共性病:最后一厘米/叙事升格/测试环境失真/知识时效/工具脆性;高价值:预注册key先行/判据零放宽/U态/探针LOOP/失败公开/跨框互查/薄封装
- [🎯云daemon v3.3切换成功 10/1](daemon-v33-switch-20261001.md) — v3.2败因=存量pkl从未np化(999MB单体PyList膨胀2-3x)·_npify载入点整体转换+巨物200MB跳过·watchdog对抗正解=改unit ExecStart·云端部署五坑(sudo -n/9877被占/stop挡不住/env真名/ssh挂起崩会话)
- [🎯P2北极星达成+GPU三坑 9/30](p2v2-lora-milestone-20260930.md) — verdict-judge LoRA 88.51%三门全绿(J1/J2/J7)·verbalizer三态天然校准·_redact遮罩坑(release必走API层)·HF大文件断流→modelscope通道·pkill自匹配第4次([r]修法)
- [判分器语料1454+P2基线 9/30](judge-corpus-p2-baseline-20260930.md) — judge自报三陷阱(is_correct复写/M2等价改写误伤/特征含被检输出=作弊通道)·qid分组防泄漏·66.2%地板=架构天花板,85%需LoRA(GPU)·errata gold=U态活水
- [云daemon根治v3.2 9/30](daemon-v32-rootcure-20260930.md) — 四刀(numpy 8x实证175.8MB/预算制300k/listen前置/MSG_PEEK)·合成压测对齐生产1469MB·MAX_PROJ红线自修(64→256护栏)·蓝绿备件已upload待10/1 08:53窗口
- [SSH cloud 端口 24860 9/30](ssh-cloud-port-2460-20260930.md) — `ssh cloud` 别名即通(43.160.239.61:24860+cloud_permanent);22 端口从未开过,超时≠抖动;HTTPS 与 SSH 两通道独立
- [竞品终核四项定谳 9/30](competitor-final-audit-20260930.md) — mem0领投纠错(Basis Set非Abstract)·Zep独立运营+转型治理层(收购=幻觉)·TypeSafe proof不可寻址(171x/75x≠193.6x/444.6x同页双口径)·Letta $10M seed Felicis;弹药已成文dcr_ammo_competitor_audit
- [知乎发布器定稿 9/27](zhihu-publisher-ready-20260927.md) — dry-run 18/18全绿草稿待点发布·四修(from_idx下界/scrollIntoView/ab-al旗标/纯文本门槛)·paste保strong翻案(昨日'全被剥'过期)·9225键盘管道死复活术(Browser.close被154无视→锚port精确PID杀)
- [Discord CDP 发帖配方 Chrome154 修复 9/27](discord-cdp-chrome154-recipe-20260927.md) — placeholder撞类名/Enter唯一=CDP text
/nav废context勿内嵌/f-string拼JS大括号翻车×2/9224重启配方(profile在Temp)
- [会话主log:验证闭环→考场→SDK 9/17-20](c-family-verify-closure-20260917.md) — 6/6 agree·回函324·T4重写j=(m,τ,D)·语料导出器(61/61绿)·ClawHub 1.0.2重扫**Pass坐实**·key迁移+platform_mail.py(349反馈去重假绿)·**官方MCP Registry已发布**io.github.chunxiaoxx/nautilus-compass v3.2.0双列(npm unscoped mcp-publisher=俄语机器人坑)·README自家成绩单上墙·命名7候选(Assay/VerdictHall净)
- [verdict-bus 试点 9/15](pilot-verdicts-unverifiable-20260915.md) — 10/10 不可复算(items 8/22 起回归·输入只在 V5 日志·tokens=0·标志生产者自置=自报复发)·CATALOG_v0 立库 3 判据·回函 id 243·hook 实弹 14/14 PASS
- [验证商业化定稿 9/15](verification-commercialization-20260915.md) — 免费复算入口已开(#166 回复)·SKU1=独立审计 $99-299·M1(首请求)/M2(付费意愿)/M3(成交)前零基建·平台市场结算·双拍板已落(LICENSE A4+CLAUDE.md 报数纪律)
- [平台迁移·VerifyPack 挂门 9/14 晚](platform-verifypack-integration-20260914.md) — 技术函 223 三案选 A 已回(id 229)·soul 提案 approved(pr-soul-fceeba31fd58)·compass=agent 9000017(agent-first 注册·钥匙在 .cache/compass_platform_agent.env)·10 条试点等取数口径
- [RSI 环 #1 终局+技能卡 9/14](rsi-loop1-recompute-verdict-20260914.md) — 复算抓 2 自报绿→修复→重测全绿闭环→通报函已发(id 220)·awesome-zh PR#43 已投(A2)·ClawHub 授权=Chrome app-bound 硬墙只能用户 2 击·README 可能是 HTML 表格/双 /tmp 两坑
- [RSI 环 #1 合入+生态线首日 9/14](rsi-loop1-merged-20260914.md) — 三件套进生产(J1-J4 绿·main 基座版弃用教训)·复算留 9/15 新会话·PR#19+weekly#11676+Glama A
- [推广渠道定案 9/11](outreach-channels-20260911.md) — awesome 列表先查生命体征·GCM token 无 PR 权限(gh auth token 兜底)·dev.to 评论 API 已废·Chrome 136+ 禁默认 profile CDP
- [HN 全 curl 管道+首帖秒 flag 9/10](hn-submit-pipeline-20260910.md) — 登录/提交/评论/确认流配方·49641875 被埋·下次发帖前先养号
- [记忆门三件套实现 9/9](memgate-trio-implemented-20260909.md) — #48 提前实现:fact_status/dedup_check/沿链一跳(daemon 仓 feat/memory-gate-trio,未部署)·J4 基线 GREEN·9/1 WIP 已固化 3912205·🔴勿在值守期直改生产 daemon.py(watchdog 会拉起半成品)
- [VerifyPack v0.2 构建完成 9/9](verifypack-v02-built-20260909.md) — #47 交付:SPEC+CLI 五命令纯 stdlib(ed25519 自实现交叉验证)·batch001 端到端 5A+1D+1degr·disagree=resource_log.csv 活文件实锤与 v0 复算交叉一致·三引擎缺陷修复录·等 flywheel 回执
- [compass 四层路线图拍板 9/7](compass-roadmap-20260907.md) — 仲裁器定位对句·VerifyPack v0.2 立项(#46 复算→#47 构建)·记忆门三件套 9/15·QC 判据定标·不做动作门·两封回执已还(platform keeper/flywheel ack)
- [竞品 Aegis Compass 9/7](aegis-compass-competitor-20260907.md) — coding agent 记忆+治理层 $20/mo·动作门强(policy/审计/合规)记忆门弱·定位修正「arbitrate what agents remember」·Compass 第三次撞名(对外一律全名)·§6 应答已加
- [七算子记忆审计 9/7](memory-audit-seven-operators-20260907.md) — 写无gate/合并无触发/链接是装饰属实·两修正(衰减在schema未使用·QC门在燃料线)·三修复冻结至9/15窗口·fact_status纪律即刻内化
- [PyPI 3.1.1 发布定案 9/6](pypi-311-published-20260906.md) — 三重验证绿·build 必走 --no-isolation(Store python venv bug)·403=token 截断(95≠175)·包自家已到 3.0.1·README 补 pip Quickstart
- [Gmail 邮箱验证生产上线 9/6](gmail-verify-production-20260906.md) — production token 定案·四坑(env CRLF 401/nginx 漏 verify 路由/probe 必带 PROBE_A/B env/nginx 不放行 .html)·signup e2e 全绿+FOUR-GREEN·daemon 僵死双进程=stop hooks 卡因(冷启动实为 ~9min)
- [9/8 发布冲刺全景 9/5](launch-sprint-status-20260905.md) — 用户拍板:新共识叙事+造词·白皮书 v1.1+深讲 PPT 39 页完成·🔴same-embedder 假声明 6 处已纠偏(对打=各用默认嵌入)·nginx /mcp 8443 陷阱·用户侧阻塞清单
- [SOTA 跑分攻坚日 8/27](sota-eval-day-20260827.md) — 500 题终裁统计平局 P@1 赢 · 归因链四步证伪法 · 12题偏样教训 · GPU 4090 速配 12min
- [传播五层顺序 9/4](propagation-layer-order-20260904.md) — 🔴用户拍板:英文业界架构文→中文圈→论文→市场需求→大众营销贴(故事素材排最末)
- [P1 宿主迁移 HTTP 9/6](p1-host-migration-http-20260906.md) — 4 框全切 HTTP 完成·根因=语义 scopes list 被归一洗掉 tools.*(ce456dc)·连环坑 resources.read 点号+recall 假绿·三重复验绿·隧道 9/15 停
# Memory Index · nautilus-compass

- [Gmail REST fallback 配方 9/10](gmail-rest-fallback-recipe-20260910.md) — gmail MCP 挂时读信:`~/.gmail-mcp/` token→oauth 换 access→gmail API·重授权 gmail_reauth.py·Trajko 9/8 ack 已处理确认非新件
- [战略四优先级拍板 9/10](compass-strategy-four-priorities-20260910.md) — 用户同意:9/15 三件套→batch002 全流程→判据库 v0→paper2 双速异构·协同拼图(flywheel 判数据/compass 判可信)·反剧场主尺=看首个外部复算请求

- [license 切 Modified MIT 9/4](license-modified-mit-20260904.md) — 用户拍板 Kimi 式(MIT+商标+托管100付费用户上限)·窗口期论·自部署≠收入死·遗留律师复核
- [cheap-tier 收口+watcher 定型 9/4](cheap-tier-close-and-watcher-20260904.md) — web 36.3/ent 36.5 双域未超现役组合关·启动模板+自动重判 watcher 堵死判官两坑
- [A 臂摘要层终判 PASS 9/3](arm-a-summary-layer-pass-20260903.md) — e2e 42.6→70.0/81.6% 三型全过门双口径稳健·组装层归因证实·judge 断连两类口径披露
- [论文线历史纠偏 9/4](paper-roadmap-history-20260904.md) — 旧paper2(Chinese LLMs·56.6%)arXiv被拒勿再引用·当前paper2=判官盲区版零依赖旧稿·kimi三篇待对齐防撞题
- [judge 401 变量名坑 9/4](lmev2-judge-401-envvar-pitfall.md) — harness 默认读 OPENAI_API_KEY,source .ark_env(ARK_API_KEY)启动=判分全 401·生成不受影响可 rejudge 补救·起评测一律走 HANDOFF(judge.env)
- [GPU 旧盘重启正路 9/3](gpu-old-disk-restart-20260903.md) — 租新机前必查保留盘(旧盘全套环境秒就位·新租重部署浪费¥30)·654686@js1:11224·24G卡vllm须--enforce-eager·instance list顶层无data键·pkill -f自匹配第3次

- [🔴LME-V2归属纠偏 9/2](lmev2-upstream-attribution-20260902.md) — 451题=上游xiaowu0162官方基准非自建(差点改名发布=侵权)·N6改形:T0=官方基准成绩册+判分协议+调优栈(attribution)·NautilusMem留T1自创新题·"自建"叙事也是自报,资产断言先grep溯源
- [基准命名/许可/立项 9/2](benchmark-naming-licensing-20260902.md) — 命名三连撞(CompassBench=上海AI实验室·ATLAS=李飞飞9/2·CompassMem=arXiv框架)·终选NautilusMem(查重净)·license 绿·N6 立 T0(9/12)T1(新题型)T2(训练飞轮=评测自举)

- [d14 刀4 定案+终局口径 9/2](d14-abstention-verdict-20260902.md) — abstention gate 未过门(误拒答92/89题·但95%本来就错·打掉仅5/2)·**终局干净口径 web 40.0%/ent 38.4%**(d12重判现役·36.7/40.3作废)·探针三陷阱(全文grep误命中/拒答模板≠误拒答/污染嫌疑=拒答)

- [测试+安全+稳定性专项 9/2](test-security-stability-20260902.md) — 全量pytest复活1581绿(mcp_durable 15失败=契约迁移非回归·tests/缺__init__坑·exit code经管道被吃)·漏网客户端#8(pytest探测器)·auth_failed的pytest噪声陷阱·探针键名bug(scopes≠scope·缺键默认值=未验证即断言)·watchdog v3 exit0顺序坑·版本四处对齐3.1.1

- [daemon 鉴权+HF offline+token 收窄 9/1](daemon-auth-and-hf-offline-20260901.md) — 9876 探活必须 socket JSON(curl HTTP 探=必假阴性·启动到可服务~2.5min)·全 action 要 token(ping 除外)·新客户端必带 token·漏网客户端 7 处已补齐(auth_failed 日志=系统性探测器)·watchdog 复活每 5min(6/29-9/1 零守望)·云端 12 token 收窄 9 剩 3 等报备
- [9876 三根因+watchdog 定案 9/8](daemon-9876-watchdog-rootcause-20260908.md) — hook 拉起挂会话树连带杀+冷启动 349s vs 豁免 120s+无 supervisor;已修:计划任务 watchdog 每 5min+死因日志落 .cache/daemon.log+GRACE 600;🔴ping 必带 \n(无 \n=连上无响应假阳性半死)
- [HUD 多窗口串台修复 9/1](hud-multiview-crosstalk-fix-20260901.md) — claude-hud 段缓存 per-cwd 分桶+独立节流(v3.0.11·2a359aa)·文件名 hash 必须 md5(str hash 跨进程漂移)

- [d13 刀3 定案 8/31](d13-judge-retry-verdict-20260831.md) — LoRA 检索增强双域未过门路线关闭,d12 现役·doubao judge 4096 被 reasoning 吃满=系统性压0·上游源码 GitHub 直拉·双进程写文件事故教训

- [收函代理轮+48h 待办 8/31](inbox-agent-round-20260831.md) — 10 函回函+ack 清零·SSOT 自纠 faedfd6·🔴 到期件:9/2 22:00+0800 daemon 日轮部署回执 / hook 注入 / d13 结果拉回+judge 复核

- [P2 提审终审+路径B 8/30](p2-submission-terms-review-20260830.md) — 3 条死路已修(卡片指 /mcp/+README 邀请制+npm 删)·6 件 MVP 开工件 HANDOFF_20260831·🔴 提交前必 push(GitHub 版还挂死链)

- [v0.9 X-User-ID 冒充洞修复 8/30](security-v09-xuserid-impersonation-20260830.md) — 8770 公网可冒充任意用户读记忆+投毒写;已改 JWT-only+五项矩阵验证·部署陷阱:生产版在 /home/ubuntu/compass 非 repo

- [daemon pylibs 根因 8/30](compass-daemon-pylibs-rootcause-20260830.md) — 1322 次 recall 失败=启动脚本 PYTHONPATH=C:\pylibs 旧库注入;已修(hud/recall 恢复)·lazy import 报错查源码+消差法
- [income 停摆读数 8/24(已纠偏)](session_income_flatline_rootcause_20260824.md) — 8/22 停铸币是用户主动停(B=0 空转)·income 指标废弃 · 8/24 g2b1=V5 真燃料线
- [V3.0 上线冲刺收口 8/24](session_v3_launch_closure_20260824.md) — C1-C3 全收口 · pkl 卡死真根因=非原子写 · 云 /opt daemon 分叉待统一

- [Convergence State Snapshot 8/9](convergence-state-snapshot-20260809.md) — income 1707 但 B=0 全自产 · fuel-loop=唯一闸门 · S4-2 已合 origin/main
- [Compass Node](\_NODE_nautilus-compass.md) — 项目综合节点(复发模式 + 矛盾陷阱 + 决策时间线 + 当前 grounded 状态)
- [Convergence Snapshot 8/21](convergence-state-snapshot-20260821.md) — income 7551 日增~30 但 B 仍=0 全 genopt 自产·fuel-loop 闸门未过·隧道配方在内
- [fuel-loop 部署合约 8/25](session-contract-fuel-loop-deploy-20260822.md) — ✅CONSUMED 8/22 compass 独立复核通过 · 下一闸=链路活(ledger 首条真记录)
- [统筹基建合约 8/26](session-contract-dogfood-bridge-20260822.md) — cnt_dogfood_bridge_20260822 · 全框接云compass MCP(用户批准)·判据=跨框读写闭环
- [真燃料 Gold 合约 8/27](session-contract-gold-replication-20260822.md) — ✅CONSUMED 8/22 · 3 Gold(2 真燃料 d3 r5/r15)· ③类部落事实 headroom 实证 control 0/10
- [Ilya/SSI 持续学习动向](industry-ilya-ssi-continual-learning-20260822.md) — 首模型 2026-08 · value function 需真值供给=我们上游 · 窗口期卡位
- [L4a 蒸馏首跑合约 8/29](session-contract-l4a-distill-20260822.md) — ✅CONSUMED 8/25 · compass 独立验收 PROVEN(单族弱边界)· proof 押送 _v5_proof_deposit 3536353 · 8/30 补登(此前假逾期)
- [recall 有用性实验 8/24](session-contract-recall-usefulness-20260823.md) — ✅CONSUMED · F2 delta=1 首证 recall 有用 · 修复语义 recall 100% 坏死(torch 长路径)

- [GOAL SSOT 目标模式](../../../../Projects/nautilus-compass/GOAL_SSOT_20260823.md) — 目标账本+心跳执法 b02b282 · 无悔/赌注/冻结三层
- [V3.0 上线冲刺交接 8/24](../../../../Projects/nautilus-compass/HANDOFF_20260824_V3_launch.md) — 新会话开工件:pkl 落盘补丁→回归门→push v3.0.0→云 ff;三框/蒸馏/发文按序
- [GPU 实例复用纪律 8/28](gpu-instance-reuse-not-rent.md) — 连不上≠到期先查 status·绝不随便新租(¥96 教训)·🔴8/31 用户定策:保磁盘不买自定义镜像·GPU 实价表(4090 1.65/A100 40G 2.75)·部署走国内源
- [e2e 修复定案+tr 诊断 8/28](e2e-context-fix-and-tr-diagnosis-20260828.md) — e2e +30pt 0.567 定案·tr 根因=context 无日期一行修·GPU 机网络拓扑直连 HF 唯一快路
- [GPU e2e 四层根因链 8/29](gpu-e2e-rootcause-chain-20260829.md) — 429退避/reranker验载/抄env逐项diff/bge路径 · GPU 30-60s/题 · 实例IP换线直连
- [禁用黑话'收棺' 8/29](no-jargon-user-correction-20260829.md) — 用户两次纠正;对外文本说人话,转述 platform/V5 原文要翻译
- [LME-V2 管线 smoke 全通 8/30](lmev2-pipeline-smoke-proven-20260830.md) — 六坑定案:BGE 线程竞态单worker/newapi审查换ARK judge/32k硬要求;复跑命令在 TRANSFER_RUNBOOK
- [LME-V2 首次全量基线 8/30](lmev2-first-full-baseline-20260830.md) — 451 题 web 19.6%/ent 12.8%(doubao 口径)·短板=检索 unknown 率·营销主打 e2e500 勿用未调优基线
- [LME-V2 三刀调优 8/30](lmev2-three-knives-tuning-20260830.md) — d12 定案 web 19.6→36.7%·ent 12.8→40.3%(四判据三中一未测)·judge patch 两连崩教训=验证要函数调用级冒烟·刀3 待 GPU

- [ARK 走 coding plan 端点 8/30](feedback-ark-coding-plan-not-metered-api.md) — /api/coding/v3 openai 兼容·按量 API 烧充值被用户两次纠·key grep 锚行首防 UID 混入
- [workbuddy 跨框暴露修复 8/30](security-workbuddy-token-scoping-20260830.md) — TCP MCP 版补项目级 scope(8/28 只修了 HTTP)·workbuddy 已换 scoped 旧全权已 revoke·TCP 改 tokens 需 restart 无热加载·12 内部 token 待迁 9/15
- [GPU 651799 到期事故 8/31](gpu-651799-expiry-incident-20260831.md) — 完案:web 240+ent166+V5 双 adapter 全固化(37aac93)·🔑续费通道真相=renew_instance API 一直可用(参数=Container_name 非 Id)·新实例实测 652509/2080Ti 已续至 9/1 14:15·🔴自动续费还开着,ent 完成后退租防空扣
- [dev.to 自主运营首夜 9/8](devto-operations-20260908.md) — 零流量三根因(AI 披露新政未设=疑似不分发·泄露文已撤·title 发布后锁死)+管道配方(python=403 Bots·curl 浏览器 UA+全文 payload 才生效)+发文 checklist(标题定稿/21:00 北京发/1-2h 盯评论)
- [ClawHub/Glama 双审查修复 9/16](clawhub-glama-audit-20260916.md) — uv universal lock 解析全部 extras·私有轮必炸外部构建·安装命令一律钉 tag/SHA·Glama 评分按钮=Admin→Request a re-sync
- [RSI 深度启示 9/16](rsi-deep-implications-20260916.md) — 动态模型时代护城河=验证机构·verdict语料=带签名SFT/RL燃料·自训只限小判分器(反自指护栏)·三机制收费映射·全挂M1后
- [「考场」立项 9/16](examhall-charter-20260916.md) — RSI×组织记忆认证轨基准·调研定谳题目层拥挤认证层空位·差异化=诚信计分+回执名次+上墙·借轨优先·compass走向五层·三函314/315/316待回
- [jev-trust 发布三发 9/22](jev-trust-launch-20260922.md) — PyPI 0.1.0+双 awesome-jev PR(cobanov#71/yibie#137)+Discord;TrustedJev=域校准常驻仪器;坑:awesome-jev 两份列表/gh 三段式 head 走 REST/socks 代理毁 venv pip
- [commit 署名纪律 9/23](commit-attribution-rule-20260923.md) — 用户纠正:主署名=chunxiaoxx<chunxiaoxx@gmail.com>,禁止 Co-Authored-By 尾注(GitHub 渲染 Claude 头像抢署名);历史 saas-dialog 署名不主动改
- [BC1+Loop+重写日 9/23](bc1-and-loop-day-20260923.md) — BC1 全链(30题/11-18审计/18-18重考/签名三连修)+Loop V1 六机制五轮跑通+历史全量署名重写(旧 sha 失效);🔴自验同源不可信+披露段须法证核对
- [HANDOFF 9/24 开工件](../../../../Projects/nautilus-compass/HANDOFF_20260924.md) — 新会话第一步:信箱(故障待查)→LOOP_STATE→七步轮值;9/27 BC1 执行日 Runbook 就绪
- [T3 接单+主批三 findings 9/24](t3-miniclaim-20260924.md) — jev-curate 首个外部 mini 履约:criteria dict 必 422/标尺 0-4 错位/R3 误拒;复算 9/26 完成**RED**(R1标注分歧未预披露致MAE不复现+报告层6数字不可复现;工件层/主批判据逐位复现,待勘误);信箱故障实锤通报 893
- [五框坐标与跨框探查法 9/24](org-frames-probe-runbook.md) — 用户拷问后实测:flywheel"静默"误判全案(当日实为7commit全速);五框仓坐标+探查三件套+信箱id同空间
- [MiniMax coding plan 供给配方 9/25](minimax-coding-plan-provider.md) — sk-cp key 走 api.minimaxi.com/v1·M3 推理模型剥 think/8k 上限·CLI OAuth 路线已证死·key 只走 env 不落仓
- [向量对拍定案 9/25](emb-bakeoff-bge-stays-20260925.md) — bge-m3 不换:Qwen3-0.6B recall@5 仅+0.46pt<阈值,recall@1/中文切片现役反优+2.75pt;MTEB 账面在自家分布不成立;只换不造原则
- [BC1发布前夜31h主log 9/26](bc1-launch-eve-20260926.md) — mem0三臂(16/11/18压缩元凶+7)·T3完约(子进程复算RED→6转写错勘误)·判因29题四类·战略总纲两版·五件批;配方:子进程claude清代理+显式model·curl直抓绕搜索配额·ctex中文
- [判分两课 9/26](judge-lessons-20260926.md) — 机械判因必覆盖判分器**全部判定门**(τ-bench两道门漏一→5题误判);判绩账双向:评委也会错,勘误留档=信用资产;独立性梯度:新会话>子进程>禁止自跑
- [Infistar 赞助处置 9/30](infistar-sponsorship-handling-20260930.md) — 首封赞助函·用户拍开放对接·四条款(中性位/实测先行/独立性/资质前置)·30天计量预注册J1-J7·待对方三项材料
- [Letta发错仓考古 10/4](letta-wrong-repo-lesson-20261004.md) — 主仓=landing page禁eval类issue(机器人报"模板缺项"不报"发错仓");外联开issue前三查(AGENTS.md/guard机器人yml/维护者活跃度);letta-evals#340已发存活
- [E1收官+两条闭环同瓶颈 10/4](e1-arc-closure-two-loops-20261004.md) — ha-006全采纳免重跑收官;判分商业闭环与P3数据闭环(32/200)共享外部消费瓶颈;M1直通车=rsi-bench replay认证(对方已实装)+letta-evals#340
- [PyPI 3.3.0 发布+根目录映射包坑 10/4](assay-330-pypi-published-20261004.md) — assay 子包首次 pip 可用(发版五连闭环+三重验证);🔴nautilus_compass=根目录映射包(无实体目录),新增子包走 package-dir 映射,未安装环境 import 用 importlib 文件加载;token 不落盘现取
- [🎯NACRE 代号拍板 10/6](nacre-codename-decided-20261006.md) — 创新模型定名 NACRE(Novelty-gated Adjudication via Compression & Registered Evolution);v1 单点隐喻批被否+中文名不用;后续一律 NACRE
- [🏁Round1 定版日 10/6](day-log-20261006-round1-final.md) — A 26.7%/B 16.7%(+10.0pp)全链定版+勘误第6例(尾换行降级)+判据①闭环+背书函9903被白皮书挂锚;待拍板:邮箱地址/14B/偏置三路径
- [🗺️基准评测体系双域拍板 10/6](benchmark-system-dual-domain-20261006.md) — flywheel=具身数据域;compass+v5=agent 域 unipat 五层地图(已有工作全 sha 锚);自有基准=子件
- [📖10/6 白天段主log](day-log-20261006-morning-benchmark-system.md) — r80判读20min闭环+NACRE白皮书v1.0+E1判据冻结+rsi-bench#4+体系三连令;教训:quiet≠无作为(RSI信号衰减论)/大件传输先看件重/列名实读
- [⚖️七判断落定 10/6](judgments-j1-j7-settled-20261006.md) — J1太极两仪C机制化/J2邮箱别名/J3 14B三实验阶梯(归因=语料量)/J4缓修+gold复核/J5改B小采集/J6 10/26裁决预注册/J7吸收;正本收敛纲领§七
- [🦴灯下黑+复算U态 10/6](dogfood-and-e1-recheck-20261006.md) — 云端daemon瘫痪19h(19.5万拒连,LRU churn根因,MAX_PROJ drop-in修复+probe第六源);E1复算0.9601<97%门U态照报(主判维度零翻转强复现);七判断J1-J7落定
- [🩺云daemon风暴根修+R256翻案 10/6](cloud-daemon-storm-rootfix-20261006.md) — R256"socket泄漏"误诊,真根因=无用功风暴(僵尸白算占满32槽);v3.3.3=开工前MSG_PEEK探活;daemon_v33.py混行尾patch锚必双变体
- [⏳NACRE对齐+SLA两函在途 10/6](nacre-align-sla-tier-inflight-20261006.md) — 7B先攒语料3000再对拍;assay-bench查重红灯(Genentech硬撞,caliber-bench较净候选);函10104(SLA分档)/10105(NACRE对齐四议题)等回执;compass定义三层校准(记忆本体/平台评测/assay工具)
- [🔑HF org=nautilus-compass 10/7](hf-org-nautilus-compass-20261007.md) — org实际名带compass尾(nautilus-org不存在404);全权限token双框各一份入库0600;10/8死线件完成;判分器/样例包挂org
- [📖10/7 主log:部署纪律+燃料闭环](day-log-1007-judge-discipline.md) — fp16可用/int4禁用判定表(研究空白首发)+E-NACRE-1负结果(三线全指攒语料)+ORG-FUEL 242条入池(语料1695)+A2复算三权分立+GPU嵌入服务上线(剩隧道+切换两步);loop cron已注销
- [🔴安全事件闭环:A100密码泄漏→机内轮换 10/8](sec-incident-a100-pw-20261008.md) — PUBLIC仓40文件6天;树脱敏→.cache迁移→机内chpasswd轮换(免控制台)→死密无害→push解冻62commit;ops脚本密码一律env化
- [🎯主线边界锚定 10/8](mainline-anchor-20261008.md) — 用户三点拍板:compass+assay+jev三位一体/NACRE创新模型=主线/评测燃料判分全归compass;串线困惑=定义演进非错误
- [📖10/8 主件制 11 轮:语料 2257+终检清零](day-log-20261008-corpus-finalcheck.md) — 1846→2257 三段/终检 final_check.py 11:11/S6 正本;两通用教训:nohup 假绿 flag/登记处答复走正本
- [🔴sha锚autocrlf行尾陷阱 10/8](sha-eol-autocrlf-trap-20261008.md) — Windows工作树CRLF/cloud LF同blob双sha致平台复核"旧sha"误判;sha锚一律LF blob口径(git show|sha256sum);gitattributes判分资产LF固化ba5ab5cf;sha不符先证伪口径再疑文件
- [🔴M5部署三课 10/8](memgate-m5-deploy-lessons-20261008.md) — inotify环境差同代码双行为(patch log抓分支)/EMBED_BUDGET渐进消化=重启后J4假RED(budget=200根修,coverage字段=进度表)/MSYS kill不达Windows pid双端口事故(netstat拿PID再taskkill)
- [🎯判读管线首夜全链 10/9](judge-pipeline-first-card-20261009.md) — 首卡delivered→平台独立复现→delta入册语料2258·sha口径LF固化(gitattributes)·派单制信箱函·L1/L2分界·4096验收五门冻结
- [🔧M5部署四课 10/9](m5-memgate-deploy-lessons-20261009.md) — cherry-pick跨24天零冲突·双进程同端口(MSYS kill无效须netstat+taskkill)·EMBED_BUDGET渐进=dedup冷文件漏检(coverage披露修)·fast path环境差虚警
- [💾S6磁盘终局与护栏 10/9](s6-disk-final-and-batch-guard-20261009.md) — 用户裁既存数据盘不扩容(/data余57G)·镜像分批用完即删·GUARD<25G精确自停21/30·containerd 16G实为docker悬空层·A4在役venv探针否决先例
