---
name: org-frames-probe-runbook
description: "五框坐标与跨框探查法——9/24 教训:凭 compass 记忆索引断言他框状态=自报复发,flywheel\"静默\"误判全案"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0591835a-21ac-4887-9bc5-28eb34d2b5f5
  modified: 2026-09-24T06:44:59.370Z
fact_status: inferred
---

2026-09-24 用户灵魂拷问:卖组织记忆的 compass 却找不到 flywheel 在哪。实测反转:flywheel 当日 7 commit 全速跑(此前我在战略分析里判其"静默/数据线悬置"=完全错误)。

**Why**:compass 记忆按项目分桶(~/.claude/projects/<proj>/),跨框知识只进不进我的召回取决于"compass 会话写过"。凭"我的索引里没有"断言他框状态=自报逻辑复发,违反立身之本。

**How to apply**:任何涉及他框的判断,先做物理探查(≤2 分钟):
- **五框坐标**:compass=`Projects/nautilus-compass`(账本 docs/plans/LOOP_STATE.md);flywheel=`Projects/nautilusflywheel`(北极星 GOALS.md·loop 锚 docs/plans/LOOP_FW_20260921.md·1h cron 自轮值);platform=`Projects/nautilus-platform-sdk`+云端(组织态 GET /api/platform/org/bootstrap?agent=X);v5=Projects/nautilus-v5;日报框=仓未定位(nautilus-core 疑似,待查)
- 探查三件套:①git log --oneline -5 <框仓> ②读其账本/GOALS 头部 ③ls 其 _INBOUND/_OUTBOUND_ 函件尾部日期
- 平台信箱 id 空间全框共享(flywheel SENT 911/914 与 compass 893/896 同空间)——写入端各框都通,9/24 故障面实测收窄为 to=compass 读取域
- Loop 深同步轮(每 5 轮)的"三方核对"必须含**直接探查各框仓**,不能只对账本+信箱
- 跨项目检索可用 compass MCP session_search/recall 带 project 参数——能力一直在,缺的是用它的流程纪律

[[t3-miniclaim-20260924]] [[bc1-and-loop-day-20260923]]
