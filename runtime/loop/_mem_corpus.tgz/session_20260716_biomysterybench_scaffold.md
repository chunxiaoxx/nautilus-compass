---
name: session_20260716_biomysterybench_scaffold
description: BioMysteryBench(甲方外部新需求·生物信息学反向推理benchmark)compass 建了格式+验证器脚手架;真解验证的 bio 工具环境+批量待拍
metadata: 
  node_type: memory
  source_session: 2026-07-16 compass 接 BioMysteryBench 新需求
  type: project
  originSessionId: e4544c1e-7207-4060-8121-a054066dcec8
---

# BioMysteryBench 出题脚手架(2026-07-16)

## 需求(甲方外部 PDF + biomysterybench.zip 样例)
生物信息学**反向推理**题:给真实测序数据(样例=721MB SRR1295350.fasta),反推隐藏事实(样例答案=Glioblastoma/GBM)。要求:必须用外部 bio 工具(BLAST/比对/查库)· 20-30min 专家难度 · ≥10 次工具调用 · 唯一答案 · 全对全错评分 · human_solvable=yes · allowed_domains 限 14 白名单。
- 格式:`problems.csv`(列 id/question/answer_rubric/allowed_domains/human_solvable)+ `data/<ID>.zip`。
- 样例只给 1 道(qes.xlsx 里 qes1),PDF 说的 74KB file_problems_1.csv 未给。
- 买方验收 = 内部抽检 + bmb-infer;泄露/无工具/难度低/无法加载/答案模糊 → 退。

## 用户决策(3 问)
① 起步=**先做格式/验证器脚手架**(不先自解、不先批量)② bio 工具环境=**本机**③ 优先级=**先评估再定**(vs 11 题/GenOpt 新题供给)。

## 已交付(compass FDE benchmark turf · `vtf/fde_benchmarks/biomysterybench/`)
- `bmb_validator.py`:把买方 §3/§4/§5 验收门译成代码。REJECT(必修)=缺列/id 不配 zip/zip 坏/域名超白名单/human_solvable≠yes/**答案泄露**;WARN=rubric 非全对全错/疑难度低/疑无工具/无答案格式。**已验证**:--selftest 过(qes1 通过 + 泄露负例被抓)+ 买方真实样例 qes1 实测 0 REJECT + 模板 exit 0。
- `README.md`(格式规范+门+用法+诚实下一步)· `problems_template.csv`(干净起点)。

## 待做(诚实·验证器挡不住的核心)
1. 搭本机 bio 工具环境(WSL/conda+bioconda:BLAST/samtools/bcftools)= 真解题验证前提。
2. 端到端产+解+验 1 道(复现 qes1 或公开 SRA 造新)证管线过验收档。
3. 跑通再定批量 + 主线优先级。
- ⚠️ 验证器只挡格式/泄露/白名单;**"题太水/答案不唯一"必须真解一遍才知道**(买方 §4 核心)。红线:内容需真数据/真专家,AI 不得凭空造。

## bio 工具环境决策(2026-07-16 · 实测)
- 🔴 **WSL Ubuntu-20.04 网络坏**:resolv.conf 有 DNS(223.5.5.5/8.8.8.8)但解析挂起、curl 全失败、命令 timeout(疑 docker-desktop 劫持网络 / 代理)。**不钻修 WSL 网的坑**。
- ✅ **走 Windows Python + Biopython(1.87)远程调 NCBI**:实连 NCBI Entrez 成功(SRR1295350 命中 SRA Id 786922)。allowed_domains 含 ncbi,够 build 端(查 ground-truth)+ 部分 solve 验证(远程 BLAST)。
- 需本地重工具(samtools 跑 BAM / 全量 BLAST 大 FASTA)的题 → 上 cloud box(有网,但共享+刚从过载恢复,慎)。
- 🔴 **solve-to-verify 仍是每题的慢活**(买方要 20-30min/≥10 工具调用):qes1=从匿名 721MB FASTA 反推 GBM,需真序列分析(非查 accession=作弊),单题就是设计上的 20-30min。这是 per-problem 主要成本,别在长 session 末尾赶。

## 500 题规模化设计(2026-07-16 · 用户拍走路 A · 甲方要 500 题)
- 手工每题 20-30min × 500 = 上百小时不可行 → 设计 = **反向推理模板 × 真数据集库 × 自动化产-验管线**(`DESIGN_500_scale.md`)。~10-12 模板 × ~40-50 实例 = 500。
- 钥匙:**难度来自模型摸不出工具链,不来自算力**;我们知解法→验证可自动化,模型不知→仍 20-30min。
- 🔴 规模化铁律:**优先小数据模板**(表达表/VCF/序列 MB 级),避开 qes1 那种 721MB 原始 FASTA(500×数百MB=TB 级不可行)。
- 硬约束:NCBI rate limit(限速+API key)· 反 gaming(跨 8 类型铺开,不能单调)· 难度守恒(每模板抽样真解计时验 20-30min 门)· 红线(数据集库=带真值 accession 清单=唯一重人工挖掘环节)。
- 分阶段:P1 证 1 模板(推荐 VCF→变异临床意义,小数据/解法清晰)→ P2 建 8-12 模板库 → P3 自动化管线 → P4 批产 500+抽样 QC → P5 交付 bmb-infer。
- 工厂复用:P2-P3 模板库+管线将来招生信专家直接复用(compass 建工厂·专家产内容)。

关联 [[FDE_BUSINESS_CHARTER]] · FDE 第三类 benchmark
