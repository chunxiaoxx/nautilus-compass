---
name: architecture-mainline-20261004
description: "用户 10/4 拍板\"智能=压缩*验证*因果倒置\"架构列为主线任务持续推进,与具身方向锚并行"
metadata: 
  node_type: memory
  type: project
  originSessionId: c62a754e-c031-437d-a37a-0d217fbf3144
  modified: 2026-10-04T13:30:23.366Z
fact_status: inferred
---

用户 2026-10-04 拍板:把"智能=压缩×验证×因果倒置"创新架构(compass+assay+jev 全链路)列为主线任务持续推进,与具身智能数据方向锚并行。

**Why:** 用户 mid-turn 战略问后追认——判分机构运营(G1/gen4/V4/r79 判例)与动态权重管道(P3/LoRA 判官)不是零散业务,而是同一架构的验证环与因果倒置环;立项让三者滚动推进有正本可挂。

**How to apply:** 正本 `docs/soul/mainline_architecture_20261004.md`(映射表+六项滚动清单 M1-M6+判分纪律不变式);每晚轮对照 M1-M6 取件推进;新判例/新协议采用即归入对应 M 件。相关:[[judging-two-line-pricing-20261003]]、[[ssi-jev-p3-pipeline-20261003]]。
