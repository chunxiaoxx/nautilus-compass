---
name: hn-submit-pipeline-20260910
description: HN 全 curl 管道配方(登录/提交/评论/确认流)+ 首帖秒 flag 的处置选项
metadata: 
  node_type: memory
  type: reference
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-10T11:30:14.646Z
fact_status: inferred
---

# HN 全 curl 管道配方(2026-09-10 首跑实测)

- 登录:`POST /login` 带 `acct=<username>&pw=<密码>&goto=news`(只认 username 不认 email;302=成功,失败 200+Bad login);cookie 名 `user`(HttpOnly,10 年期)
- 提交:`GET /submit` 解析 `fnid` → `POST /r`(fnid+fnop=submit-page+title+url/text);URL 帖若被 site 风控拦→报「your account isn't able to submit this site」(零历史账号第一帖提自家域=标准待遇),改 text post 通常直接 302 newest=发布成功
- 评论:item 页无内嵌表单;`POST /comment`(parent+text+goto)→ 首评常触发 `302 /x?fnid=...&fnop=commconfirm` 二次确认;新账号可能直接「Sorry, you can't comment here」
- 登录态验证:GET /news 看 `user?id=<name>`+logout;flagged 帖匿名访问 fatitem 为空(对外不可见)
- Algolia 查提交史/dup:`hn.algolia.com/api/v1/search_by_date?tags=story,author_<name>`(curl schannel 吊销检查 offline 时用 python urllib)

# 首帖秒 flag 事故(2026-09-10)

item?id=49641875(text post 版)发布成功但秒被 flag(埋掉,匿名不可见),作者评论也被拒。零 karma 账号第一帖自推的系统性待遇,非内容问题。处置选项:留帖等 mod 复审+contact 表单说明(官方路径)/删帖养号(自删首帖=负信号,不推荐)/换号(违纪律)。**下次发帖前:账号先有几天真实评论活动。**

相关:[[launch-sprint-status-20260905]]
