---
name: arm-a-summary-layer-pass-20260903
description: "A 臂摘要层终判 PASS(9/3)——e2e 500 题 42.6%→70.0/81.6%,三型全过门双口径稳健;judge 断连 71 题两类口径披露;ssp 回退=噪声"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-03T18:06:02.287Z
---

# A 臂(摘要层)终判 PASS · 2026-09-03

**主判定:预注册三态全 PASS,双口径稳健。** e2e LongMemEval-S 500 题 overall 0.426 → **0.754 定案(9/4 重判 31/31 断连题补齐,每题均有真实判决;+32.8pt)**,4 天(ms 0.226→0.692 · ssa 0.250→0.839 · tr 0.158→0.624);ssp 终值 0.800=锚值零回退,此前一切"回退"证实为 judge 断连误判。

**Why:** 9/2 诊断"97% 错题 gold 已在 top5=组装层负全责"被证实——纯 context 工程(逐会话摘要卡+日期锚时间线,路由 ms/tr/ssa 三型)零检索改动零训练拿下。验证了"瓶颈在组装不在检索"的归因方法学。

**How to apply:**
- 两类口径披露:71 题(14%)judge 断连(newapi glm 间歇 403)重跑仍复发=基础设施噪声;保守口径(按错计)与干净口径(剔除)结论同向。对外发保守口径 70.0%,脚注干净口径。
- ssp "-5pt 回退"=n24 二项噪声带(差 1.5 题),中期版"-20pt"已证实是断连误判假象。小样本型的回退判断必须算噪声带。
- 落盘分片会静默缺尾(s168 段 70 题没写盘)——聚合判定前必对账 unique 数 vs 应有数。
- 产物:`vtf/_e2e_diag/arm_a_final_verdict.md` + `arm_a_final_verdict_raw.json`;README e2e 段/对比表已刷(commit 本轮);GOAL_SSOT N5① 已更新。
- 下一步:三池设计移植(ATTRIBUTION.md,目标官方 Small 55-60%)9/12 营销帖发完后启动。

关联 [[lmev2-upstream-attribution-20260902]] [[sota-eval-day-20260827]] [[d14-abstention-verdict-20260902]]
