---
name: p2-submission-terms-review-20260830
description: "8/30 P2 提审材料陌生人终审定案——3 条死路已修(卡片改真/README 邀请制/npm 死链删),路径 B 拍板(8/31 话术版提交+6 件 MVP 并行);🔴 GitHub 版 README 未推,提交前必 push"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-30T15:47:16.006Z
---

# P2 提审 · 陌生人终审 + 路径 B(2026-08-30 深夜定案)

用户要求对立面质疑后拍板:**8/31 用户提交话术版提审;6 件多租户 MVP 新 session 动工(约 3 工作日),完成后把"邀请制"翻成"开放注册"**。开工件 = repo 根 `HANDOFF_20260831_MULTITENANT_MVP.md`(五步旅程判据+地形事实+禁区)。

## 陌生人终审结论(对外材料实物核验法,可复用)

数字口径/实物存在性/敏感词全过;抓出 3 条"材料承诺了但实物不存在"的死路:
1. README 承诺 `/signup` → 404(自助 signup 是 MVP 件 2,当时没做)
2. agent.json 卡片 6 个端点全指 `/v1/*` → 当天删公网代理后全死(A2A 指路牌全死)
3. npm 包 `@nautilus/compass-mcp` → registry Not found

**方法教训:对外材料终审 = 每一条"命令/URL/包名/页面"都当作陌生人第一次点,逐一 curl/registry 实测。自己说齐不算齐。**

## 已修(commit bd63855,公网验证过)

- agent.json 卡片改真:capabilities 全指 `/mcp/`,auth=邀请制 bearer token(GitHub issue 获取),npm 死链删,改指真实 server_url。**双端同 patch:云端生产(/home/ubuntu/compass)+ repo**(改真后 MVP 完成时 acquisition 再翻"自助")。
- README Cloud-hosted 段改"invitation-only during review period"+真实 MCP endpoint。

## 🔴 提交前必做

**GitHub 版 README 仍挂着旧 /signup 死链**(本地领先 origin 11 笔未推)——评委从 homepage 点 GitHub 会看到死链。**8/31 提交前必须 push**(等用户授权)。

## 关联

[[security-v09-xuserid-impersonation-20260830]] · [[security-workbuddy-token-scoping-20260830]] · `docs/plans/2026-08-30-multitenant-roadmap-tasks.md`
