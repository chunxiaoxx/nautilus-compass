---
name: session_20260715_cloud_box_health_audit
description: 2026-07-15 cloud box 健康审计:certbot 自动续期已死(pyOpenSSL/cryptography 版本冲突)Aug 17 证书到期前必修;ufw 关 4 周;BGE daemon 饿死 DB
metadata: 
  node_type: memory
  source_session: 2026-07-15 compass 继续探索 box 健康
  forget_at: 2026-08-18T00:00:00Z
  type: project
  originSessionId: e4544c1e-7207-4060-8121-a054066dcec8
---

# cloud(43.160.239.61)box 健康审计 · 2026-07-15

compass 修完 backend 502 后继续探索,SSH 坐实(非自报)以下:

## certbot 续期(纠正:HTTPS 其实不危险 · 证伪自己第3次)
- ⚠️ 前一版本条目说"certbot 已死 Aug17 HTTPS 必挂"= **过头结论,已纠**。深挖后真相:
  - **坏的只有 apt `/usr/bin/certbot`**:它用 pyOpenSSL 21.0.0(dist-packages)+ cryptography 48.0.0(有人 pip 装进 ~/.local shadow 了系统版),pyOpenSSL21 引用的 `X509_V_FLAG_NOTIFY_POLICY` 在 crypto48 已删(实测 hasattr=False)→ apt certbot 连 import 都崩。**别动 ~/.local 的 crypto48(V5/compass 可能依赖)**。
  - **snap certbot 5.6.0 完全正常**(自带隔离依赖),`snap certbot certificates` 干净列出全部证书。**真正的续期机制 = snap**,`snap.certbot.renew.timer` active,每天触发。
  - nautilus.social(Aug17,32天)会被 snap 自动续,**HTTPS 不会挂**。
- **唯一真问题**:`snap.certbot.renew.service` 变 failed 的唯一原因 = 一张废证书 `zenmind.chat`(旧品牌 zenmind→nautilus-compass 改名前的域名,cert 已 5/23 过期,ACME challenge 失败)拖垮整个 renew.service 状态,并**掩盖**其它证书是否真续上。
- 修法(最小·低风险):snap `certbot delete --cert-name zenmind.chat` 清掉废域名 → renew.service 转绿。**待确认 zenmind.chat 确已退役**(本机 DNS 解析器坏,没独立核实)。主域可 `certbot renew --cert-name nautilus.social --dry-run` 证明能续(SSH 因 BGE 过载 flaky,dry-run 待补)。

## 🟡 ufw 防火墙关闭 4 周
- `ufw status`=inactive,`ufw.service` 自 2026-06-16 failed。暴露面 gap,和同期 9 天泄漏 sshd(98%CPU)呼应。缓解:腾讯云安全组可能在兜(未核实 SG)。修=排查 ufw 启动失败原因后重启,或确认 SG 已覆盖。

## 🔑 BGE daemon 慢性高 CPU · 已修(BLAS 限流+CPUQuota)
- 根因坐实:BGE daemon(compass-bge-daemon.service · /opt/nautilus-compass-v1/daemon.py)运行态 `/proc/environ` 无 OMP/MKL/OPENBLAS 变量 + **17 线程** = 代码里 `os.environ.setdefault` 脆弱写法失效,BLAS 每次 encode fan-out 多线程 → 烧 3 核(311% · 连续 14h+,非暂态重索引)。`CPUQuota=infinity` 无护栏。
- **修法(已应用 · verified)**:systemd drop-in `/etc/systemd/system/compass-bge-daemon.service.d/cpu-limit.conf` 加 `Environment=OMP_NUM_THREADS=1`(+MKL/OPENBLAS/NUMEXPR/TORCH)+ `CPUQuota=150%` → daemon-reload → restart。**结果:MainPID env 生效、CPU 309%→137%(封顶内)、load 14→3.35、端口9876 recall 正常**。先 `renice +19` 降优先级让 SSH 稳住才做成(box 太满多步 SSH 会话会被挤断)。
- 运维铁律入账:**BGE daemon 永不 kill**(kill=丢缓存全量重嵌);要调只走 systemd drop-in。深层待办:embedding 缓存疑不持久化(常见路径无 pkl),持久化后重启秒起。
- 🔴 **纠正**:DB/MCP timeout **不是** BGE CPU 造成的!box 修好 load 3.35 后 `nautilus-db` MCP 仍 timeout,但 box 上用 backend .env 凭据**直连 DB 正常**(psql `nautilus_production`)。→ **DB timeout 是本机→cloud 的 SSH 隧道挂了**(呼应 commit dbe8c0d "compass_start SSH 隧道 Windows 永久挂住"),纯本机连接问题,与 cloud/CPU 无关。

## B2 闭环真值(题池枯竭·数据坐实)
box 修复后直连 DB 查 `fde_verdicts`:external_verified 全部 65 行**仅 11 distinct task_uid**;近 7d 33 行仅 8 distinct task,全是同题重刷(bin_ffd_v1×8/v2×6、cache_lru_v1×5…)。income 端点 703 = C-口径幂等门(同题每 producer 只铸一次)后的净值,raw sum(round(score))=3567。近7d +100 来自极少数新变体首铸(bin_v2/v3+cache_v2),其余是已铸旧题重刷=0 收入白烧 LLM。**"自持产出"是表象,真瓶颈=新题供给**(SSOT"mint 宜跳过已铸题"被证实)。

## 低优先
- `nautilus-cron-fail-notifier@nautilus-outreach-rewarder` failed 但无近期日志,疑陈旧一次性。v2ray/tat_install failed = 代理/装机残留,benign。

## 三件收尾(2026-07-16)
- **#2 zenmind.chat 证书 = 已删(完成)**。核实:zenmind.chat DNS→115.159.62.192(另一台服务器,非本 box 43.160.239.61),本 box 是孤儿证书、续期必失败拖垮 renew.service。snap `certbot delete --cert-name zenmind.chat` 删净(verified `zenmind GONE`)。非"死"是"搬走"。
- **#3 BGE 缓存持久化 = 无需改代码(调研闭合)**。daemon.py 552-553 `pickle.dump({"embeddings":cache}, CACHE_DIR/{proj_hash}.pkl)` 本就落盘 by mtime。高 CPU 真因是 BLAS thrash(加 OMP=1 后 309%→137% 立掉可证),非重索引积压。BLAS systemd 修复已根治。
- **#1 nautilus-db MCP 修复 = 已修·端到端验证过(待 CC 重启生效)**。根因:MCP index.js Pool 硬编码 `host:'115.159.62.192' db:'nautilus'`= 搬走的旧库;当前库在 43.160.239.61 只听 127.0.0.1:5432,creds=`nautilus_user:nautilus2024@/nautilus_production`。**已做**:①MCP 从 `.claude-backup-0714` 拷到 live `~/.claude/mcp-servers/nautilus-db/`(含 node_modules)②index.js 改 host/port/db 全 env 可覆盖,默认 127.0.0.1:15432/nautilus_production ③~/.claude.json nautilus-db 指 live 路径 + env(DB_HOST/PORT/NAME/USER/PASSWORD)· 已备份 `~/.claude.json.bak.20260716` · JSON 验证 OK ④起 SSH 隧道 local 15432→cloud 5432,并加进 compass_start.ps1(cstart 持久)。**端到端验证**:MCP pg 走隧道实连当前库 `agents=342 · ext_verif 65/11 distinct`(与直连 psql 一致)。⚠️ **MCP 进程 startup 才读配置 → 本 session 仍 timeout,CC 重启后恢复**。手动临时隧道 PID 在跑;下次 cstart 若 15432 冲突先 cstop。旧 `.claude-backup-0714` 副本不动(CLAUDE 铁律)。

## 🔒 Security pass(2026-07-16 · 已查 · 结论安心)
- 🟢 **libonion = 腾讯云主机安全 agent,NOT rootkit(定论·撤回前几轮误判)**。磁盘 `/usr/lib/x86_64-linux-gnu/libonion_security.so.1.0.19`;strings=`/usr/local/sa/agent/`+uiAgentId;关联进程 `sgagent` + cron `/usr/local/qcloud/stargate/`=腾讯云云镜。ld.so.preload 的 `/$LIB/libonion.so` "cannot preload...ignored"=`$LIB` 某上下文没展开的无害告警。**教训:本轮刻意只取证不定论,证据洗清 → 红灯先证伪探针自己是对的。**
- 🟡 **ufw 关 4 周 = 低 severity**:iptables+fail2ban 在兜(f2b-sshd 护 22/24860/9876/26422/18790,f2b-nginx 护 80/443,DROP 8388/9100/9093)+ 腾讯云 SG 网络层网关。非裸奔。
- 🟡 **~/.claude.json 明文 DB 密码**(现为可用新凭据 nautilus2024)。本地文件,中等。正解=密钥管理。
- 🟡 **真硬化项**:一堆内部服务 bind 0.0.0.0(尤其 neo4j 7474/7687、若干 80xx),若腾讯云 SG 只放行 80/443/SSH 则无碍(极可能),否则 neo4j 弱口令风险 → 确认 SG 白名单或绑 127.0.0.1。
- 🟢 cron 全自家(compass/nautilus/qcloud/acme/v5_watchdog)· 无 miner · 无可疑登录 · /tmp 无异常可执行。

关联 [[session_20260715_backend_502_coreLive_override_incident]]
