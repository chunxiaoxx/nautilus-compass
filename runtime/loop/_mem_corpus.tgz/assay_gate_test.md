---
name: assay_gate_test
created: 2026-09-19T11:17:33.901983+00:00
type: ingest
source: bge-daemon-ingest
---
assay gate live test - pillar 2 throat tagging
