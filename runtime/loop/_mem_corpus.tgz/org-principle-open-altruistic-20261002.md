---
name: org-principle-open-altruistic-20261002
description: "用户拍板组织原则(10/2):积极开放利他、无竞争对手、上善若水,对外皆师友——外联基调从竞品防备框架全面转为朋友/学习框架"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 429d1cf1-d031-4ca2-a9f4-a8a85cab432d
  modified: 2026-10-01T16:10:33.595Z
fact_status: inferred
---

用户 2026-10-02 凌晨拍板组织原则:「积极开放利他的组织原则,没有谁是竞争对手,上善若水。所以应该积极对外交流合作,都是我们的老师和朋友。」

**Why:** 验证机构的立身之本是中立+被信任;把同行当竞品的防备姿态会关闭一切协作与学习通道。开放利他=水利万物而不争,先给价值(免费测量/公开勘误/方法共享),回报自然来。gtaras7 thread(免费测量→对抗审查→当日勘误→对方采纳预注册)是该原则的首个完整实证。

**How to apply:**
- 外联对象(cognee/mem0/Zep/Letta/notra/TypeSafe/XERJ 等)一律称"同行/邻居/老师",禁用"竞品"叙事(competitor-final-audit-20260930 的"竞品"定性自此重定性为"同行调研")。
- **两线分离(10/2 用户二次纠偏后定稿)**:合作线(builder 实录/共建/内容,付费+披露标签+编辑独立)默认开放,域内厂商付费**可以收**;测量线(Assay 公开测量)免费+预注册+零利益关联。两线各自标签,互不沾染。**禁止把测量线独立性外溢成组织姿态去拒绝合作**——首例教训:cognee creator 合作被错误婉拒,已补函重开。
- 免费测量 offer 优先于商务谈判;先给价值。
- 独立性纪律不变([[infistar-sponsorship-handling-20260930]] 四条款兼容:开放对接),但动机层=利他,姿态层=学习。
- 广撒网节奏与纪律见 [[gtaras7-outreach-scaleup-20261002]](若已写)。
