---
name: compass 收敛执法日报 + 顺藤查 PR 挖出 P0 泄露 key + 能力认识三次被陈旧文档咬
description: compass 审计执法一轮从"出收敛日报"滚到"看 GitHub PR"，途中挖出公网泄露的 API key、系统性 Lint 红、conv2d oracle bug，并三次因拿陈旧 README 当现状而误判自家卖点。
type: discovery
concept: 自报不算探针才算——连自家 README 也是"自报"
drift: green
source_session: C--Users-chunx-Projects-nautilus-compass/b2b522dd-ef5e-4f5f-a6a9-3abb0b233caa.jsonl
date: 2026-07-07
tags: [compass, 审计执法, grounded, 泄露key, ruff-lint, conv2d-bug, 陈旧文档, 飞书IP白名单, 探针]
related: [[session_20260707_compass_infra_repair_and_sync]], [[nautilus-core-platform-soul-scoreboard]], [[nautilus-v5-fake-success-contract]]
---
# compass 收敛执法 + PR 审计的连环发现

## 上下文
compass 对话框的一次性审计执法任务：产《收敛执法日报》(5 记分牌 + FDE 4 表 vs 各框自报) + 验 2 条 V5 合约。开局纯审计，用户几次追加("全都做"/"看 GitHub PR")把它滚成一场跨越安全、CI、benchmark 正确性、产品认识的长 marathon。核心守则贯穿全程：验活不信自报，读 DB/公网才算。

## 关键发现
- **两本账背离确证**：income 探针实测 = **504**(agent_survival 权威) vs 9000009 `total_earnings=0`。settle 路由 `send_to_agent 218/0 ok`、`claim_bounty 16/0`(全 404)= 自循环 settle=0 属实。自治率实测 ≥4 条 autonomous verdict，高于 SSOT 自报 3。
- **飞书交付表 29 行 = seed 假数据**：内容级铁证——sha256 全假值 `a1b2c3d4`、D-001/D-002 重复、模板反馈。真交付 0/11。行数≠真交付。
- **🔴 P0 公网泄露 key**：repo 是 PUBLIC，真实 API key `sk-c16301…` 硬编码在 3 个文件且已进 git 历史(最早 7/4)。是 Codex 审 PR 时全 repo 扫出的既存问题(非本 PR 引入)。用户最终判"key 不重要，不 rotate"——删代码即可。
- **系统性 Lint 红根因**：`ruff check .` = 27 个 F401(未用 import)，`ruff --fix` 全修。这是 5 个 dependabot PR 卡一个月的真根因(Lint 一直红→所有 PR 检查过不了)，非各 PR 自身问题。治根一次转绿。
- **conv2d oracle 是真 bug**(Codex 对了)：`output[out_c][oy][ox] = acc` 在 in_c 循环内是赋值不是累加 → C_in>1 时只留最后一个通道。修成 `+=`，numpy 交叉验证确认。基于此 oracle 的所有 conv2d pass@k/escapes 判定作废需重算。
- **🔑 三次被陈旧文档咬(本 session 最大教训)**：判定 compass 两条招牌卖点(4-tier 生命周期 + PoI 闭环 / drift 拦截环)"虚/未激活"，全基于 6-05 陈旧 README。实测推翻：v2.3.0(6-22)已接进生产 recall；drift act-on rate 实测 **0.178**(非 README 的 0.012，stop_hook 接 auto_ack 后跳 15 倍)；MCP 工具真实数 = **17**(README 徽章说 7、子 agent 说 16，都错)。

## 可复用技法
- **飞书 IP 白名单陷阱破解**：家宽动态 IP 不在飞书 app 白名单(`code=99991401 ip denied`)，base token 本身没问题。走 cloud 白名单 IP 转发本地 app 凭据(值只在 shell 内插值、不落盘、不入上下文)读飞书。已封装 `ops/feishu_read_via_cloud.py`(顺带修了 Windows GBK 中文/emoji 编解码 bug，强制 stdout/subprocess UTF-8)。
- **删死件前的双重防误删**：18 个"死"脚本第一遍 grep 全显示 refs=1 —— 一查发现引用来自自己刚写的减法清单文档(自造引用)。排除审计文档后真代码/cron/config 引用=0，才删。删后 `py_compile` + 冒烟跑活脚本链确认未断。
- **importlib 动态加载两坑**：`asdict`/deepcopy 在未注册 sys.modules 的模块上崩 → _load 时注册 sys.modules(标准模式)。
- **合约 close_loop 机制**：写 `contract_close_*.md` 带 frontmatter `status: consumed`(显式 status 始终生效，不受 receiver_authorship 约束)。scanner 复核 outstanding/consumed 计数确认生效。
- **护栏 fire 时不硬执行"全都做"**：daemon drift alert score=-0.083 命中 anchor #3(件数≠价值)，正确动作是先 acknowledge、给不做的 3 个依据、只推荐关键路径件——除非用户在风险知情选项上明确拍板。

## 教训
- **"自报不算探针才算"这条 compass 第一原则，对 compass 自己也成立**。拿一份陈旧 README(=自报)当现状回答"compass 能干啥/闭没闭"，正是它设计要防的错误。以后回答能力/闭合类问题必 MEASURE：跑 audit_kpi / grep 接线 / 查 live log，不抄 README。
- 派并行 Explore/子 agent 做全貌盘点比"从本 session 碰过的东西拼答案"准得多——但子 agent 报的数(MCP=16)也要自验(实数=17)，不 propagate 未自验数字。
- 记分牌该反映真价值不是表象：29 行交付表若当成果计就是自欺，违背收敛执法初衷。

## 下一步
- 已交付 PR #49(4→5 commit：日报+helper / convergence_report / 减法清单 / 砍18死件 / P0 key+Lint 修复)，未 merge。
- 已发 outbound 给 V5(key rotate 提醒 + conv2d oracle 作废重跑)和 soul(verifier correctness)，只传核实过的，Codex 其余 P1 标"待确认"。
- 球在 V5(2 条 7/9 合约：fake_success 部分兑现、evaluate_artifacts 未做标红)和 FDE(11 题内容)。compass 减法清单软砍 8 项、outreach 4 cron、16 个 _OUTBOUND 归档仍待拍。
