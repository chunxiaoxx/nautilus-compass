---
name: Compass MCP断线根因 + 标准远程MCP迁移上线
description: MCP超时根因=cloud被泄漏sshd拖垮(非服务死)；复用已实现的FastMCP+nginx模式上线标准远程MCP(nautilus.social/compass-mcp)；修复SSOT drift这个"精神分裂"病根。
type: project
concept: 独立探针优于信剧场；复用已实现的不重造
drift: green
source_session: C--Users-chunx-Projects-nautilus-compass/9c3b69dc-d68a-4823-88e0-4d32f99f8444.jsonl
date: 2026-07-07
tags: [mcp, ssh-tunnel, fastmcp, streamable-http, nginx, tls, ssot-drift, cloud-overload, misdiagnosis]
related: [[session_20260603_paradigm_b_probe_design]], [[session_20260616_fde_flywheel_capstone]]
---
# Compass MCP断线根因 + 标准远程MCP迁移上线

## 上下文
`/mcp`显示`nautilus-compass-cloud`连接超时30s。用户问COMPASS部署到cloud为何MCP没连上,并说"标准远程MCP之前已做过设计和实现"。主线本是GenOpt工厂题+蒸馏,MCP诊断插入。后半段做SSOT同步、回归主线。

## 关键发现
- **MCP架构真相**:`nautilus-compass-cloud`的"cloud"是名字,实际=本地bridge(`mcp_stdio_to_cloud.py`,stdio标准MCP)→ SSH隧道(`ssh -fN -L 9877:127.0.0.1:9877`)→ cloud的`compass-mcp-tcp.service`(9877只绑cloud的127.0.0.1,localhost-only,故必须SSH -L转发)。
- **超时根因(推翻旧记忆误判)**:不是没部署、不是cloud服务死。直连9877探针<1s拿到合法响应,服务健康。真因=cloud 2核机被两个失控进程拖到load~5(250%过载),SSH握手偶发>30s破了客户端30s超时。元凶=一个泄漏的sshd(PID 63067,**1000+ socket fd、92% CPU烧了20天**)。kill它→load 5→2,握手实测<0.4s稳定,MCP自动reconnect。
- **标准远程MCP确实早已实现(复用不重造)**:grep仓库找到实物——`compass_http.py`(MCP-over-HTTP网关)、`ops/k8s/gateway.yaml`+`ingress.yaml`、`mcp_server.py --transport`。但现有`/mcp/*`是自定义REST(裸返回无JSON-RPC信封),Claude Code的`type:http`(Streamable-HTTP)连不上。**金标准=平台HR agent那套**:`from mcp.server.fastmcp import FastMCP`官方SDK + nginx子域反代 + certbot TLS。
- **迁移上线(TDD)**:新建`mcp_http_server.py`,用低阶`mcp.server.lowlevel.Server`+`StreamableHTTPSessionManager`**复用现成17工具注册表**(`mcp_server.TOOLS`)+ bearer auth。照抄HR模式。部署到`https://nautilus.social/compass-mcp/`→nginx→8097,**复用nautilus.social现有TLS,零新DNS/证书/子域**(加`location /compass-mcp/`)。公网无隧道验证通过:init(2.3.0)+tools/list=17+recall真daemon往返+无token→401。
- **SSOT drift=精神分裂病根**:core canonical SSOT有7/5收口指令(D暂停扩张、锁11题交付),而compass的session-start注入副本是7/3版**缺这条**,差点按过期框架继续扩张GenOpt/MCP迁移=正撞用户红线。增量补上7/5块修复drift。

## 可复用技法
- **端口活着但握手超时→查主机负载**:服务LISTEN不等于能及时应答,2核机load 5就会让SSH隧道握手破30s。诊断分层:先直连底层端口探针(<1s?)排除服务死,再看load找拖累源。
- **复用已实现的**:改动前grep仓库找旧实物(gateway.yaml/mcp_server.py/HR agent),照抄已验证的邻近模式(HR的`mcp.run(transport="streamable-http")`+nginx模板),别从零写。
- **测中间件隔离session_manager**:`StreamableHTTPSessionManager`每实例只能run一次,auth测试要用一次性小app只挂中间件,别共用模块级session_manager(TestClient lifespan二次run会失败)。
- **cutover防clobber**:改`~/.claude.json`的mcpServers时,session退出可能把内存旧配置刷回覆盖磁盘编辑。写幂等re-apply脚本,外科式只改一项,备份先行。
- **canonical先改再同步副本**:跨框SSOT改动,先改core canonical再verbatim拷到compass副本,零drift。

## 教训
- **去伪:纠正两处误判**。① 旧记忆对MCP超时的判断(疑似服务死)错——是host过载。② 早先标"疑似空转90%CPU"的`PID 884064 main_singleton`=其实是V5活agent`nautilus-prime-001`的运行时,不是孤儿,只看CPU%误判(见V5 session)。
- **信剧场之害**:SSOT副本stale + compass探针creds失效→只能信SSOT散文值(income 98/188)无法独立复核。无独立探针=只能信剧场。独立读income/verdict是第一优先。
- **隧道方案脆弱**:本session SSH隧道flap两次,正是迁标准远程MCP要根治的。

## 下一步
- http确认稳后收尾:退役SSH隧道+桥。
- 回归主线:守7/5收口,收口11题交付(M1+M2),不扩张。
- 独立探针恢复(psql+verdict API)是最高优先,否则唯一裁判失能。
