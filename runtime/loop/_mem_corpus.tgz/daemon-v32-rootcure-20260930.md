---
name: daemon-v32-rootcure-20260930
description: 云daemon根治v3.2四刀(numpy 8x实证/预算制/listen前置/MSG_PEEK豁免)+蓝绿备件就位待10/1 08:53读数后窗口;合成压测175.8MB对齐生产1469MB;MAX_PROJ红线自修
metadata: 
  node_type: memory
  type: project
  originSessionId: e01698b5-ca0c-4d79-8423-11cb0e107d82
  modified: 2026-09-30T08:32:09.597Z
fact_status: inferred
---

2026-09-30 云 daemon 根治方案 v3.2(用户令"真正长期有效的方案")全链落地,待窗口切换。

**根因四层**(实证):PyList 32KB/向量 8x 膨胀(根本)/LRU 与 pkl 回读互搏/in-flight 无豁免/bind 在 warmup 后(冷启动断服)。

**四刀**(runtime/cloud_daemon_v32_20260930.py,commit 94a7ef7f→01eba599):
1. numpy float32 化(惰性转换旧 pkl,单测 cosine 等价 1e-6)
2. 容量预算 300k 向量替代 MAX_PROJ=8 硬逐(churn 根因);**红线自修:MAX_PROJ=64 在 75 项目场景仍硬逐 11 个(压测实抓)→降级纯护栏 256**
3. listen 前置+warmup 后台+load 锁(重启零断服)
4. MSG_PEEK ping/status 豁免(churn 期监控不瞎眼)

**合成压测实证**(tools/v32_synth_bench.py):75 项目×600 向量仿生产规模,np 驻留 **175.8MB vs PyList 等效 1408.7MB=8.0x**,与生产 cache 实测 1469MB 吻合;J1 生产预期 RSS<3.5G 可达。

**蓝绿备件**(ops/v32_bluegreen_deploy.sh 五步幂等+runbook):已 upload 云端(md5 c5d64636);blue 步内置 <4000MB 熔断(系统仅 4.3G);**窗口铁律=10/1 08:53 记忆判据读数之后**;回退一步零确认;孤儿 pkl 10261 个/1469MB 刀 D 分离单独走(列清单确认后移档)。

[[ssh-cloud-port-2460-20260930]] [[daemon-9876-watchdog-rootcause-20260908]]
