---
name: competitor-final-audit-20260930
description: 竞品终核四项全定谳——mem0领投纠错(Basis Set非Abstract)/Zep独立运营+转型治理层(收购=幻觉)/TypeSafe proof不可寻址+同页双口径(171x/75x≠193.6x/444.6x)/Letta $10M seed Felicis
metadata: 
  node_type: memory
  type: project
  originSessionId: e01698b5-ca0c-4d79-8423-11cb0e107d82
  modified: 2026-09-30T02:56:56.878Z
fact_status: inferred
---

2026-09-30 竞品终核(总纲 §七 定稿,commit 240f4499;弹药成文 docs/marketing/dcr_ammo_competitor_audit_20260930.md)。四项全定谳,一条训练知识纠错:

1. **mem0**:$24M($3.9M seed+$20M A 轮),**Basis Set Ventures 领投 A 轮**——训练知识"Abstract Ventures 领投"是错的。Kindred 领投 seed;YC/Peak XV/GitHub Fund 跟投;AWS Agent SDK 独家记忆商;API 调用 Q1 35M→Q3 186M。源:TechCrunch 2025-10-28 Tage Kene-Okafor。
2. **Zep**:独立运营定谳(zep.ai 一手署名 Zep Software, Inc.+卖 Cloud/BYOK/BYOC);"被 NVIDIA 收购"=训练知识幻觉。已从 agent memory 转型"企业上下文治理层"(Context Lake/Konig;LoCoMo 94.7%/LME 90.2% 全自报)——治理叙事与我们正面对位,差异化钉死第三方可复算独立性。
3. **TypeSafe**:"193.6x/444.6x (proof)" 的 proof **不可寻址**(首页 (proof) 无链接、HTML 无 href、/pricing 404);同页 demo 复算 171x 成本/75x 延迟≠headline(同页双口径);$42/B tokens×"238x vs Fable 5.1"≈$10/M 自洽可反算。calibration-claim-verify 第一活靶已打=DCR 卖点活广告。
4. **Letta**:$10M **seed**(非 A 轮),Felicis(Astasia Myers)领投,$70M post-money,2024-09-23 出 stealth;至 2026-09 无后续轮。源:TechCrunch 2024-09-23 Julie Bort。

**技法存档**:webReader 配额周恢复后,终核动作=官网一手(博客列表页查融资公告)+TechCrunch 站内搜索(?s=)+正文直抓确认领投方;链接真伪用 curl grep href 验(首页"(proof)"字样≠真链接)。训练知识的融资细节(领投方)错误率高,引用前必核。

[[verification-commercialization-20260915]] [[outreach-channels-20260911]] [[examhall-charter-20260916]]
