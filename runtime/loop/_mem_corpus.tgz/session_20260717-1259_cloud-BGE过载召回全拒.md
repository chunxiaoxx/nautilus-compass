---
name: cloud-BGE过载召回全拒
description: 🔴 cloud compass-bge-daemon 常态 CPU 打满(127%·5GB),/v1/v14/recall 全部回"daemon overloaded - retry"→ cloud 上所有 agent 记忆盲(reborn 271/271 呼吸 hits=0)。请 compass 框诊断
type: discovery
concept: gotcha
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: episodic
decay_rate: 0.5
promote_after: 5_access
reinforce_count: 25
---

# cloud-BGE过载召回全拒

## 上下文
🔴 cloud compass-bge-daemon 常态 CPU 打满(127%·5GB),/v1/v14/recall 全部回"daemon overloaded - retry"→ cloud 上所有 agent 记忆盲(reborn 271/271 呼吸 hits=0)。请 compass 框诊断

## 内容
2026-07-18 V5 框 grounded 排查链(全实测):

现象:reborn 影子 271 口呼吸的 compass_recall 全部 hits=0。
排查:① compass 服务在 cloud 全活(daemon.py:9876 / compass_http_v09:8770 / mcp_server:9877)② client 参数正确(发 q 非 query)③ 直接 curl http://127.0.0.1:8770/v1/v14/recall?q=... → {"ok":false,"error":"daemon overloaded - retry","backend":"v1.4-bge-m3"} = 根因。
负载证据:PID 1419913(compass-bge-daemon.service)127% CPU / 5GB RSS;journalctl:7/07 18:30 起跑到 7/16 00:04 累计消耗 1w1d21h CPU;7/16 17:35 重启后至今又 2394 CPU 分钟(≈3 核连续打满)。重启史表明重启即再打满 = 结构性(疑:embedding 回填死循环 / 队列无界 / recall 与 embed 同池互饿)。
影响:cloud 上一切依赖 recall 的 agent 都是记忆盲。V5 侧 client/shadow 接线已验证正确,daemon 恢复健康后 reborn 长期记忆零改动点亮。
建议给 compass 框:① 查 daemon 忙在什么(py-spy/日志)② recall 读路径与 embed 写路径分池,读路径轻量降级(metadata fallback 而非全拒)③ 每日探针加"cloud recall 可用性"读数(自报不算)。
另:纠错记录——V5 框此前判断"compass daemon 只在本机、cloud 够不着"是错的,用户纠正后实测推翻,daemon 一直在 cloud。
