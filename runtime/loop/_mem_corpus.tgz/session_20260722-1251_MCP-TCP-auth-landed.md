---
name: MCP TCP auth landed
description: token-gated TCP transport for cross-machine A2A
type: feature
concept: how-it-works
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# MCP TCP auth landed

## 上下文
token-gated TCP transport for cross-machine A2A

## 内容
mcp_server.py --transport tcp --token SECRET now accepts concurrent JSON-RPC clients. Bad token → -32001. Strips authToken before forwarding to handle_message so it never leaks in logs.
