---
name: day-log-20261002-gtaras7-erratum
description: 10/2 全日主 log——gtaras7 勘误闭环(方法论被采纳)/daemon 真部署抓出 10/1 假部署/提前点火 A 系列三 RED 转 P0-full/超长会话升格-疲劳定律
metadata: 
  node_type: memory
  type: project
  originSessionId: 429d1cf1-d031-4ca2-a9f4-a8a85cab432d
  modified: 2026-10-02T10:07:28.609Z
fact_status: inferred
---

2026-10-02 超长 session(23:31-20:30+,R21-R37)四线主 log:

**①gtaras7 勘误闭环(组织级里程碑)**:他逐项验证 mini-report 抓出散文层错误(unclear 2/27 被写成类别互换)+证伪 flag leakage(性别代理,我方独立复现 18/0/22-16/IT4 精确匹配后才撤)→当日勘误+Brier 口径主动披露→**他把预注册方法论采纳进自己 evals/README**。三层复算 9 项全绿定谳错误仅在叙事层。教训:预注册只许定判据**不许定叙事预期**(模板预设"有趣结果"裹挟散文)。

**②daemon 生产战役**:R36 发现 **10/1 "v3.3 部署成功"是假的**(unit 被 deploy-path.conf 覆盖,云上从未有 v33 文件;教训=部署必须验进程 cmdline 非服务活性)→真部署 RSS 5.05G→2.6G 减半→recall 全挂 3h/195 次→云上打栈补丁 1 分钟定位两处 numpy 数组真值笔误(888 'and vecs'/1186 'if not embedding')→修复+栈补丁收编正本 v3.3.2(双侧 md5 一致 ae922039)。48h 观察至 10/4 16:20。

**③新模型点火(用户 17:0x 解冻 10/26 冻结令)**:锚点库 anchor_v0 落地(1454 零编造零泄漏)→A 系列判据三连 RED 有价值:P0-lite 天花板(无头 98.7%=风格泄漏非因果能力)/A2v4 桥为零(hit@5=0)→**P0-full(14B)升级依据坐实**。双主干对拍下载中(Qwen3-14B 正传+Qwen3.8-14B-Instruct-Turbo 社区蒸馏版,判据档 P0_FULL_PREREG F1-F4)。**2026 开源生态实况:各家旗舰全 MoE 巨型化(GLM-5.3-Flash 也 320B/DeepSeek-V4.1 763B),单 40G 卡对旗舰全体无解;中小稠密主力=Qwen3 系+社区蒸馏**。SSI 对照臂入蓝图 v0.1(用户拍板)。

**④元发现:升格倾向与疲劳时长正相关**——当日四处叙事错误(@file/时间漂移×2/总档 M2+代码联邦两处升格)全部产自超长会话后半段;对策=战略函不在疲劳端写(实证:flywheel 第五场两问回执延至 10/3 新会话)。

其他:lint-report 落地(L1-L6 全绿,昨晚错误 12h 变产品)/Report#3 全链完工/GitHub org Nautilus-agent 上线(代码联邦基建)/MASTER_PLAN v1.1(compass 草案)/主仓 39 commits+论文仓已 push。交接:双 14B 下载收尾→P0-full 提取/flywheel 两问 10/3 上午/MemOS 22:00/daemon 关单 10/4。关联 [[org-principle-open-altruistic-20261002]] [[daemon-v33-switch-20261001]]。
