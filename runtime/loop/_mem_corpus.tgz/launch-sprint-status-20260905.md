---
name: launch-sprint-status-20260905
description: 9/8 发布冲刺全景——物料清单位置+用户拍板方向(新共识叙事/造词)+nginx /mcp 8443 陷阱+用户侧阻塞清单
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-05T08:04:20.244Z
---

9/8(周二 21:00 北京)发布冲刺状态(截至 9/5):

**用户拍板方向(9/5 两条,统领所有物料)**:
- "破圈核心=形成新共识,依靠我们的叙事引领话语权" → 纲在 `docs/marketing/narrative_core_20260905.md`(五条共识断言:①覆写 ②写入时赌注 ③写入零LLM ④判分卫生 ⑤dogfood;话语权=把做法变公共品)
- "制造新词,定义新词,掌握新词" → `docs/marketing/lexicon_20260905.md`(Judge Hygiene 主打造词·查重空缺;Write-Time Wager 收编定型·Rune/Mem0 已用 bet 语言无定义;词已进 README Glossary+paper2 摘要/贡献/正文三处钉穿)

**物料全家桶(全在 docs/marketing/)**:PPT v2 19页深色可视化版(deck_assets/ 13图,make_deck_charts.py)、金句卡5张(quote_cards/,make_quote_cards.py)、公众号封面2张(zh_covers/,make_zh_covers.py)、HN文案(launch_plan §14)、r-ML论文贴模板(rml_paper_post_template.md,等arXiv ID)、中文圈三件、content_pack(agent传播执行包)。**图表管线复用**:改字/改数→重跑脚本→marp 重渲染一条命令。

**🔴 nginx 生产陷阱(9/5 抓到修复)**:生效 nginx **非 systemd 管理**(systemctl 说 not active 但 443 活着)——reload 要 `sudo kill -HUP <master PID>`(9/5 时 616431),`nginx -t` 也须 sudo。`location = /mcp { return 301 /mcp/; }` 相对 301 被同文件 `listen 8443` block 污染端口,公网无尾斜杠 /mcp 直连死——已改直 proxy,备份 /home/ubuntu/compass.bak.20260905。**改服务器 nginx 前先 ps 确认真身,别信 systemctl。**


**🔴 9/5 双洞修复(发布阻断级,已上线验证)**:① /mcp 无尾斜杠 301→:8443 死路径(nginx 直 proxy 修);② 自助 token 读写全断+跨租户读——scope 门禁把无 project 参数判 `read:''` 403,且 **HTTP 200 包 forbidden body = 假绿**(探针必须验 body 不只看状态码!);首修只放行检查侧,又暴露执行侧落 daemon 默认内部用户(cycle-N-auto)的跨租户读——**检查侧与执行侧必须同源 resolve**;终修=mcp_http_server._call_tool 缺省 project 显式注入 _current_user(持有者 uid)。四探针 FOUR-GREEN 复验。~~遗留:tools/list 17 个含 10 个平台内部工具暴露外部~~ → **tools/list 收敛已上线(b812332)**:公网自助 8 个/直调 forbidden/ops 17 个全见。🔴 部署教训:§12.1 假设 ops token 带 admin scope 是错的(tokens.json 实为 tools.read/write 旧格式),首版把 ops 也关进 8 个=生产破坏,ssh 本地 ops 视角复验当场抓到——**对外行为变更部署后,必须分 token 类型各自实测视角,不能只验一边**。

**9/5 深度材料两步走完成(用户批评"材料基础/无系统/无深度"后拍板方案 C)**:①白皮书 `docs/marketing/whitepaper_20260905.md`(v1.1,11 章——参考 nautilus-core 平台白皮书 TECHNICAL_WHITEPAPER_V2.md 结构,含生态定位/架构决策记录/归因链/判官病理学/评测版图诚实定位/路线图开放问题/bibtex);②深讲版 PPT `pitch_deck_deepdive_20260905.md` 39 页七幕(30/15/5 分钟裁剪规则),从白皮书裁。**🔴 挖数中抓到发布阻断级错误并修正**:检索对打 evidence 原文=各用默认嵌入(bge-m3 vs mem0 text-embedding-005),6 处物料曾写"same embedder/BGE-m3 双方"假声明(Reddit/HN 首评/Bluesky/知乎/V2EX/PPT)——已全修+launch_plan §6 补应答模板+PPT 重渲染。归因链定案口径:42.6(8/29)→70.0/81.6(9/3 摘要层=方法+27.4pt)→75.4/81.6(9/4 重判=测量+5.4pt);56.7% 是 n=30 配对轮不入主链。

**9/5 深讲版 PPT v3 视觉重做(用户两轮批评"纯白/无版式/错层"后)**:根因 fitz 量化坐实——①v2 全系统无实色区块,内容页非白像素仅 13-16%;②7 页大图底边 546-600pt 超页高 540 被裁 11-15%(=用户看到的"错层",v2 只查文字块漏检图 bbox)。修复=实色页眉带 62px+卡片实色底+深色表头+9 页整页渐变色块+8 图非白底装裱+大图 `![h:372]` 高度约束。量化验证:全页非白 22%→40.1%,图被裁 7→0,越界 0(commit 265701f)。**元教训:验证视觉必须量化渲染产物(非白占比/元素 bbox),grep 类名=自报;marp 改 padding 后图必须用 h: 约束;marp 渲染用本地缓存二进制(`~/AppData/Local/npm-cache/_npx/e0d73ab2e0dfa94b/.../bin/marp`),npx 联网解析会卡死。**

**9/5 晚间发布准备收口**:①信箱清零(168 C2销案 ack · 172 飞书指令入口征求意见已回函 id174:拍板/数字类只读不自动回执+人工必读档+影子模式一天);②launch_plan §6 补两条应答(官方榜名次=预算1/8·延迟1/47·判分口径三差异;比最弱RAG低=诚实定位是卖点)与深讲 v4 效率轴叙事同步;③数字纪律排查:71.1%=基准论文官方 pilot ChatGPT 易版分(作者自测,合法),56.7% 零残留;④🔴资产风险修复:19页路演版 pitch_deck_20260904.md 源文件从未 commit 且丢失(只剩产物)——从 PDF 逐页提取重建并升级 v4 版式,三格式重渲量化验证(commit 09-05 晚)。**教训:md 源文件当页写完当页 commit,不要攒。**

**用户侧阻塞(9/5 全量)**:GCP OAuth 转 production 或 App Password(邮箱验证部署最后一步)/ paper2 arXiv 提交(术语强化版已备)/ demo 录屏(脚本就绪)/ PyPI 发 3.1.1 凭证 / Reddit karma 预热。
**邮箱验证真实状态(9/5 午间澄清,推翻"等凭证从零开始")**:用户 9/5 00:17 已亲填 `/etc/compass/mail.env`——`EMAIL_REQUIRED=0`(兜底值未动)+`SMTP_PORT=587`+HOST/USER/PASS/FROM **留空**;生产行为与配置一致(signup/login 正常无门禁),**无 bug 无需 restart**。🔴 读数陷阱:我 awk `print $1"="length($2)` 把**值长度**误读成值,连造两个假观察("EMAIL_REQUIRED=1 已设"+"spawn worker 丢 env")绕了 40 分钟——**读 env 必须输出 repr(值),禁止 length/格式化拼接**。Gmail 方案B 的 refresh_token(~/.gmail-mcp/credentials.json)已死(GCP consent screen testing 模式 7 天过期,invalid_grant)——方案B 要等 consent screen 转 production 后重新授权;更快路径=用户开 2FA 生成 App Password 填 HOST/USER/PASS/FROM+EMAIL_REQUIRED 改 1+restart。**smtp 空时勿先改 EMAIL_REQUIRED=1 再 restart——signup 会全 503**,顺序必须是凭证先落、门禁后开。

**回归门基线**:全量 pytest 1660 passed 8 skipped(mcp_durable 15 失败=契约迁移非回归,跑时 --ignore);consumer matrix 注册表=端口引用文件的唯一台账,新文件连 9876 必须登记。相关:[[lmev2-judge-401-envvar-pitfall]] [[no-jargon-user-correction-20260829]]
