---
name: session_20260716_eval_recall_v230_rerun
description: "2026-07-16 v2.3.0 eval_recall 实测:bge-m3 地基 P@1 0.969/MRR 0.980 极强;poi/tier/gemini 三层全 +0.000(语料 131 条 0 impact/100% working/gemini off = 无信号,非逻辑坏)"
metadata: 
  node_type: memory
  source_session: 2026-07-16 compass 跑分状态确认
  type: project
  originSessionId: e4544c1e-7207-4060-8121-a054066dcec8
reinforce_count: 50
---

# compass v2.3.0 跑分实测(2026-07-16 · 独立复现)

用户问"能否跑分对比 / 记忆胶囊等功能实现了吗"→ 按铁律实跑 `tests/eval_recall.py --mode all`(非看台账自报)。

## 结果(本机 cuda · C--Users-chunx/memory 131 条 · leave-one-out)
```
mode      P@1     P@3     P@5     MRR
flat     0.969   0.992   0.992   0.980
poi      0.969   0.992   0.992   0.980  (Δ +0.000)
tier     0.969   0.992   0.992   0.980  (Δ +0.000)
gemini   0.969   0.992   0.992   0.980  (Δ +0.000)
```
语料诊断:cumulative_impact!=0 → **0 条**;tier!=working → **0 条**;Gemini off。

## 判读(第 3 次独立坐实同一结论:设计文档 → 6/24 FEATURE_VALUE_LEDGER → 今天)
- **地基 bge-m3 召回极强**(P@1 0.969/MRR 0.980)。131 条语料比 6/24 的 1106 条干净,绝对值更高,不直接可比;但 **Δ=0 结论一致**。
- **poi/tier/gemini 三层 lifecycle 功能全 +0.000**:根因=**语料无元数据信号**(0 impact/100% working/gemini off),harness 数学上无从作用 → **不是逻辑坏(rerank TDD 证模式真切换),是语料无信号**。
- **实现 ≠ 证明有价值**:capsule_schema/tier/reinforce/poi_rerank 代码实现、部分部署(见 [[session_20260715_cloud_box_health_audit]] 无关;详见 repo docs/FEATURE_VALUE_LEDGER.md + proof/value_gate.py 价值门),但下游 uplift 实测 0.000。记忆胶囊本身还 gated 在 V5 写端(V5 不产胶囊即空转)。

## 要量出真 lifecycle delta 的前置(不满足前别再本机重跑,还是 0)
1. 在**盒 9720 语料**跑(那里 tier 晋升真跑过、PoI impact 非零)。
2. 先**降晋升门槛**让分层不那么稀疏(盒 9720 仅 2 胶囊过 impact 门)。
3. 让 V5 写端真产胶囊(激活 capsule_schema)。

## 元
系统自带 value_gate（proof/value_gate.py）拒绝"已写代码=有价值",本结果是反-D 锚(件数≠价值)的活样本。这是"独立验证优于自报"第 N 次兑现。

关联 [[anchor_anti_patterns_history]]
