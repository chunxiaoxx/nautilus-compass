---
name: gpu-old-disk-restart-20260903
description: "GPU 用旧盘重启实例是正路(全套环境秒级就位)——租新机前必查保留盘;9/3 实例 654686(js1.blockelite.cn:11224)踩坑:pip 缺失/24G 卡 vllm cudagraph OOM 须 --enforce-eager/pkill -f 自匹配又犯/get_connection_info 返回顶层无 data 键"
metadata:
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-03T03:48:47.456Z
---

# GPU 旧盘重启(2026-09-03 · 便宜档验证)

## 核心教训(用户纠正)

- **租新机前必查保留盘**:用户 8/31 定策"保磁盘不买自定义镜像"——旧实例(镜像族 ebc62635)的盘上全套环境(qwen35-9b/bge-m3/LME-V2 haystacks+screenshots/vllm 0.18.1),重启带盘实例秒级就位;我租新机重新部署浪费 ~¥30 包时(654656 已退)。
- 旧盘实例清单:get_instance_list **顶层就是 {"list": [...]},无 "data" 键包裹**(解析两次踩坑);保留盘本身不在 instance list(平台无盘清单接口,查计费靠钱包流水/DiskKeepped_Cost_per_time 字段)。

## 当前实例 654686(2026-09-03 用户重启)

- js1.blockelite.cn:11224 root(连接信息 get_connection_info,ssh_url 的 port= 参数+base64 密码)
- 4090 **24G**(不是 48G)、盘 96% 满(8.7G 空闲,够跑分输出)

## 2026-09-04 补:gpu_ssh.py 直传二进制会污染(md5 不一致)

- `python vtf/gpu_ssh.py "cat file.gz" > local.gz` 过通道后 md5 变(gzip -t 失败级污染)。
  **拉回二进制一律走 base64**:`gpu_ssh.py "base64 -w0 /path/file" | base64 -d > local`,传完 md5 对账(GPU 侧 md5sum vs 本地)。
- 文本小件(json/log)同样建议 base64,防 CRLF 混入。
- 顺带:本地 bash 工作目录跨 Bash 调用持久——上一条 cd 进子目录后,下一条的相对路径 cd 会失败,用绝对路径或先 pwd。

## 24G 卡 vllm 启动配方(踩实)

```
vllm.entrypoints.openai.api_server --model /root/data/models/qwen35-9b \
  --served-model-name Qwen/Qwen3.5-9B --port 8023 \
  --gpu-memory-utilization 0.90 --max-model-len 32768 --enforce-eager
```
- 不加 --enforce-eager:cudagraph 内存探测 OOM(模型 17.66G 后余量不够 capture),EngineCore failed
- 32k max-len 是 LME-V2 硬要求(memory 六坑定案)

## 本机环境三坑(新租机才有,旧盘机无)

- pip: command not found → apt-get install python3-pip
- deploy.sh STEP1 vllm==0.8.5 过时 → 0.18.1(RUNBOOK 矩阵未同步进 deploy.sh)
- blockelite 新机 exec channel 不收 stdin(writefile base64 流挂)→ 数据 inline 进命令 `printf '%s' '<b64>' | base64 -d > remote`

## 其他复发坑(再记)

- **pkill -f 自匹配 ssh exec 命令行**(第 3 次犯):按 pgrep 查 PID 再 kill
- paramiko nohup 后台链占 channel:启动与查询分开发

关联 [[gpu-instance-reuse-not-rent]] · [[lmev2-pipeline-smoke-proven-20260830]] · [[gpu-e2e-rootcause-chain-20260829]]
