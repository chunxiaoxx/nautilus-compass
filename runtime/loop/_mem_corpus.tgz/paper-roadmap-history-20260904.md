---
name: paper-roadmap-history-20260904
description: 论文线历史纠偏(用户 9/4 口述)——旧 paper2(Chinese LLMs recall gap·v0.8 56.6%)arXiv 审核未通过;当前 paper2=判官盲区融合版是另一篇(零引用旧稿结果);kimi 框也规划三篇论文待对齐
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-04T04:52:10.968Z
---

2026-09-04 用户口述补齐论文线历史(仓内无记录的部分以用户为准):

1. **paper1 已发布**:arXiv:2605.09863(2026-05-11·单作者 Chunxiao Wang·默认 license)。
2. **旧 paper2 被拒**:《Closing the Memory Recall Gap with Chinese LLMs》(v0.8 LME-S 56.6%·六模型对比)arXiv **审核未通过**——仓内 OUTLINE_PAPER2.md/paper2_main.tex 全套还在但已死线,勿再引用其数字作对外承诺。
3. **当前 paper2(=#41)是另一篇**:判官盲区融合版《Judge Failure in the Wild》——已 grep 证实零处引用旧稿结果(56.6/Chinese LLMs 无一处),同账号新提交不受旧拒审影响。
4. **排序**:新 paper2 九月内 → compass 系统 2.0(十月)→ 验证学习(Q4);理论底座=verification-learning-papers 三篇体系(GOAL_SSOT:22)。
5. **kimi 三篇已定位并核验(9/4 用户给仓+本地实读)**:`~/Projects/verification-learning-papers`(github.com/chunxiaoxx/verification-learning-papers)——①验证学习(无验证→空转)②判官盲区(同构验证→盲区·数值精度盲点定理·2600 调用·Kimi k3/MiniMax)③元理论(智能=压缩+验证)。
6. **统一论文路线图(无撞题,已 grep 核验)**:当前 #41《Judge Failure in the Wild》= **kimi 论文②的实身**(数值精度盲点定理完整织入 tex:37-48%@±0.1% 单调衰减等)+ compass 野生判官失效案例+卫生协议 → 九月内 arXiv;后续 compass 系统 2.0(十月)→ 验证学习=**kimi 论文①**(Q4)→ 元理论=kimi 论文③(更远)。kimi 骨架文件 paper2_judge_blindspot.tex 仍 Anonymous 未发布,融合版发出后该骨架不再单独投。

**Why**:论文身份混淆的代价高——差点把旧被拒稿当现役材料;拒审史影响同账号后续提交策略。

**How to apply**:涉及 paper1/2/3 或 arXiv 提交时先读本条;kimi 三篇拿到后更新本条(合并为统一论文路线图)。
关联:[[lmev2-judge-401-envvar-pitfall]](新 paper2 的素材源)
