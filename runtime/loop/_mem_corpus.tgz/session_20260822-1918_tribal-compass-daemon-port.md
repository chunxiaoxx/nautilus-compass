---
name: tribal-compass-daemon-port
description: 
type: discovery
concept: pattern
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# tribal-compass-daemon-port

## 上下文


## 内容
nautilus-compass 本地记忆 daemon 跑在 127.0.0.1:9876(TCP,行分隔 JSON-RPC,MCP 协议);云 MCP 是 9877 仅 localhost,公网 REST 网关 8770。三套入口并存是收敛债。
