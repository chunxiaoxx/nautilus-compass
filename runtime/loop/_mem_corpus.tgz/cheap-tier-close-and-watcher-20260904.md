---
name: cheap-tier-close-and-watcher-20260904
description: "cheap-tier 双域定案关闭(web 36.3/ent 36.5 均未超现役,三改组合关)+ watcher 全自动跑分链路定型(模板含 judge 修正 flag)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-04T12:10:30.121Z
---

2026-09-04 cheap-tier(raw-state 强化)双域定案:**web 36.3%(87/240)/ ent 36.5%(77/211)**,双双低于 d12 现役(40.0/38.4)→ 预注册规则执行,三改组合(a11y_chars1500/query_decomp/shot_per_traj)关闭,d12 维持现役,营销/README 沿用现役数字。ent raw 曾被坏判官(4096+medium,启动漏带修正 flag)压至 30.8%,重判修复 +5.7pt(flips +16/−4,failed=0)。

**watcher 全自动链路(定型,后续跑分默认)**:GPU 上 `watch_ent_rejudge.sh` = `while pgrep -f evaluation.harness; do sleep 60; done; export $(cat /root/e2e/judge.env|xargs); python3 /root/rejudge_cheap.py <out>/per_question.jsonl <rejudge_out>.jsonl`——跑完→自动重判→ALL_DONE 零人工。启动命令模板(含 `--evaluator-max-completion-tokens 16384 --evaluator-reasoning-effort low`)+3 分钟自检已固化 TRANSFER_RUNBOOK(commit d7df1d6)。

**Why**:连踩 401/4096 两坑后,判官配置坑已从模板层堵死;watcher 把"跑完忘重判"这个环节也消掉了。本线 5 次 judge 事故(401/4096×2/断连/预算)全部是"启动/判官配置"层问题,无一例是判官模型本身。

**How to apply**:下次跑分照 TRANSFER_RUNBOOK 模板抄(勿手拼命令);产物拉回走 base64+md5 对账;进仓口径照 cheap_web(gz+VERDICT+run_args,*.log/*.jsonl 被 gitignore)。关联 [[lmev2-judge-401-envvar-pitfall]] [[gpu-old-disk-restart-20260903]]。
