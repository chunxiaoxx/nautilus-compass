---
name: session-contract-recall-usefulness-20260823
description: ✅CONSUMED 8/23 · recall 有用性首次获外部证据(F2 delta=1 · 检索 9/9)· 附带修复本地语义 recall 100% 坏死的 torch 根因
metadata: 
  node_type: memory
  contracts: 
    - contract_id: cnt_recall_usefulness_20260823
      from: compass-dialog
      to: compass-dialog(self)
      action: "对照实验:treatment 臂用自然语言 recall 检索部落事实记忆并注入后答题,与裸模型 control 臂比 delta;检索失败与注入失败分开归因"
      due: 2026-08-24T22:00:00+08:00
      done_when: "≥3 fact × ≥3 跑:treatment delta≥1 于至少 1 个 control 恒败 fact,且报告区分 hit/miss(检索层)与 inject-fail(注入层);负结果也如实记录"
      why: "用户裁定'从不觉得它帮到我'——compass 核心主张(recall 有用)从未受外部裁决;回归 compass 本身的第一仗"
  type: feedback
  originSessionId: 24bcc23d-3ddf-459f-a164-5653de16da4f
  modified: 2026-08-23T01:16:53.696Z
reinforce_count: 1
---

# recall 有用性对照实验(2026-08-23 派 · 用户裁定优先级)

- 用户原话:"从不觉得它帮到我,先证 recall 有用"。compass 十几版本从未回答"recall 改变过哪次任务结局"。
- 方法:Gate B 同款(control/treatment/确定性 oracle/诚实条款)。treatment = 自然语言 recall → top-3 注入 → 答;检索不中记 miss 不记 model fail。
- 燃料:③类部落事实(飞书单选 id 透传 · control 已实测 0/10 失败 · validator 现成 _valid_d2_transfer)。
- 环境:本地 daemon 9876(云过载,不依赖云)。
- 关联 [[session-contract-gold-replication-20260822]](方法来源)。


## ✅ 终局(8/23 早)
- **裁决:recall 有用,首次外部证据**。F2(端口部落事实)control 0/3 → treatment 3/3(delta=1);F3 负对照 delta=0(判别力成立);F1 检索✓+机制注入成功但表达式合规败(同 Gate B 方差,非 recall 失败)。检索层 hit@3 = 9/9。证据 outputs/recall_usefulness_20260823.json。
- **根因修复(回归 compass 本身的第一刀)**:本地语义 recall 曾 100% 坏死(torch 在 Store Python 长路径 WinError 206 → cache-miss 全炸)。修法 = torch 装短路径 C:/pylibs + daemon PYTHONPATH 重启。**"从不觉得它帮到我"的机械根因候选第一名。**
- 产品缺口:recall 只回 path+空 description,不交付正文(消费方须二跳读文件)→ 下一步召回输出带正文摘要。
- 坑:网关过滤 python-urllib UA(urllib 403/requests 200);glm 网关 429 突发限流需退避。

## 延伸(8/23 上午 · 目标模式开启)
- GOAL_SSOT_20260823.md 立为跨框目标账本(commit b02b282):无悔层/赌注层(决策树预注册)/产品层冻结。
- 心跳执法上线:tools/compass_goal_heartbeat.py 每小时(recall 探活+合约扫描,红灯自动 obs),Startup vbs 自启。首跑 OK 0.2s。
- 推进不再依赖会话记忆:合约到期 hook 亮牌 + 心跳红灯广播 + GOAL_SSOT recall 注入。

## 延伸(8/24 深夜 · verification-learning-papers 并入)
- 用户给出 github.com/chunxiaoxx/verification-learning-papers(本地已 clone):三篇论文体系(智能=压缩+验证/无验证→空转/同构验证→盲区)+ 真实数据 + 狗粮飞轮首日实录(引用 compass 8/22 Gold 当证据)+《收敛方案》发声路径。
- 判定:**理论 keystone,与 B 理论/Gate B/燃料分类完全同构**。"control 先失败门"已被其记为论文3 新推论候选(无 headroom→空学)。
- 并入 GOAL SSOT 理论底座;发声双轮 = arXiv(三部曲+狗粮数据)+ dev.to 博文(对照实验),协同推进。
