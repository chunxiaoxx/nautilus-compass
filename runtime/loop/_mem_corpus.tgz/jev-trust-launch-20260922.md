---
name: jev-trust-launch-20260922
description: "jev-trust 0.1.0 发布(PyPI+双 awesome-jev PR+Discord 同发)——Jev API 信任中间件,含双列表 fork 坑与 PR 创建配方"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5103bb42-025f-4754-adcf-4ff0f2b7218d
  modified: 2026-09-22T16:57:34.007Z
fact_status: inferred
---

jev-trust 0.1.0 于 2026-09-22 三发落地:PyPI(pypi.org/project/jev-trust/0.1.0,独立 venv 安装冒烟全绿)+ awesome-jev 双 PR + Discord 帖(等扫码)。

**Dogfood 首跑(同日闭环)**:PyPI 版实弹 python-exception-prediction 域(读函数源码判抛异常,6 模式×20,seed 20260922,n=120,132s 0 错):acc 100%/Brier 0.0055/ECE 0.0466/C=0.9534→FACE_VALUE,验签 VALID,独立手算四指标与库精确一致(预注册五判据全绿,PROTOCOL/RESULTS 在 runtime/jev_trust_dogfood_20260922/,**待非实现者复算**)。新汇率已上两块牌(wall.html 表+MEMORY_SYSTEMS_DIRECTORY)。注意:Jev 在此合成确定性域又稳又准,但 email-choice C=0.086 教训=校准是(模型,域)对的属性,读数不外推。

**域 2(同日)**:code-patch-behavior(v5 修复判定切片,读 patch 判行为变化):n=120 acc 92.5%/Brier 0.0575/ECE 0.1343/**C=0.8658** FACE_VALUE,验签 VALID 独立对拍一致;**域间差 −8.8pt**=域特异性设计化实证;错集中 nonecheck 16/20+typeconv 15/20(语义等价性判断)。工件 runtime/jev_trust_domain2_20260922/,待非实现者复算。

**域 3(同日)**:embodied-qc-labeling(flywheel 数据标注切片,按书面规范判关节角序列):n=120 acc **50%**/ECE 0.311/**C=0.689→DISCOUNT(首个非 FACE_VALUE)**。错误结构=**全 yes 策略**(120/120 说 NEEDS_REVIEW:召回 100%/精确率 50%/假阳性率 100%),置信 0.6 档占半;与 mini-DCR email-choice 50%@91% 同构=Jev 分类面结构性弱点。对管线含义:QC 建议不可直接执行。jev-trust 的 DISCOUNT/有效置信机制首次在第三方域触发设计作用。三域梯度 0.953→0.866→0.689=任务类型谱。反向措辞试验(先判 OK)列为待验证变量。工件 runtime/jev_trust_domain3_20260922/。

**域 4 OK-first 措辞对照(同日)**:单一变量复用域 3 决策集(同 sha256,只反转问题极性+条件方向)。预注册判据全触线:负例误报 **60/60→0/60**(H1 强成立=全 yes 由措辞诱导)但缺陷漏检 **28/60**(镜像偏差,召回红旗)。**漏检分层揭机制:算得动的跟数据走(limit 0/15、drift 1/15),算不动的跟措辞走(spike 14/15、stuck 13/15)——判定退化精确条件=机械计算成本,非纯迎合**。衍生:jev-trust v0.2 双极性自检候选(正反两问不一致→不可信)/TypeSafe API 级极性对称化建议/Assay 新对抗单元(极性翻转)。工件 runtime/jev_trust_domain4_20260922/(session.jsonl 首次就 git add -f,教训即改),待非实现者复算(判据 6-8 对照计算一并)。

**非实现者复算(同日晚,独立 agent 新鲜上下文)**:三域全 GREEN——验签双路(jev_trust+cryptography 独立实现)、sha 对拍、**真值独立重推 0/120 失配**(域1/2 exec 重跑、域3 独立 verifier)、四指标逐位一致、无选择性报告三方互证;agent 过程 4 次红灯全证伪为自己探针(纪律正确执行)。**抓到实现者假绿:三份 session.jsonl 被 .gitignore 的 `*.jsonl` 静默拦截从未入 git**(声称「工件完备入库」不实,克隆者无法验签)→ git add -f 补齐(3416978)。🔴新复发陷阱:**声称工件入库前必须 `git ls-files` 验证,通配 gitignore 会静默吞工件**。报告 runtime/jev_trust_recompute_report_20260922.md(证据档 _indep_*,独立结果先于 stats.json 落盘)。复算配方:交接档零预期读数+agent prompt 禁止先看 stats.json/RESULTS.md。

**域 4 复算(RED→修复→复核 GREEN 全环)**:判据 1-7 全过+H1/红旗与预注册线一致,但抓到判据 8 名实不符:stats.json `defect_newly_missed:32` 实为 decision 翻转数(域4 正确检出),真新漏=28 与自身判据 7 矛盾——**数字对但语义标错,自相矛盾暴露**。修复:三字段(clean_fixed 60/defect_newly_missed 28/decision_flips 32)+_note 注明纠错来源+run.py 防重跑复现;复核员 git diff 证数据未动+独立重推三字段逐位一致→GREEN(d7c0ec4/21825cc/de56f71)。🔴教训:**分析汇总字段的命名即口径——起错名=报告内自相矛盾,复算是唯一能抓到这类错的工序**(单看数字全绿)。yibie#137 也已 MERGED→双列表收录(324+1186★)。

**v0.2 双极性自检(9/23 发布+实测)**:decide_symmetric——同题正反两问单次 API 调用(调用方写反转措辞,库不改语义),极性映射比对;冲突→POLARITY_CONFLICT+有效置信强制 None+回调。33 测试绿,PyPI 0.2.0 独立冒烟过。**实测(runtime/jev_trust_v02_field_20260923)**:难域(域3/4 分层 50 题)冲突率 **98%**——三源交叉证极性偏差高度稳定(单次调用内复现两天前两域分离);特异度对照(域1 zerodiv 20 题)冲突率 **0%**+一致 20/20 全对。核心判读:**域4 单极 C=0.863 FACE_VALUE 被当场揭穿——校准货币看不见极性偏差,双极性自检能,两者互补**。坑:全局 python 旧版 0.1.0 没有 decide_symmetric(AttributeError 全 error 行→日志不建→sign_log 炸,先升版本);协议里的检出数凭印象写错(spike 实检 1 非 6)开工前自纠。

**Discord 三发收官(21:40)**:TypeSafe 官方服务器(discord.gg/typesafe,guild 1483217544214085663)#show-and-tell 两楼(1500+848 字符,2000 限内拆分),DOM 读取验证+截图 $LOCALAPPDATA/Temp/discord_posted.png。**域 3 发现回传(22:09)**:#builders-chat 全 yes 策略帖(1794 字符)。**域 4 follow-up(23:01)**:#builders-chat 措辞对照帖(1671 字符:偏差完全翻转+计算成本分层+双极性自检建议+@TypeSafe API 级极性对称化)。CDP 配方:隔离 profile+socks 代理+--remote-debugging-port(9223 被占换 9224),cdp_tool.py(eval/shot/nav)+send_post.py(focus→Input.insertText→Enter)。坑:①扫码后过早关窗=cookie 未落盘需重扫;②**Slate Enter 必须带 text="\r" 的 keyDown,且 insertText 后立即 Enter 可能仍被吞**——稳健做法=发完查输入框残留长度,>1 则重试 focus+Enter 循环直至清空;③Discord 按钮对 DOM .click() 响应正常;④频道:show-and-tell=发项目/builders-chat=发讨论/model-jaggedness=论坛;⑤heredoc 里 JS 的 \n 转义必炸,复杂 eval 写进 .py 文件别走 heredoc。

**产品**:Jev API 信任中间件。TrustedJev 包装 API:JSONL 落账每次调用、运行时校准(准确率/Brier=mean(1−p_true)²/ECE top-label 10桶/C=1−ECE)、有效置信度标注(分箱观测≥5样本优先→C 调整兜底→明示 insufficient_n)、过度自信告警回调、ed25519 签名日志(assay-verify 同源实现,可直接提交 Assay 复算=DCR 漏斗)。纯 stdlib,25 测试。代码在 `sdks/jev-trust/`。

**Why**: 校准是(模型,域)对的属性——研究 #1 ECE 0.041 vs mini-DCR 50%准确率@91%置信。厂商基准看不见你的域;jev-trust 是把 DCR 变成人人可自装的常驻仪器。

**How to apply**:
- awesome-jev 有两份独立列表,别搞混:我们席位在 **cobanov/awesome-jev**(324★,PR#56 研究已合);**yibie/awesome-jev**(1186★,categories/ 分文件+条目计数结构,需更新 README 计数)。两边都投了:cobanov PR#71、yibie PR#137。
- 我们 fork chunxiaoxx/awesome-jev 指向 cobanov;yibie 的 fork 因重名自动成了 **chunxiaoxx/awesome-jev-1**。
- gh CLI 不认 `owner:repo:branch` 三段式 head(重名 fork 场景)→ 用 REST:`gh api -X POST repos/<upstream>/pulls -f head="user:branch"`,GitHub 会按网络内分支解析到重名 fork。
- 本机环境常挂 ALL_PROXY=socks5(10808,Discord 配方副作用)→ venv 里 pip 装包会报 "Missing dependencies for SOCKS support",须临时清空 *_PROXY 再装。
- 全局 pip 走国内镜像,新发布的包同步延迟 → 加 `-i https://pypi.org/simple/`。
- 版本迭代时:测试手算值要过一遍 binning 语义(单样本 0.93 置信全对 → ECE=0.07 不是 0;0.75 置信半对 → Brier=0.3125 不是 0.0625)。

相关:[[c-family-verify-closure-20260917]](assay-verify 同源 ed25519)· 研究数据锚在 docs/wall/MEMORY_SYSTEMS_DIRECTORY.md 汇率牌。
