---
name: lmev2-three-knives-tuning-20260830
description: LME-V2 三刀调优——d12 全量定案 web 19.6→36.7%·ent 12.8→40.3%(刀1 abstention 口径+刀2 检索单元,四判据三中一未测);judge retry patch 两连崩教训(patch 验证要函数调用级冒烟);刀3 训练对脚本就绪待 GPU
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-30T07:16:07.489Z
---

# LME-V2 三刀调优(2026-08-30 · 用户拍板 1→2→3 推进)

**根因链(逐题对齐 evidence,四级全实测)**:①web 域 haystack=webarena 轨迹非对话(goal+几十 state+整页 UI 树) ②traj 级检索零漏召回(unknown 题 121/121 gold 全在) ③context 3410 tok 装不下单轨迹(数万 tok),喂的是头部片段 ④**88% unknown 题答案文本不在窗口**(correct 组 49%)。**abstention 大发现**:72 道(占 30%)is_abstention_problem 裸 UNKNOWN 49 道 checker 仅给 2 分——judge rubric 得分路线=指出前提矛盾 或 明确说"无法访问 live environment";裸 UNKNOWN 明确判 0。

**刀1(abstention 口径)**:`vtf/patches/lmev2_harness_prompt_patch.py` 重写 DOMAIN_SYSTEM_PROMPTS(禁裸 UNKNOWN,引导两条得分路线);GPU 机已执行(备份 harness.py.orig-d1)。
**刀2(检索单元)**:`vtf/lmev2_compass_memory.py` 三改——a11y 空结构行剪枝(500 上限)/traj 内 dense 重排扩展 per_traj_extra=4/text_budget 12000→24000;cfg 已同步。
**刀3(embedder 域适配)**:训练对构造脚本已就绪 `vtf/build_lmev2_contrastive_pairs.py`(commit 8c70ed4·纯本地 CPU)——query=题干/正例=含 gold 的 state 段(原始轨迹源优先,evidence 窗口兜底)/难负例=同轨迹 lexical 相近不含 gold 段;state 文本与部署栈同款(a11y 剪枝 500+1200 截断)防 train/serve skew。**基线 451 题出 56 对**(web 25/ent 31):abstention 128+枚举类 gold(元素散多 state)与 judge rubric 文本 109 题天然不可机械对齐;gold<5 字符(数字词)28 对有巧合命中风险已弃 precision 优先。200 条轨迹 subset(164MB)已拉回 `vtf/_compass_lmev2_out/lmev2_traj_subset.jsonl`(gitignore 不入库·md5 86310a25 两端一致·gpu_ssh 新增 readfile 分片下行)。d12 evidence 出来后重跑脚本可涨窗口命中→对数升。LoRA 训练本身待 d12 判据出后上 GPU。

**smoke 10 题三验证全绿**:零裸 UNKNOWN(10/10 解释性输出,1 道 abs 直接得分)/ctx 3400→5700+/UI 占比 13%→7-11%。

**全量重跑(d12 定案 8/30)**:`/root/lmev2_runs_d12` web+ent 全量完成,evidence 固化 `vtf/_compass_lmev2_out/d12/`(对比报告 D12_VS_BASELINE_20260830.md)。**结果:全题口径 web 19.6→36.7%(+17.1pt)·ent 12.8→40.3%(+27.5pt)**。四预注册判据:abstention 2.8→45.8%(ent 0→83.9)✅·裸 UNKNOWN 121/131→0 ✅·procedure web +16.6pt ✅(ent -3.1pt 轻滑)·LME-S 回归未测 ⏳。分型:abs 类全线大涨(static-abs ent 0→0.958),唯一下滑 web dynamic -3.9pt。诚实注记:①answered_score 0.469→0.327 是口径变化(敢答池 119→240)非退化 ②abstention 得分路线依赖 judge 主观(抽验同款措辞有 1 有 0,非无脑放水但存在套分空间)③LME-V2 abstention 占 27-30%,跨系统对比必须锁同口径。README 双语已更新。

**judge retry patch 两连崩教训**:web 首崩=judge(doubao)瞬时空响应 ValueError 崩全 harness;patch 后 web2 再崩=**我自己的 patch 引入 NameError(f-string 占位符 {MARK} 目标文件无定义)**——ast.parse+import 都不执行函数体,漏网。修复=函数调用级冒烟(inspect.getsource 断言无残留)+远端 sed 补刀。**铁律:patch 验证链必须含"函数实际被调用"级冒烟,语法门只是底线**。patch 留档 `vtf/patches/lmev2_evaluator_retry_patch.py`(三层:内部 retry 3 次/两 judge 调用点 try-except 记 0 分不崩 run/语法门),上岗后 scoring 零崩溃。

**深度重析(8/30 二轮 · 推翻"刀3 收益低"初判)**:①模糊匹配窗口命中率没涨(web 11.9→7.7%)但 substring 是下界——45/155"未命中"题得分>0.5(bool/枚举 gold 天然不可匹配+窗口内转述命中),真实命中率 11-15%;②刀2 作用机制=不是拉 gold 进窗口,是把**命中→得分转化率**大幅拉高:web 0.500→0.769·ent 0.115→0.652(ent 基线倒挂:gold 在场 reader 不用=排序问题,刀2 修复);③**刀3 重判值得做**——窄颈=段级选择(轨迹零漏召回但窗口命中率仅 10-15%=段选失败,转化率 0.65-0.77=段进窗口即得分),量化预期命中率 15%→30% ⇒ +8-12pt;前置=GPU 拉全轨迹(~300-400MB,subset 200 条是 56 对瓶颈)④tokens 成本 +63~72%(budget 翻倍代价,web 111万→182万)⑤掉分配对 9+9 道 vs 涨分 39 道,dynamic -3.9pt=3 掉 1 涨非系统性。

**本轮环境坑(复用)**:Bash 工具 cwd 跨调用持久(上次 cd 会带到下次,相对路径 `cd vtf/...` 二连败)→ 用绝对路径或 python 内锚定;readfile local 参数给相对路径(Python 把 /tmp 解释为 C:\tmp);解压 tar 前先查顶层目录名防覆盖基线 evidence(d12 顶层与基线同名,靠立刻重组+四方行数对账救回)。

**技法**:blockelite SFTP upload 也报 ENOENT→gpu_ssh.py 加 writefile 分支(exec 通道 base64 流);Windows 传 `/root` 路径必须 `MSYS2_ARG_CONV_EXCL="*"` 否则被转成 C:/Program。关联 [[lmev2-first-full-baseline-20260830]] [[lmev2-pipeline-smoke-proven-20260830]]。
