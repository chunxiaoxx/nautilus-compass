---
name: s6-disk-final-and-batch-guard-20261009
description: S6磁盘终局与分批护栏——用户裁用既存数据盘/vdb余57G工作目录落/data·镜像分批用完即删·GUARD<25G精确自停(21/30)·docker悬空层才是清理大头非containerd
metadata: 
  node_type: memory
  fact_status: measured
  type: project
  originSessionId: 5a6ae1c6-f5d4-4f54-a33a-73a088959318
  modified: 2026-10-08T12:52:27.576Z
---

# S6 磁盘终局与分批护栏(10/9 · 10730 令 · R367-R381)

- **用户终裁**:不购盘不扩容——既存数据盘 /dev/vdb(99G 余 57G,fstab 持久)承接 S6 工作目录(/data/s6_rerun);系统盘 vda2 留生产。**docker data-root 不迁移**:6 生产容器(espocrm×4/labelstudio×2/n8n/neo4j)Up 3 weeks,零收益不冒险。
- **镜像策略="分批用完即删"**:batch_run.sh(拉→跑→rmi 闭环,每批 2 实例)替代整批囤积;夜班整批拉 21/30 后 GUARD(avail<25G)精确自停=护栏语义实测通过;超持 19 个 rmi 释放 43G(23→66G)。
- **清理大头教训**:du 显示 /var/lib/containerd 16G 诱判"k8s 残留"——真身 4K(零容器零快照),**16G 实为 docker 悬空镜像层**;`docker system df` RECLAIMABLE+`docker image prune -f` 才是正解(回收 2.3GB);清理前列单每项必须 ps/ctr 探活再分级。
- **A4 否决先例**:/opt/ecc-shared/scripts/.venv 按体积像垃圾——ps 探到 2 个在役 uvicorn(8849/8850,自 9/15 运行)→从列单剔除;清理令执行前逐项探针是纪律不是保守。
- **runbook 模式**:死线前夜把执行序/命令/触发条件/SLA 全部落档(DEADLINE_RUNBOOK_20261009.md),新会话零考古接续——夜班终态补记(runbook 内追加段)让晨检直接读数。

相关:[[gpu-instance-reuse-not-rent]] [[cloud-daemon-storm-rootfix-20261006]]
