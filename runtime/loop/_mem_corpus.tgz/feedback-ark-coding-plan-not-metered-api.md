---
name: feedback-ark-coding-plan-not-metered-api
description: "用户多次纠正:火山 ARK 一律走 coding plan 端点(/api/coding/v3),不走按量 API(/api/v3 烧充值)——含可复制接入配方"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-30T09:30:37.933Z
---

用户 2026-08-28 首纠、2026-08-30 再纠("多次强调使用 coding plan 而不是直接使用 api"):调 ARK 模型(doubao 等)一律走 **coding plan 数据面端点**,禁止走按量 API。

**Why:** 按量端点 `https://ark.cn-beijing.volces.com/api/v3` + 老 ARK_API_KEY = 按量计费烧充值;8/30 compass 框刀3 弱标注+d12+d13 连续沿用它,把账户余额烧尽触发 `403 AccountOverdueError`,d13 两域全崩——违规有直接代价。红线 memory 原在 core/v5 框,compass 本地没有,导致本框未防住。

**How to apply(可复制配方,8/30 实测打通):**
- 端点:`https://ark.cn-beijing.volces.com/api/coding/v3`(**openai 兼容**,同 /api/v3 同构);anthropic 面为 `/api/coding`(config.yaml `anthropic_base_url`)
- key:本机 `~/.arkcli/.env` 的 `VOLCENGINE_ARK_API_KEY`(36 位 UUID,profile=coding-plan_cn-beijing_personal,有效期至 2026-10-28);⚠️ grep 必须锚定行首 `grep '^VOLCENGINE_ARK_API_KEY='`,否则混入 KEY_UID 行导致 400 Bad Request(8/30 踩坑:错误 key 长度 47)
- 查通道:`arkcli config show` 显示 base_url;`arkcli profile list` 显示 plan 档位
- 权益模型清单:`arkcli models list` 是全平台目录,**不等于** plan 权益面;doubao-seed-2-0-pro-260215 实测 plan 端点可用
- GPU 机 key 位置:`/root/.secrets/ark_plan_key`(600);judge.env 直接 `printf 'OPENAI_API_KEY=%s\n' $K` 覆盖即可,管线(base_url 参数)指向 /api/coding/v3
- 400 纯文本(非 JSON 错误)=大概率 key 取行污染,先验 `${#K}==36`

关联 [[lmev2-three-knives-tuning-20260830]] [[gpu-instance-reuse-not-rent]]
