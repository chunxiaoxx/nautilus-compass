---
name: lmev2-upstream-attribution-20260902
description: "🔴 重大纠偏:LME-V2 451题=上游 xiaowu0162(Di Wu)官方基准非我们自建(差点改名NautilusMem发布=侵权)——N6改形:T0=官方基准成绩册+判分协议+调优栈(attribution上游),NautilusMem留给T1自创新题;铁律再应验:自己写的'自建'叙事也是自报"
metadata:
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-02T15:54:46.217Z
---

# LME-V2 归属纠偏(2026-09-02 深夜)

## 事实链

- `vtf/lmev2_deploy.sh:36`:`git clone https://github.com/xiaowu0162/LongMemEval-V2.git` ——上游线索
- 上游实锤:[GitHub](https://github.com/xiaowu0162/LongMemEval-V2) + [HF dataset](https://huggingface.co/datasets/xiaowu0162/longmemeval-v2)(卡片原文"**451 manually curated questions**")+ arXiv 2605.12493 + 项目页 xiaowu0162.github.io/longmemeval-v2
- 上游定位:web+enterprise agent 轨迹长期记忆基准;LME-V2-Small=100 轨迹共享 haystack / Medium=500 轨迹;**论文口径 frontier LLM 无轨迹证据 ≤14.1%**(OpenReview)
- 我们的贡献(真实):compass 接入跑分 + 三刀调优(19.6/12.8→40.0/38.4)+ 判分口径修正(judge 4096→16384)——**是成绩与调优方法论,不是基准本体**

## 改形后的 N6(GOAL_SSOT 已同步)

- **T0 成绩册**(9/12):官方 LME-V2 上的 compass 成绩+判分卫生学协议+调优栈开源,attribution 上游。叙事比自建基准更硬:"官方基准+我们修了判分问题+涨 20pt"
- **NautilusMem** 名字保留给 **T1 自创新题**(前瞻/反事实/任务落地/容量压力=原创题,attribution LME-V2 轨迹源)——T2 训练飞轮不变
- README/落地页已改回"LongMemEval-V2 官方基准"表述(不说 our benchmark)

## 教训(铁律再应验)

"自建基准"是我的叙事自报——没查数据溯源(vtf 部署脚本里明写着上游 URL)。**改名发布别人的 451 题=学术不端+侵权,一步之遥**。以后凡"我们的资产"断言,先 grep 溯源(数据从哪 clone/构造脚本在哪/题目作者谁)。与"红灯先证伪自己"同源,这次的红灯是我自己的定性。

关联 [[benchmark-naming-licensing-20260902]] · [[lmev2-three-knives-tuning-20260830]] · [[d14-abstention-verdict-20260902]]
