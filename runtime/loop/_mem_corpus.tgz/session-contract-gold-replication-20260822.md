---
name: session-contract-gold-replication-20260822
description: ✅CONSUMED 8/22 深夜六 · 真燃料 Gold 合约达成(3 Gold 其中 2 真燃料 d3 r5/r15 · commit 99184b6)
metadata: 
  node_type: memory
  contracts: 
    - contract_id: cnt_gold_replication_20260822
      from: compass-dialog
      to: compass-dialog(self)
      action: "真燃料 suite(ledger fuel_evidence→Gate B 可跑)+ Gold 复制:合成 fixture 上 n≥3,其中 ≥2 Gold 来自真燃料 suite"
      due: 2026-08-27T22:00:00+08:00
      done_when: "≥3 次 verify rc=0 的 Gold,其中 ≥2 次燃料溯源到 fde_admission_ledger consumed 记录(非合成 fixture)"
      why: "首次 Gold(c093f98)是单点;合成 fixture 复现=搬B,真燃料复现=增B(测'经验迁移'真主张)。用户 8/22 批准"
  type: feedback
  originSessionId: a944fcc7-8e20-4a38-b8a8-46e4ccca757b
  modified: 2026-08-22T18:01:30.059Z
reinforce_count: 1
---

# 真燃料 Gold 可复制合约(2026-08-22 派 · 用户批准)

- 工作主体:把 ledger consumed 记录对应的 fuel_evidence(compass_exp_c2e/d2/v1)转成 Gate B suite(oracle 从任务自带确定性 verifier 派生,不手造)。
- 验收:≥3 Gold(verify rc=0),≥2 来自真燃料。
- 诚实条款:判 Repair 就记 Repair,不许改 oracle 迁就。
- 关联 [[session-contract-fuel-loop-live-20260822]](燃料来源)。

## 进展(8/22 深夜三)
- 合成 fixture Gold 已有 1 次(gate_b_cal2);真燃料管道建成:c2e spec + suite + 13 测试(7583e68),溯源 ledger grant e6fb8a43。
- **真燃料首测(c2e)= delta 0 Repair**:source✓ control✓ treatment✓——该经验(显式 encoding='utf-8')是 glm-5.3 已知常识,无 headroom。
- 🔬 关键发现:学习燃料 QC 缺一道前置门——**control 先失败**(同 A 类燃料"弱模型难倒"判据)。选燃料必须先测裸模型失败率。
- 下一步:换有 headroom 的燃料(v1_data_freshness / d2_enum 先测 control,或 A 类难倒题)冲真燃料 Gold;n≥3 继续。

## 进展(8/22 深夜四 · 方向性发现)
- 第 2 条真燃料 v1(freshness 边界口径)建成+实测:source✓ control✓ treatment✓ → delta=0 Repair(47dc468)。
- **双真燃料双杀(c2e+v1 通用工程常识均无 headroom)→ 结论升级:通用工程常识对 glm-5.3 已压缩完毕,不可作学习燃料。**
- 真燃料 Gold 的正确路径 = **项目特异经验**:飞书单选 options 必须原对象带 id 透传(6/12 实证坑)、Windows 下写文件必须显式 encoding='utf-8' 否则 GBK、agent_tool_calls 双库分裂等——这些模型不可能"本来就会"。
- 附带修复:anthropic 解析拼接 text block(47dc468),glm-5.3 thinking-first 不再致 provider_output_invalid。
- 这同时是产品验证:Verified Memory 的真卖点 = 团队私有验证知识,不是通用常识(Mem0 们存的恰是后者)。

## 进展(8/22 深夜五 · headroom 三级分类成型)
- d2(飞书id合并)spec 建成+三跑(8e80414):oracle 语义求值,事故式拒/合并式过。
- **headroom 三级分类(本夜核心产出)**:
  ① 通用工程常识(c2e/v1)→ 零 headroom,control 恒对;
  ② 可从需求推理的良好设计(d2)→ 不稳定 headroom:glm-5.3 三分之一概率自己推出正确合并,且复杂表达式 JSON 输出噪声大(3/6 臂 output_invalid);
  ③ **可靠 headroom = 不可推导的部落事实**(API 私有行为/内部口径)——下一个 suite 设计靶点:transfer 直接问'飞书单选更新 payload 怎么写才不丢 id',模型无渠道知道,经验有。
- 修复沉淀:anthropic thinking-block 拼接、comprehension bindings 进 globals、validator 变量名/dict() 放行(语义判据不放宽)。
- 状态:合成 Gold 1/3;真燃料 0/2 但产出三级分类(比 Gold 更值钱的 QC 理论);due 8/27 继续用③类燃料冲。

## 终局(8/22 深夜六 · ✅CONSUMED)
- **d3 suite(compass-exp-d3-payload-v1)= ③类部落事实靶点落地**:同 d2 燃料但 transfer 去提示化(prompt 只给"最终名单"可观察需求,id 透传机制只存在于 source advice)。
- **合约达成**:Gold ×2 真燃料(r5 / r15 · verify 重放 rc=0 · outputs/gate_b_d3_r5|r15_20260822)+ 合成 cal2 = 3 Gold 其中 ≥2 真燃料 ✓。commit 99184b6。
- **③类 headroom 实证**:control 干净尝试 0/10 通过(全败于"新选项缺 id / 重建 by name")——不可推导的部落事实 = 可靠 headroom,三级分类获直接证据。
- **treatment 方差来源 = 传输层非知识**:r4-r13 多数 treatment 语义正确但死于 ```json fence / AST 安全子集误杀(*解包、|、walrus、slice、next/any/set 等)——两轮探针自误杀修复(语义 oracle 4 案例零放宽)。教训:先证伪探针再归因模型,再次实证。
- **边界**:prompt 明文限制("Only stdlib builtins like max/enumerate/sorted")外的写法(.get/.count/int())按约定拒,不算误杀。
