---
name: verification-commercialization-20260915
description: 验证能力商业化定稿——免费复算入口已开(#166 回复+issue 入口)·第一付费 SKU=发布前独立审计 $99/199/299 三档·里程碑 M1(首请求)/M2(付费意愿)/M3(成交)M1 前零付费基建·结算走平台市场一石三鸟·四红线(两向如实/不验己售/license 口径待用户拍板/免费时效如实)
metadata:
  node_type: memory
  type: project
  originSessionId: 79d94145-3f9a-48a7-8bda-93a4a2bdc1d5
  modified: 2026-09-15T15:45:15.008Z
fact_status: measured
---

# 验证商业化 playbook(2026-09-14 深夜用户拍板,正本 docs/marketing/verification_playbook_20260914.md)

**已落地**:免费复算入口=讨论帖 #166 官方回复(discussioncomment-18436585,
issue 入口+两向如实承诺+人肉管线诚实边界;讨论帖评论无置顶权限,以官方首条
回复承接)。田野记录表 recompute_intake_log.md 已建(每次请求一行,兼作 M1-M3
判据与定价依据)。

**商业化阶梯**:免费漏斗(DIY VerifyPack→免费复算一次换语料/wall/判据库/
需求画像)→ **SKU1 发布前独立审计**($99 subset/$199 standard/$299 full,
人肉+现成流程,零新基建,交付=签名报告+wall 条目+徽章)→ SKU2 持续验证 API
(前置:M1 后 ≥3 家持续需求+daemon 稳定性专项修完,否则不写一行基建)→
SKU3 企业记忆+治理(Aegis 对位,单列)。

**里程碑(反剧场)**:M1 首个外部复算请求(观察 2 周,无则换 HN/定向直邮入口
不追发)→ M2 首个付费意愿(才上 $99 试报价+一页纸)→ M3 首笔成交(才谈 API 化)。
**M1 前零付费基建零定价页零营销投入。**

**结算**:外部客户平台挂单→compass(9000017)接单→external-verify 门结算
NAU——商业收入+平台生态首个外部任务流+verdict-bus 实战一石三鸟。

**两条拍板已落(9/15 凌晨,commit be9894e)**:①LICENSE 新增 A4 澄清——A2
托管 100 付费上限仅指记忆/检索功能,独立验证服务(复算/证据包/审计报告)为
独立商业线,条款另由服务协议定;②compass CLAUDE.md 已加「报数纪律」块——
对外报数任务开工先落预注册判据档+收工走非实现者复算+交接档零预期读数
(其他框的 CLAUDE.md 由各框 owner 参照自加,soul 提案是组织层正本)。

**9/15 午后追加**:③转化工具包 docs/marketing/revenue_conversion_kit_20260915.md
(M1/M2/M3 当日动作+履约 SOP+收款两腿 LS/平台 NAU)——**报价单措辞已过用户审
(d056204),M2 触发日原样使用**,两向如实+品类隔离=不可让步项;用户侧待办
=LemonSqueezy 注册+WorkBuddy 15 分钟真跑。传播第一层已打:EN 架构文 dev.to
id 4660567 已发,Cognee 互跑帖 #5070 已投(回应即 M1 级信号)。

**风险位**:daemon 稳定性=高(今日两次无端死,第三次触发系统层专项;对外
服务接客前必修);免费→付费转化靠田野记录定方向。

相关:[[platform-verifypack-integration-20260914]] [[rsi-loop1-recompute-verdict-20260914]] [[license-modified-mit-20260904]] [[compass-strategy-four-priorities-20260910]]
