---
name: verifypack-v02-built-20260909
description: "#47 VerifyPack v0.2 完成——SPEC+CLI 四命令纯 stdlib 实现,batch001 端到端跑通,活文件缺陷显式化,等 flywheel 确认"
metadata: 
  node_type: memory
  type: project
  verified_at: 2026-09-09
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-09T15:48:37.984Z
fact_status: measured
---

# VerifyPack v0.2 构建完成(9/9 用户拍板推进,当日晚交付)

**交付物**(commit e28ba3c):`docs/verifypack/SPEC_v0.2.md` 正本 + `tools/verifypack/`
CLI 五命令(build/verify/receipt/check/keygen)+ 57 测试。纯 stdlib 零依赖,
ed25519 是 RFC 8032 自实现,正确性靠 cryptography 库交叉验证(importorskip)。

**batch001 端到端定案**:5 agree + 1 disagree + 1 degraded。
disagree = resource_log.csv(claim 1f9ce5cd vs 实测 e7a5989e)——打包(9/5 18:11)后
文件仍被追写(mtime 9/6 17:42),**与 9/9 凌晨 v0 手写复算器逐条交叉一致**(两代独立
实现同结论)。C6 口径升级:v0 记 agree(降级)→ v0.2 记 degraded(更严格)。

**Why:** 这是「第三方数据有效性验证平台」方向的工具载体(方向锚 2026-09-02);
把项目立身之本「自报不算,能独立复现才算」从手工流程固化成标准协议。

**How to apply:**
- 复算任何 pack:`python -m tools.verifypack verify <pack> --key <key>`;密钥在
  `.verifypack/`(已 gitignore,公钥 f7554b87…3e8be 可分发)。
- claim 写法:check 结构见 SPEC §4;L2 必须 fallback(环境缺失自动降级)。
- 外部引用文件必须进 pack.json `inputs` 声明——seal 记哈希,改动即 SEAL_FAIL。
- 手几何第二包仍 blocked-on-artifact([[compass-roadmap-20260907]] #46 挂账)。
- DoD 第 4 条等 flywheel 回执(回函草稿 `_OUTBOUND_FROM_COMPASS_TO_FLYWHEEL_20260909_verifypack_v02_receipt.md`)。

三处引擎缺陷(测试+e2e 抓出,修复后 57 绿):manifest 漏写 input_decls 导致
input-missing 假红 / build_manifest 顶层 rglob 误扫 receipts/ 报 unsealed /
file_hash_map 行映射不支持嵌套点路径(qc.video KeyError)。
