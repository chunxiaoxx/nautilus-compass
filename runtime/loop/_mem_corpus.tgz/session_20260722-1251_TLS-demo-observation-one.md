---
name: TLS demo · observation one
description: mTLS cross-peer write
type: feature
concept: how-it-works
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# TLS demo · observation one

## 上下文
mTLS cross-peer write

## 内容
Observer peer wrote this over mutual TLS. Both sides presented certs signed by compass-demo-ca.
