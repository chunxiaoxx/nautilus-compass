---
name: pilot-verdicts-unverifiable-20260915
description: verdict-bus 试点复算定案——10/10 不可复算:items 8/22 起写入器回归全表归零·输入侧只在 V5 会话日志·三模型判分 total_tokens=0·external_verified 生产者自置=自报复发;CATALOG_v0 立库 3 判据;回函 id 243;hook 实弹 14/14 PASS(J1 无尾巴)
metadata:
  node_type: memory
  type: project
  originSessionId: 79d94145-3f9a-48a7-8bda-93a4a2bdc1d5
  modified: 2026-09-15T16:03:23.849Z
fact_status: measured
---

# verdict-bus 试点:10/10 不可复算(2026-09-15)

**读数**(判据=platform 232 原文口径;报告 docs/platform/pilot_verifypack_10verdicts_20260915.md;回函 id 243):
- 10 条 8/29 批(4391-4380):items 全空、输入不在行内(tasks 表无 g2b1 记录)、
  artifacts total_tokens=0、external_verified=true 无复算者参与 → **UNVERIFIABLE×10**
- **系统性回归带时间边界**:8/16-8/21 每条 1 item;8/22 起约 390 行归零;
  9/2 起 external_verified 也归零(195 行 0%)——两 regime 之间的尾巴即本批
- 病理=自报复发:标志可由生产者侧置位,与 RSI 环 #1 J1 同款,组织级模式

**探针自证三重**:current_database()=nautilus_production、verdict 表全库唯一、
15 天序列对照——结论非误诊(先证伪自己的纪律再次生效)。

**产出**:CATALOG_v0 立库(docs/catalog/CATALOG_v0.md)首批 3 判据
(verdict-recomputability-v1 / external-verified-provenance-v1 / evidence-schema-v1),
格式 criteria:<id>@catalog-v0,棘轮纪律;commit 45eeaa1。
**等 platform**:记账回锚+三修复落地(写入器全载荷/标志改复算者写/旧队列真复算
需 V5 给 problem 坐标)+ soul draft PR 落点(两函未回写,已催)。

**同晨另验**:记忆门 hook 实弹 14/14 PASS(跨 4 项目含凌晨他框写入)——J1 无尾巴。

**9/16 收口补链(用户转发提醒,迟到回执已补)**:
- **结论函 277 → flywheel**:T1 三态映射定案(refuted=disagree/not_computable=degraded 严格化/pending 新增,17.5% 活例注册 refuted)·T7 gate 留 build 侧 verify 纯等式·T8 排期(C 族首批 9/17 开,全量=写入器 M3 修后一周)
- **CATALOG_v0 增第 4 条**:anchor-pool-selection-bias-v1(锚池须以历史合格批语义构建;flywheel sim50-001 闸③三组对照归因:批内自锚 6.4% vs 生产池 68.1%——G1 盲区活例,「昨天验过的批次是今天的锚」=飞轮复利显性化)commit 71c332a/d2230ba
- **回函 278 → v5**:10 条 task_uid 清单照发;SSH 若仍断我方直接出 8/21 vs 8/22 字段级 diff 样本(有 DB 直读通道)
- **考古定谳修正(275)**:8/22 items 归零**非回归是换管**——8/23 daemon 化引入硬编码 items=[],上游已两行修复;9/2 起 external_verified 归零同源。旧格式 10 条真复算已排批(函 255,坐标已到)
- 五封未读(245/247/255/268/275)全部 ack 清零

**同日 1+5 落地**(用户拍板,commit b38d8bb+插件仓 watch_daemon v2):
- **证据守望探针** `ops/verdict_evidence_watchdog.py`:CATALOG_v0 三判据测量仪;
  正控=全量 4079/4564 违例(比试点口径更完整);凭证运行时读 nautilus-db MCP
  配置(初版硬编码密码当场自纠);计划任务 compass-verdict-evidence-watchdog
  每 6h(--since 6 增量,新违例 exit 1)。
- **daemon 死因专项定案**:三连死(9/14 12:16/13:55·9/15 ~05:04/~10:02)全
  无崩溃记录/Application 1000 空/WER 空/无 OOM 事件/36h 仅一次睡眠唤醒
  (9/14 10:02,只解释晨间批)→ 结论=**宿主控制台连坐**(nohup python 挂
  bash 控制台对象,关窗/会话树关闭连坐杀,与 v5 python 同批蒸发的形态吻合;
  9/8 根因案的补刀——当时只修了 watchdog 存在性)。
- **修复**:watch_daemon.cmd v2 → `ops/detached_daemon_start.ps1` → pythonw
  (无控制台)+Start-Process 独立进程;受控验证 PASS(精确杀旧 PID→看护
  5min 节拍自动拉起→新形态 pythonw3.13 PID 3344 ping 正常)。
- drift FP:a-476132ee 命中但方向相反(本会话做证据真化非虚增),
  feedback_log 工具缺 write scope 标不了,记录在案。

相关:[[platform-verifypack-integration-20260914]] [[verification-commercialization-20260915]] [[rsi-loop1-recompute-verdict-20260914]]
