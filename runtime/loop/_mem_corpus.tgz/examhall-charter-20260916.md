---
name: examhall-charter-20260916
description: 「考场」立项草案 v0——RSI×组织记忆认证轨基准;调研定谳题目层拥挤(RSI-Bench已存在/LME-V2已转组织向)认证协议层空位;差异化=诚信计分U扣分+回执名次+UNVERIFIABLE上墙;借轨合作优先;BC0-BC3挂M1闸;compass走向扩五层;三框头脑风暴函314/315/316已发9/18截止
metadata: 
  node_type: memory
  type: project
  originSessionId: 5103bb42-025f-4754-adcf-4ff0f2b7218d
  modified: 2026-09-16T15:44:44.543Z
fact_status: inferred
---

# 「考场」立项(2026-09-16 · 草案 v0 · 用户指示正式立项+跨框头脑风暴)

**调研定谳**(真实检索):RSI-Bench 已存在(评改进速率,共识化中);**LME-V2
(ICML26,我们 NautilusMem T0 的上游)已自己转向组织经验记忆**;AgentMemoryBench/
AMB 密集 → **题目层拥挤,认证协议层空位**。差异化三板斧:①诚信是分数(不可复
算占比 U 扣分)②官方名次只认带回执运行 ③UNVERIFIABLE 上墙。姿态=借轨合作
优先(向 LME-V2/RSI-Bench 提认证轨),被拒再全自建。

**compass 走向 v2(四层→五层)**:状态层(记忆)→裁判层(三态复算+回执)→
法律层(CATALOG+棘轮)→**考场层(本立项,唯一直通 M1)**→燃料层(verdict
语料→RLVF,导出器先行,训练挂语料≥2000+M2)。9/7 四层路线图全保留归入。
对外一句话:**建了记忆,装了裁判,立了法,现在开考场。**

**里程碑**:BC0 头脑风暴回函并入+命名查重+计分规范预注册(9/17-9/20,前提=C
族 verify 管线健康)→BC1 30 题原型+自家成绩单上墙含难看数字(9/27)→BC2 借轨
合作函+榜单页(10/10)→BC3 首外部被测=**M1 正式形态**。

**分工**:compass 计分引擎/v5 首席被测者+盲区探针共创(被骗 14.2% 最懂)/
flywheel 题源+REJECT 标本+榜单页/platform 总线结算+Jarvis 签发/用户=判据变更
唯一批准人。M1 前零付费基建;失败面:借轨被拒且自轨无人→回退 P3。

正本:docs/plans/2026-09-16-examhall-charter.md;三函 314(v5)/315(flywheel)/
316(platform),deadline 9/18 22:00。

相关:[[rsi-deep-implications-20260916]] [[benchmark-naming-licensing-20260902]]
[[lmev2-upstream-attribution-20260902]] [[verification-commercialization-20260915]]
