---
name: nacre-codename-decided-20261006
description: 创新模型代号 NACRE 用户拍板定案(10/6);v1 批次单点隐喻被否、中文名「溯衡」不认可
metadata:
  node_type: memory
  type: project
  originSessionId: c62a754e-c031-437d-a37a-0d217fbf3144
  modified: 2026-10-05T16:52:13.172Z
fact_status: inferred
---

2026-10-06 用户拍板:创新模型(动态权重小判分器,[[architecture-mainline-20261004]]"智能=压缩×验证×因果倒置"载体)代号=**NACRE**。

**Why:** v1 批次(Chamber/Sextant/Assayer/Arbiter)被否——全是单点隐喻,没体现"动态权重×压缩×验证×因果倒置"的关联性(用户原话);中文名「溯衡」也不认可。用户要的是名字本身编码公式。

**How to apply:** NACRE = **N**ovelty-gated **A**djudication via **C**ompression & **R**egistered **E**volution(珍珠母):压缩=Compression、验证=Adjudication、动态权重+因果倒置=Registered Evolution、防自指=Novelty-gated;全称一句即公式。品牌叙事:nacre=鹦鹉螺壳材质本身(生物矿化=增量固化=registry 棘轮同构)。撞名已核干净(gh api 209 仓最高 36★+HF 2 零下载,Gnomon 撞 paypal 932★ 降级、Tessera 撞 tesseract 淘汰)。对外品类锚:judgment-native judge model(借 Metis 之于 memory 的造词权,[[metis-benchmark-20261005]] 若已立)。正本:docs/soul/INNOV_MODEL_WHITEPAPER_SKELETON_20261006.md。所有后续文档/发版/榜页一律用 NACRE。
