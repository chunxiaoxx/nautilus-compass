---
name: security-workbuddy-token-scoping-20260830
description: 8/30 workbuddy 跨框记忆暴露修复:TCP MCP 版补项目级 scope(8/28 体系只覆盖 HTTP 版)· 13 存量全权 token·workbuddy 已换 scoped+旧已 revoke · 验证矩阵与遗留
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-01T10:51:35.245Z
---

# workbuddy 跨框记忆暴露 · TCP scope 修复(2026-08-30)

用户实测发现 workbuddy 接入 compass MCP 能读各对话框全部记忆。查透三层根因:

1. **存量未迁移**:8/28 scoped-token 机制只交付了 HTTP 版(mcp_http_server.py)+签发工具,云端 `/etc/compass/tokens.json` 13 个存量 token 全是旧格式(=全权 read:*+write:*)。
2. **TCP 通道无项目边界**:workbuddy 与各框桥主通道 = 云端 TCP 9877(mcp_server.py),只有工具级 tools.read/write,持有效 token 可跨全部 project 读写。8/28 修复漏了这条通道。
3. **通道拓扑**:workbuddy 桥(mcp_stdio_to_cloud.py)recall/drift/thread_recall 走本地 daemon 9876(无鉴权·本机信任域,风险低),其余工具走云端 TCP 9877(无项目级 scope,已修)。

## 已修(全部 grounded 验证)

- mcp_server.py v3.2:`read:<project>`/`write:<project>`/`read:*`/`write:*`/admin 语法与 HTTP 版同构,共用 tokens.json;携带 project 级 scope 的 token 进 fail-closed 强制,旧工具级/'*' token 行为不变;dict 空 scopes=全拒;**scoped token 放行工具级门槛**(双重检查冲突,首版部署踩过,云端四向 DENY 抓到)。
- workbuddy 换 scoped token(`cmp_workbuddy__e6d5…`,read+write 仅 C--Users-chunx),旧全权 `cmp_workbuddy_9a0b…` 已 revoke+重启后 DENY 验证。
- 云端验证矩阵:自己 project ALLOW / 别 project 读 DENY / scope=user DENY / 别 project 写 DENY / 旧全权 ALLOW(回归)/ revoke 后 DENY。
- TDD:tests/test_mcp_server_project_scope.py 8/8 绿。

## 关键 gotcha

- TCP 版(mcp_server.py)**无 tokens.json 热加载**(HTTP 版有 mtime 懒重载)——改 tokens 后必须 `sudo systemctl restart compass-mcp-tcp`,否则 revoke 不生效(实证踩过)。
- 云端 ~/nautilus-compass 是 non-bare checked out main,**push cloudpush 被拒**;部署通道 = format-patch+scp+git apply(或整文件 scp+云端 git commit 留痕)。
- tokens.json 里 `cmp_my-agent__91…` 是新格式名但旧格式值(全权)——签发工具上线前的手工产物,迁移清单内。
- 本地 daemon 9876 无鉴权 = 本机信任域(回环),对外商业化时必须走云端 scoped 通道,不能依赖 local-first。

## 遗留(迁移清单 · 2026-09-01 大幅消化)

**9/1 已收窄 9 个**(值不变·数组→dict `read:* + write:C--Users-chunx`,单元 7/7+e2e 2/2 验证,备份 `.bak-20260901`):v5/v6/kairos/v7_telegram/v7_souls_fus/my-agent/super_agent/fde_dialog/hr_dialog。依据=云端观测写入面仅 C--Users-chunx 或零活动。**留痕** `docs/SECURITY_TOKEN_SCOPE_20260901.md`。

**剩 3 个等框报备(9/15)**:compass_dialog(审计写多框)/platform_dialog(管理全平台)/v5_dialog(V5 会话)——跨框 ingest_obs(对方) 是语义通道,收窄会打断,须各框确认写入面后再动。已知边界:写工具不带 project 参数(如 feedback_log)会 DENY,fail-soft 客户端无感,误伤回滚备份+restart。对外商业化租户隔离 = 每租户独立 token+scope 仅租户 project(机制已就绪)。

关联 [[session_20260823-0846_workbuddy 首调]] · LOOP_STATE P1(9877/8770 退役 9/15)
