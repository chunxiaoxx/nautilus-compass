---
name: p2v2-lora-milestone-20260930
description: P2北极星达成(verdict-judge LoRA 88.51%三门全绿)+GPU实例释放_redact遮罩坑+模型下载断流三通道排障
metadata: 
  node_type: memory
  type: project
  originSessionId: ea8fe589-cfd0-4e92-aa7d-acc30fddd29b
  modified: 2026-09-30T15:27:48.936Z
---

# P2v2 LoRA 里程碑 + GPU 运维三坑(2026-09-30 深夜)

## 里程碑:P2 北极星达成(判分器≥85%)

承 [[judge-corpus-p2-baseline-20260930]](v1 地板 66.2%=架构天花板定谳),v2 LoRA 路线一次达标:

- **J1 test 二值 acc=88.51%≥85% / J2 ECE=0.072≤0.10 / J7 v1+22.3pt≥+10pt / J5 split sha 三项 PASS**
- 配方:Qwen3-1.7B + QLoRA r16/α32 + verbalizer 三态(pass/fail/insufficient_evidence 下一 token 训练,推理取三词 softmax=天然校准概率,ECE 直接可算)
- 输入=P2 v1 的无作弊通道版 sample_text(剔除 judge_output);split 冻结零改动(train1162/dev143/test149)
- dev 曲线 0.867→0.916→0.881,早停 ep5,无硬过拟合;U 态仅 1 条(全库 7 条,沿 v1 口径如实披露)
- 产物:runtime/judge_lora_p2v2/(adapter 25.7MB+run.log 全量);宪章 J8 申报函 1829(数据+逻辑 70% compass/算力 30% 组织)
- 下一步=装记忆写入热路径评估(RSI 环实体化),**装前另行申报**;训练 commit 87fce6f2

## 坑 1:CLI `_redact` 遮罩 approval_token → release 静默失败(高发)

智星云 CLI 对除 connect 外所有命令输出走 `_redact` 遮罩敏感字段——**release-plan 打印的 approval_token 是被遮罩的**,从 stdout 解析 token 再 release 必然校验失败且无明显报错(两次静默失败)。
**修法:release 一律走 API 层原子调用**:
```python
from ai_galaxy_compute.cli import _client
from ai_galaxy_compute.client import AIGalaxyClient
from ai_galaxy_compute.broker import ComputeBroker, SafetyPolicy
from ai_galaxy_compute.ledger import ApprovalLedger, ApprovalAuthority
import types
client = _client(types.SimpleNamespace(base_url=AIGalaxyClient.BASE_URL, timeout=30))
broker = ComputeBroker(client, SafetyPolicy(max_total_price=0.01), ledger=ApprovalLedger(), authority=ApprovalAuthority())
plan = broker.prepare_release(instance_name)   # 返回真 dict,approval_token 未遮罩
broker.execute_release(plan, plan['approval_token'])
```
rent 同理(plan/rent 有同一进程 60s quote TTL 约束,API 层天然满足)。

## 坑 2:实例网络大文件系统性断流 → 模型下载三通道排障

智星云实例(js2)对 HF 大文件(safetensors 数百 MB+)**系统性断流**:HF 直连与 hf-mirror 都卡在 75%(小文件全过,3 个 safetensors 全 incomplete,重试原地复发)——不是随机抖动,别在 HF 通道上浪费时间重试。
**终路=modelscope**:`pip install modelscope` + `snapshot_download('Qwen/Qwen3-1.7B')` 稳定 1.77MB/s;下载后 sed 改训练脚本 MODEL_ID 指向 `~/.cache/modelscope/hub/models/...` 本地路径即可。Qwen 系模型 ModelScope 都有官方镜像。相关 [[gpu-e2e-rootcause-chain-20260829]](8/29"直连 HF 唯一快路"已过时,网络环境会变,先测速再选通道)。

## 坑 3:pkill 自匹配自杀(第 4 次)

`pkill -f p2v2_dl_mirror` 匹配到执行它的 bash -c 进程自身(命令行含模式串)→ 自杀,后续命令不执行。
**修法:模式用字符类破坏自匹配**:`pkill -f 'p2v2_dl_mirro[r]'`。前科:gpu-old-disk-restart/daemon-auth 记忆,这次又犯——**凡 pkill -f 先想 [x] 写法**。

## 其他定谳

- transformers 4.46.3 不支持 Qwen3(Qwen3ForCausalLM 需 ≥4.51),升 4.57.6 与 torch 2.6/peft 0.13.2/bnb 0.50.2 兼容
- 1.7B QLoRA 在 4090 48G 上训练 1162 条 × 8 epochs ≈ 35 min(含评估),全流程(下载+训练)<1h,成本 <¥2
- setsid 后台管道经典坑:nohup 重定向目标目录必须先 mkdir(重定向先于脚本内 mkdir 执行);paramiko 启动与验证分两个 exec_command(同 channel 读输出会挂起)
