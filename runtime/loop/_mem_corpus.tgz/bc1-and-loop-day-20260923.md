---
name: bc1-and-loop-day-20260923
description: BC1 基准全链(30题/自测/审计/重考/发布就绪)+Loop V1 系统+历史署名重写+签名断链三连修——9/23 超长 session 战报
metadata: 
  node_type: memory
  type: project
  originSessionId: 5103bb42-025f-4754-adcf-4ff0f2b7218d
  modified: 2026-09-23T13:54:46.869Z
fact_status: inferred
---

2026-09-23(接 9/22 jev-trust 发布日)一天完成:Loop V1 组织循环系统、BC1 基准全链、git 历史全量署名重写、BC1 签名断链三连修。

**BC1**(runtime/assay_bc1_20260927/,发布页 docs/benchmarks/BC1_LAUNCH.md,9/27 执行):
- 30 题四维(跨框一致/写入门/重犯率/归因),seed=20260927 先入库,18/12 public-holdout 切分
- 自测戏剧性链:v1 独立 agent 应考 11/18 → 逐题审计 7 FAIL **全判出题侧缺陷**(T12×2 真值错误=考生比真值对/T11×3 题面歧义无 reply-to/T31×2 边界未定义)→ 复算 GREEN 独立坐实(raw=69/62 法证)→ v2 修题(expected 全改 verifier 从 inputs 推导)→ 重考 **18/18 满分**(缺陷题全转 PASS=归因反证)。v1 全套工件留作「缺陷→审计→修复→重考」公开样本=发布卖点
- 签名断链三连修(复算 RED):V2 签名 pub 文件误作 seed 传 from_hex+**自验同路=假 VALID**;v1 改文未重签;v1 披露段照抄 V2 根因(张冠李戴)→专用密钥(seed 存 .cache)三签+披露勘误,外部视角直验全 VALID
- 🔴教训:**自验与签字同源时自验不可信——签名物有效性只能由独立路径证明**;**披露段内容也须法证级核对**(照抄别件根因=新的丑数字);jev-trust KeyPair(pub=) 构造器覆盖 bug→0.2.1(装版实测)

**Loop V1**(docs/plans/LOOP_SYSTEM_V1_20260923.md+LOOP_STATE.md 账本):六根因(状态无真值/函件无闭环/角色无矩阵/脱离M1/用户淹没/节奏无层)→六机制(git 单源账本/三段协议 ack≠完成/五框矩阵/M1 锚定黄红牌/用户决策面板/三层节拍)+七步轮值。与 platform Loop v4.1 分层对齐(V1=协议层/v4.1=机器层,共用 LOOP_STATE 真值);**818 单边宣布生效被 platform 程序对表纠正(9/5 征求纪律)——认**。五轮跑通,轮次摘要函=不能拉仓框的只读投影。

**历史重写**(用户批准,docs/plans/HISTORY_REWRITE_NOTE_20260923.md):filter-repo+mailmap 全量(1340 commits/35 分支/29 tags,saas-dialog 及变体→chunxiaoxx gmail,bot 保留),双镜像备份(Projects+D:\backup-git-20260923)。**9/23 前旧 sha 全失效**。配方:mirror clone 上跑+push --all/--tags(mirror push 撞只读 refs/pull 被拒但 heads 已上)+本地 update-ref 不碰工作区+服务器 fetch+checkout landing。外部 PR 现状:#71/#137 已合并署名 chunx@local.lan(假域名不可认领,影响小);NanoJev#12 与 PR#56 本就正确;全局 config 已修=根源堵死。相关:[[commit-attribution-rule-20260923]]

**晚间续(同日)**:
- **¥0.01 端到端四回执全通**(L5 ✅,订单 HR…F0DE7/e2e_1fen plan,微信流水 4500000490…9734,wxpay_notify 自动回调,对账 1 分精确,「已全额退款」官方确认,净成本 0;回函 887)。坑:plan 金额单位=元(test=1 元≠0.01,增设 e2e_1fen plan+重启 accounts);退款终态取证=幂等重发创建拿 400「订单已全额退款」官方字样(查单 /out-refund-no 404、列表 405 都不通时此法兜底)
- **卡2 DCR 上墙**(56a69ae):验证墙主 CTA 卡(双语三档+§5b+微信通道+生产验证披露);www 入口卡素材交 platform(函 890,#803 边界=只入口不复制正本)
- **C1 触达实弹**:T1(is-malicious)被关+「slop writing」批评→**AI 营销腔在开源社区被打 signal**,话术 v2 人味版入库(≤120 词/无粗体/工程师口吻);T4(hono-jev-router#7)v2 单点试验发出
- L9 ✅(exam-signup 模板 v2 密钥三步流,平台代落 3a1093d);L4 ✅(v0.2 复算 GREEN 六步全复现,ad74767)
- 晚间故障:信箱查询返回空(主站 200+写入有回执 id,读挂)——platform 域待自愈;🔴诊断配方:**写入成功≠读正常;两种读通道都空+主站 200=查询层故障非我方**
