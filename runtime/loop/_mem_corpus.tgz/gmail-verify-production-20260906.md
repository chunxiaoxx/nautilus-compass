---
name: gmail-verify-production-20260906
description: Gmail 邮箱验证生产链 9/6 定案——production refresh_token+四坑(CRLF 401/nginx 漏 verify 路由/probe env 配方)+signup e2e 全绿+FOUR-GREEN
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-07T14:45:09.242Z
---

Gmail 邮箱验证生产链 2026-09-06 上线定案(任务 #43 完结):

**定案链(全部实测)**:GCP consent screen 转 **In production**(7 天死根因=Testing 状态轮换,项目级状态管所有客户端,新建客户端不解决)→ 新 client `318623800596-ehjjf3j9…`(installed,redirect=http://localhost)授权 → refresh_token(103 字符,scope gmail.modify+gmail.settings.basic,长期)→ 云端 `/etc/compass/mail.env` 四键 `COMPASS_GMAIL_CLIENT_ID/CLIENT_SECRET/REFRESH_TOKEN/FROM`(FROM=chunxiaoxx@gmail.com)→ 实弹发码 Gmail API 读回确认 → `COMPASS_EMAIL_REQUIRED=1` → **signup e2e 全绿**(signup 发码→收件箱读回真码→verify→login→cmp_live 签发)+四探针 FOUR-GREEN。顺序红线执行:凭证先落→实弹验证→最后开门禁。

**四坑**:
1. Windows 上传 env 片段带 CRLF → 值尾粘 `\r` → token endpoint 401(`mail.env: line 12: $'\r': command not found` 是 giveaway)。修复 `sudo sed -i 's/\r$//'`。**上传 env 一律先 LF**。
2. nginx sites-enabled/compass 只代理 `signup|login|tokens`,**漏 /verify(/resend)** → 公网 404 连锁 login 403。已补 `^/(signup|login|verify(/resend)?|tokens(/.*)?)$`。
3. EMAIL_REQUIRED=1 后 probes.py 假域账号必 403 崩。修=env 注入已验证账号对:`PROBE_A="chunxiaoxx+probeA@gmail.com:probe-account-20260906" PROBE_B="chunxiaoxx+probeB@gmail.com:probe-account-20260906"`(Gmail 别名收码,一次性 setup 长期复用;P4 只 revoke token 不动账号)。**cron 巡检已更新带此配方**(dfd7050a)。
4. nginx 静态 location 正则只放行图片/css/js **不含 .html** → privacy/terms 页 404;加精确 location 后 200。另:备份别放 sites-enabled/(`include sites-enabled/*` 无扩展名过滤 → conflicting server name warn)。

**技巧**:①gmail.modify 可读收件箱——e2e 验证码用 Gmail API `messages/list?q=to:别名` 自动读回,零人工独立复现;②redirect_uri=http://localhost + 本地 80 端口 dual-stack 捕获器(IPV6_V6ONLY=False)自动接 code;③本机 curl 访问 Google 域必走 `-x socks5h://127.0.0.1:10808`(env 代理时灵时不灵);④443 由 nginx.conf stream SNI 分流到 8443 compass 块,改 HTTP 层配置只动 sites-enabled/compass。

**daemon 僵死案(同日)**:两个 daemon.py 进程 6h 无心跳无监听(日志停 15:50,无崩溃栈)→ stop hooks 卡 5min+。清双 PID 重启后启动全程 **524s**(BGE 329+anchors 195+pkl 96)——冷启动预算按 ~9min,不是 2.5min。stop hooks 三个:①plugin stop_hook.py(连 daemon,带 token)②tools/fuel_intake.py(纯文件,不连 daemon)③…;卡的是等 daemon 的那个。**+9/7 再死两次(共 3 次/3 形态:双进程僵死→整进程消失→listener 半死进程仍写心跳)**——系统性问题挂 9/15 窗口与七算子三修复合批:加 watchdog 自动重启+查 accept 循环异常;期间 daemon 死只伤本地 recall/stop hooks 时长,不伤云端四探针与发布链。

**剩余**:`~/.gmail-mcp/credentials.json` 仍是旧 client(本地 gmail MCP 服务用,与生产链无关,该服务目前连接超时);域名验证 TXT(google-site-verification=3QP_…)用户是否已在阿里云 DNS 落地未确认。

**Why**: 9/8 发布 signup 是入口;7 天 token 死循环曾三度复发,production 是根治。
**How to apply**: 换/续凭证走同链(production 不必再转);env 上传先 LF;nginx 改动后 grep 全 location 集;四探针必带 PROBE_A/PROBE_B。相关:[[launch-sprint-status-20260905]] [[p1-host-migration-http-20260906]] [[daemon-auth-and-hf-offline-20260901]]
