---
name: rsi-loop1-recompute-verdict-20260914
description: RSI 环 #1 终局——非实现者复算抓 2 处自报绿(J1 覆盖 0/30·J3 body[:500] 截断)→ 用户拍板修复(hook 写入门+全文沿链)→ 重测四条全绿 → 环闭环+通报函已发(id 220);教训=探针过幸运窗口≠功能成立、预注册复算真拦假绿
metadata:
  node_type: memory
  type: project
  originSessionId: 79d94145-3f9a-48a7-8bda-93a4a2bdc1d5
  modified: 2026-09-14T13:27:49.874Z
fact_status: measured
---

# RSI 环 #1:复算抓缺陷→修复→全绿闭环(2026-09-14 午,提前于计划的 9/15)

**复算段(独立实测,回执 commit 0210f49)**:J1 FAIL(9/9 后 30 条新记忆 0 条带
fact_status——写入门只装在 daemon 读出+session_writer,直写路径零落点)、
J3 FAIL(chain_extra 恒空——`parse_memory_file` 的 `body[:500]`+`description[:120]`
截断,尾部 [[链接]] 永不展开;实现方 aegis 例偏移 1272 不可复现=误记)、J2 PASS
(三档全对)、J4 PASS、15 单测 PASS。

**修复段(用户拍板,插件仓 feat/memory-gate-trio d9a47e1)**:
- J3:`expand_chain_links` 经 `_entry_link_text` 读条目全文;
- J1:`memgate_stamp.py` PostToolUse hook(matcher Write|Edit,settings.json 接线),
  memory/*.md 缺 fact_status 即注入 inferred;fail-open/幂等;
- 数据面:30 条回填 inferred + 2 条嵌套层级规范化(实现方手写时把
  fact_status: measured 放进了 metadata: 下——两种读取口径的格式漂移点);
- 受控重启:精确 PID 杀旧→daemon_start.sh 拉新(冷启动 ~2.5min;回填改 mtime
  触发一次性重嵌入 24 文件 168s,期间 recall 超时属预期勿误诊)。

**重测段(全绿,判据档 commit a12c08c)**:J1 34/34=100%;J2 三档;
J3 arm-a 3 目标全带出+6 查询批量严格验证(每条 chain 目标∈via 全文链接∧via∈top)
ALL PASS;J4 GREEN;19 单测。**通报函已发**(mailbox id 220,trace
compass-platform-rsi-loop1-closure-20260914,兑现 id 213 soul 固化承诺)。

**可复用教训**:
1. 探针恰好在幸运窗口内通过≠功能成立(J3 窗口=body 前 500 字符);
2. 预注册+非实现者复算真拦假绿(本次拦下 2 处,含 1 处实现方示例不可复现);
3. 复算红灯先证伪自己探针:本日 3 次"FAIL"全是探针选样错(POSIX 路径形态/
   误选含链文件当无链样本/grep -c 数行不数出现);
4. hook 接线后本会话快照已过,首次实弹观察留下一会话(未验项,待观测)。

**同会话另产**:技能卡双语两版+三投放物料草稿;下午用户拍板 A2 直接投
awesome-openclaw-skills-zh → **PR #43 已开**(open/mergeable/+7,diff 已核验)。
ClawHub 授权 6 路全撞墙(CDP 复制 profile/junction 均被 Chrome app-bound
反窃取加密挡住——会话 cookie 绑数据目录,设计如此;clawhub API 只有设备流)。
结论:ClawHub publish 必须用户 2 次点击(或给 token),AI 无法全自动;补发条件
=用户说「出码」。**讨论帖 #166 已发**(openclaw-community/openclaw-hub →
Show and tell,已核验在线;OpenClaw 主仓 discussions 是关的,社区 hub 是
正场地)。**跨框同步函已齐**:v5 id227(记忆门影响+daemon 死亡对表)·
flywheel id228(流程同构+投放两件)·platform id220(早间闭环通报)——
四框信息面 9/14 傍晚对齐。剩余:ClawHub 2 击→PR#43 链接升级;WorkBuddy
案例等真跑截图。

**投放实操两坑**:目标仓 README 是 HTML 表格(web_reader 转 markdown 会骗人,
插行前必看原始字节);bash /tmp ≠ Windows python /tmp(C:\tmp vs AppData\Temp),
跨 bash/python 传文件一律显式 Windows 路径。

相关:[[memgate-trio-implemented-20260909]] [[rsi-loop1-merged-20260914]] [[outreach-channels-20260911]]
