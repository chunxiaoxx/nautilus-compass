---
name: session-contract-dogfood-bridge-20260822
description: compass 派发 · 统筹基建合约(全框接云 compass MCP · DOGFOOD_BRIDGE Plan A)· due 2026-08-26T22:00+0800
metadata: 
  node_type: memory
  contracts: 
    - contract_id: cnt_dogfood_bridge_20260822
      from: compass-dialog
      to: compass-dialog(self)
      action: 全框统筹接线:cloud compass MCP(9877)暴露可连 + 为 platform/V5/FDE 各 mint 带 agent_type 的 token + 各框 mcp.json 指向同一云实例 + session-start 注入跨框活合约/收敛日报
      due: 2026-08-26T22:00:00+08:00
      done_when: "四框各自 ingest 一条带本框 agent_type 标签的 obs,且任一框能 recall 到其它框的该条(跨框读写闭环实证)"
      why: "用户 8/22 批准;治'人肉总线'根因(跨框信息靠用户搬运);统筹进系统而非对话框脑子;协调经验自动成为 ExperiencePacket 燃料=吃狗粮"
  type: feedback
  originSessionId: a944fcc7-8e20-4a38-b8a8-46e4ccca757b
  modified: 2026-08-22T11:33:45.039Z
reinforce_count: 1
---

# 统筹基建合约(2026-08-22 派 · 用户批准)

- 设计复用 `docs/DOGFOOD_BRIDGE.md` Plan A(5/10 设计,服务已 active 实证:9876/9877 监听中,tokens.env 存在)。
- 关键注意:9877 现只绑 127.0.0.1,需开公网绑定或 ssh 隧道方案,任选其一落地。
- 排序:在链路活后续收尾(ledger 已首通)之后做,不抢主线。
- 关联 [[session-contract-fuel-loop-live-20260822]](✅ CONSUMED)。

## 进展(8/22 深夜七 · 基建全部就绪,差三框各一次 ingest)
- 云端:mint v5_dialog/fde_dialog tokens(/etc/compass/tokens.json)+ systemd restart compass-mcp-tcp ✓。
- 本机:9877 隧道(启动项 compass_tunnel.vbs 静默保活)+ 统一 shim ops/mcp_stdio_to_cloud.py(复用现成,弃自造)✓。
- 四框 .mcp.json 全写好(每框独立 token+agent_type,已 gitignore)✓。
- compass 框首条云 obs 写入+独立读回 ✓(fleet-capsules 落盘 · agent_type 正确)。
- 已知:云 load~14,BGE 过载时 recall 报 daemon overloaded(文件直查可靠);ingest 冷启动 ~147s。
- **done_when 差口:platform/V5/FDE 三框各重启会话 + ingest 一次**;broadcast 已发(_OUTBOUND_FROM_COMPASS_TO_ALL_20260822_dogfood_bridge_live.md)。token 本地备份 ~/.claude/.cache/compass_cloud_tokens.env。

## 进展(8/22 深夜八 · workbuddy 吃狗粮上云)
- SSH 曾被临时封禁(高频连接触发 reset,~1h 自愈)——期间降级接本地 daemon 9876,恢复后切云。
- 云 mint cmp_workbuddy token · workbuddy .mcp.json = nautilus-compass-cloud(ops shim · 9877 隧道 · agent_type=workbuddy-user)。
- **首个非 Claude Code CLI 的云写闭环**:ingest → 云落盘 → 独立读回 agent_type ✓(session_20260823-0848)。
- 云路 ingest 冷启动 ~2min(负载),冒烟勿用短窗口误判失败。
- 待办:隧道保活只登录自启(断了要手动跑 compass_tunnel.vbs);workbuddy 真实会话内首调仍待用户实测。

## 进展(8/24 · 云端同步幽灵查清+修复)
- "同步副本"真相 = 插件 stop_hook 挂的 cloud_ingest.py v1.6.0(5月 V7-N5):跨项目扫 24h 内最新 obs,SSH inline POST 云 8770,agent_type 硬编码 compass-dialog → platform/V5 本地 obs 被冒名推云。
- 修复(已冒烟验证):①agent_type 从源 obs frontmatter 透传(云端实测落 smoke-agent-xyz ✓)②stop_hook 只推本会话项目(NAUTILUS_COMPASS_PROJECT 过滤)。
- 真四框 token 云 ingest 仍 0:platform/V5 需重启会话挂 nautilus-compass-cloud 后重写。FDE 未动。
- 附:agent 框自报 gpu_4090.md/18d06a6 在 nautilus-v5 main 不存在(疑在 worktree 未合);其 L4a 在下 7B(任务书建议 1.5B 优先,样本<10 易假负)。
