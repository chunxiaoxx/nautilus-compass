---
name: ssi-jev-p3-pipeline-20261003
description: "动态权重线立档 10/3+10/4 更新:P3 管道+REG-100 门;errata 活水通道全通(delta_0003 收 3 条,33/200)+domain 门槛入白名单门;J8 已发(3037);A100 磁盘清理毕(vdd2 66%,删落选 turbo 留 q14)"
metadata: 
  node_type: memory
  type: project
  originSessionId: f5c5b189-5288-4869-9436-f0ef6160b475
  modified: 2026-10-04T13:59:39.183Z
fact_status: inferred
---

# 动态权重 SSI×JEV 线立档(2026-10-03,用户亲自推动)

## 已落地的档与数

1. **P3 设计档** `docs/plans/P3_DYNAMIC_WEIGHT_PIPELINE_DESIGN_20261003.md`:六段管道(S1 白名单门→S2 ≥200 训练单→S3 4090 短租→S4 回归门→S5 原子切换→S6 台账);**REG-100 零 correct→incorrect 翻转门**(从冻结 test149 分层抽,确定性读数无抽样噪声)+宪法地板(85%/ECE 0.10)+U 态守恒±2pt;同 delta 重训限 2 次防刷门;20 连绿验收+时间线不可承诺如实注;**因果倒置落点=权重只被白名单真值驱动(independent_recompute/human_review/official_rule/three_vendor_final),判官自产标签永久禁入**。
2. **J8 申报+P4 预注册** `docs/plans/J8_HOTPATH_P4_DECLARATION_20261003.md`(**起草未发送**):P4-1 记忆写入门 shadow fail-open(一致率≥90%/false-fail≤5%/时延≤50ms),P4-2 具身辅助腿,P4-3 F15 第一腿;装载期 judge 输出不进语料。
3. **delta_0001 校准读数**:G1/pusht 五演导出 **14 条**(pass7/U5/fail2,全 independent_recompute,锚件 sha256+函 2407/2422/2459/2464);**ledger cycle1=SKIP(14<200 不攒人情)**——五演=14 条/轮,200 门槛≈14 轮流入,**门槛现实性悬案挂 P3 首评审**(门槛有技术理由不能降:14 条训 LoRA=噪声;正解=攒源 errata gold/unlabelled 47/harness 轨迹)。导出器 tools/verdict_corpus_embodied_delta.py 幂等。
4. **ledger 制式**:仓 .gitignore 第 7 行 `*.jsonl` 全局忽略——**审计件须入 git 的一律 .json**(runtime/judge_lora_p3/ledger.json),设计档已同步。

## 悬而未决(下会话首要)

- **10/4 更新**:J8 已发(3037,deadline 10/11);errata 活水通道全通(#2634→2660→2667→#2678 A 案 10 条→delta_0003 收 E3/E4/S6 3 条,delta_0001-0003 合计 33/200;S2 叙事件移出→domain 门槛入白名单门,manifest 账实差 4/3 勘误注);**A100 磁盘已清理**(vdd2 66%/51G 可用,删 Qwen3.8-14B-Turbo 落选对照[eval 实测 q14 hit@5 0.6774>0.6094],留 Qwen3-14B);判分服务页 v1 底稿成+上站请求函 3074。
- ~~GPU 余额红灯~~:10/4 实测 A100 存活且 GPU 空闲+磁盘清理完成,实例未被终止=余额危机暂解 [推断,直连余额探针 SSL 失败待代理复核];磁盘 98% 旧读数作废(实测 85%→清理后 66%)。
- ~~compass main CI 红~~:R71 已清(34 处 F401,CI 转绿)。
- verdicts 端点(org_state)404 盯守中。
- 200 门槛校准提案件(不降格只校准,或维持+攒源路线)。

## 配方

- 训 GPU 实价复核:4090 1.65/h · A100-40G 2.75/h;LoRA 1.7B 增量 ~35min<¥2;凭证在 ~/.config/ai-galaxy-compute/credentials.json(AI_GALAXY_CREDENTIALS_FILE)。
- ai_galaxy API:instance list 顶层无 data 键要兼容;get_instance_detail 要 Container_name 非 Id;release/rent 走 broker API 层(_redact 遮罩坑)。
- inst_live.json 是 9/6 陈旧快照,勿当现况——**凡库存疑一律 API 实查**。

关联:[[g1-pusht-judging-arc-20261003]] [[p2v2-lora-milestone-20260930]] [[judge-corpus-p2-baseline-20260930]] [[rsi-deep-implications-20260916]]
