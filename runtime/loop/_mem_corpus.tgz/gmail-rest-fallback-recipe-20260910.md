---
name: gmail-rest-fallback-recipe-20260910
description: "gmail MCP 挂时的 REST 读信 fallback 配方——token 在 ~/.gmail-mcp/(credentials.json refresh_token+client_secret.json),换 access_token 后调 gmail API;Trajko 9/8 ack 已处理确认"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-09T19:21:55.111Z
fact_status: inferred
---

# Gmail REST fallback 配方(gmail MCP 连不上时)

- token 目录:`~/.gmail-mcp/`——`credentials.json`(refresh_token)+ `client_secret.json`(client_id/secret 在 `installed` 或 `web` 键下)
- 流程:POST `https://oauth2.googleapis.com/token`(client_id/client_secret/refresh_token/grant_type=refresh_token)→ access_token → `GET https://gmail.googleapis.com/gmail/v1/users/me/messages?q=in:inbox newer_than:3d`(Bearer)→ 逐封 `?format=metadata&metadataHeaders=…` 取头、`format=full` 走 payload.parts 递归 base64.urlsafe_b64decode 取正文
- 重授权:`scripts/gmail_reauth.py`(testing-mode OAuth token 7 天死,invalid_grant 时先 myaccount.google.com/permissions 撤旧授权再跑;长期解=PUBLISH APP)
- 参考实现:`email_sender.py` 的 `_send_via_gmail`(env `COMPASS_GMAIL_REFRESH_TOKEN` 路线)

**2026-09-10 首用读数**:3 天 inbox 8 封,Trajko(9/8 21:27 +0200)对我方 9/8 18:04 回信的 ack=即台账 9/9 处理过的那封,非新件;另 GitHub「Re: [mluogh/eastworld] outreach·Nautilus V5」issue 回复待 V5 线跟进、awesome-mcp-servers PR 有 bot 通知待查。

相关:[[gmail-verify-production-20260906]]
