---
name: zhihu-publisher-ready-20260927
description: "知乎发布器四修定稿+9225键盘管道死亡复活术+paste保strong翻案(昨日\"全被剥\"结论过期)"
metadata:
  node_type: memory
  type: project
  originSessionId: e01698b5-ca0c-4d79-8423-11cb0e107d82
  modified: 2026-09-26T16:07:17.379Z
---

2026-09-27 00:2x · cn_publisher.py 知乎腿收口(commit 2e42f732),dry-run 18/18 全绿(单次粘贴 2386 字/h3×6/链接 a=2/16 粗体),草稿已在 9225 编辑器里,用户点「发布」即发。

**四修(全是实测抓的,勿回退)**
1. `_sel_text` from_idx 必须当编辑器全文坐标下界用(旧版忽略):裸「11/18」的前文命中点在「首考 11/18」「v1 首考 11/18」内部,无下界会选中已加粗文本 → 工具栏加粗是 toggle,点了=取消加粗。
2. 点击坐标前必须 scrollIntoView:目标在视口外(rect.y 负几千)时 CDP 鼠标点击必落空——旧版 18/18 全 skip 的根因。
3. ab/al 旗标:**CF_HTML 粘贴实测保留 strong**(渲染为 span[style*=bold],16/16 保真;仅 <a> 被剥成裸 URL 文字)。昨日 commit「行内格式全被知乎 paste 管线剥」结论过期,以今日实测为准。已粗体的跳过不点。
4. 粘贴重试门槛=纯文本期望长(`re.sub(r'<[^>]+>','',body)`),不是 HTML 字节数:旧版拿 6129 字节当尺子,2386 字永不达标 → 重复粘贴正文翻倍(2386→4772)。重试前必须清空。

**9225 键盘输入管道死亡事故(复发预防)**
- 症状:insertText 正常、JS eval 正常,但一切 CDP 按键全灭(普通字符/keydown 事件/pasteEvent 全 0)。对拍 9224(Discord)keydown=1 → 坐实实例级,非机器/会话级。
- 复活:Browser.close 被 Chrome154 静默无视(ack 但不关)→ PowerShell 按命令行锚 `remote-debugging-port=9225` 找唯一根 PID 精确杀(子进程带 profile 路径会级联消退)→ `launch("zhihu")` 拉起。登录态随 Temp profile 持久,重启不需重扫码。
- 教训:CDP 配方类脚本挂掉时先分辨「管道死」还是「页面错」——keydown 监听器对拍是最快的分辨器。

**知乎发布现状**
- 9225 Chrome 常开(profile Temp/zhihu-chrome-profile);发布=`python scripts/cn_publisher.py zhihu <md> --publish` 或用户手点。
- 实验期产生的空草稿(多份 /p/<id>/edit)无害,知乎草稿箱可清。
- xhs 9226/smzdm 9227 骨架留位未适配。

相关:[[discord-cdp-chrome154-recipe-20260927]] [[bc1-launch-eve-20260926]]
