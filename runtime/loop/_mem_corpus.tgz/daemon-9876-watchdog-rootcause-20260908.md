---
name: daemon-9876-watchdog-rootcause-20260908
description: 9876 daemon 反复死的三个根因与 9/8 修复案——watchdog 计划任务配方+ping 必带 \n 的协议 gotcha+冷启动实测 349s
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-08T13:24:28.961Z
---

2026-09-08 发布夜诊断定案(9876 三死三形态的根因链,与 [[gmail-verify-production-20260906]] 的 stop-hooks 卡因互补):

**三个根因(全部实测坐实)**:
1. **会话进程树连带杀**:hook 拉起的 daemon(nohup+disown 在 Windows 不真正 detach),hook 超时/会话清理时被连带杀(PID 19524:21:12 起、几分钟内死、端口从未开)。
2. **冷启动 349s vs 豁免 120s**:BGE 294s + anchors 40s + bind,daemon_start.sh 假设 30s/GRACE 120s → 豁免期过 daemon 未起 → 下个调用者再拉 → 双实例竞态(历史上「双实例」的真源)。
3. **无 supervisor**:死了没人拉,靠下个 hook 碰运气。

**9/8 修复(全部已生效)**:
- `watch_daemon.cmd` + 计划任务 `nautilus_compass_daemon_watchdog`(schtasks 每 5min,幂等跑 daemon_start.sh,快路径活着 ~2s noop)——脱离任何会话进程树,这是 supervisor 正解。删除:`schtasks /Delete /TN nautilus_compass_daemon_watchdog /F`
- daemon_start.sh:nohup 输出 `/dev/null`→`.cache/daemon.log`(死因黑箱已修);GRACE 120→600s
- **探活三态**(CLAUDE.md 只说了「socket JSON」,缺了换行):
  - 进程死 = ConnectionRefused
  - 活 = `sendall(b'{"action":"ping"}\n')` → `{"ok":true,"pong":true,...}`(**必须带 \n**,服务端按行读;无 \n = 连上但无响应 = 假阳性「半死」,9/8 差点误诊)
  - curl HTTP 探 = 假阴性
- 旧 `/tmp/compass_daemon.log` 是 5/27 遗留文件,不是诊断源;真源 = `~/.claude/plugins/nautilus-compass/.cache/daemon.log`(21:14 起才有,之前全黑箱)
- auth_failed action=ingest 日志 = 系统性探测器噪声(9/1 已知),非病。

**9/15 #48 窗口剩余项**:真「listener 半死」(带 \n 仍无响应)时的 accept-loop 排查、记忆门三件套、旧入口退役。
