---
name: security-v09-xuserid-impersonation-20260830
description: 8/30 重大洞修复:8770(v0.9)X-User-ID header-only 身份=公网可冒充任意用户读记忆+投毒写;三处改 Bearer JWT-only+五项矩阵验证;生产版在 /home/ubuntu/compass 与 repo 版分叉的部署陷阱
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-30T15:06:37.535Z
---

# v0.9 X-User-ID 冒充洞 · 修复定案(2026-08-30)

用户问"其他任何人接入 MCP 都能获得我个人的记忆吗" → 查出两通道答案相反:
- **8097 新 MCP 通道:不能**(scoped token fail-closed,见 [[security-workbuddy-token-scoping-20260830]])。
- **8770 老 v0.9 服务:能**——`auth_user` 的 legacy 分支 `if x_user_id: return x_user_id` 无任何验证(注释承诺的 user-exists 校验从未实现),且 nginx `location ~ ^/(v1|healthz|readyz)` + `/v9/` 把 8770 **全量代理到公网 443**。实测 `curl https://compass.nautilus.social/v1/recall?q=test -H 'X-User-ID: u_probe_nonexist'` → **200**;`/v1/v14/ingest_obs` 更可**无凭证写任意 project 记忆目录(记忆投毒)**。近 48h nginx log:该路径零合法消费方(仅爬虫扫描,扫描器已在盯此域名),关闭无副作用。

## 已修(全部 grounded)

- 三处改 Bearer JWT-only:`auth_user`(读)/`drift_check`(读)/`v14_ingest_obs`(写,签名加 authorization)。JWT 携带 X-User-ID 时只作一致性校验(不一致 401)。
- 公网验证矩阵:冒充读 401 / 无凭证 401 / 投毒写 401 / 合法 JWT 200 / JWT+不匹配 header 401。
- iptables `-I INPUT -p tcp --dport 8770 ! -i lo -j DROP`(直连层,nginx 443 代理路径靠应用层修)。
- 本地 repo 与云端 `~/nautilus-compass` 版已改;**生产实际加载的是 `/home/ubuntu/compass/compass_http_v09.py`(另一演化分支,1668 行 vs repo 1690 行)**——同 patch 就地应用(脚本化精确替换 4 对,备份 .bak-20260830-security)。
- 探针期间写入的垃圾 session 文件已删;workbuddy token 按用户指示放宽为 `read:* + write:C--Users-chunx`(用户自用,不需要收紧)。

## 🔴 部署陷阱(复发风险)

**compass.service 的 WorkingDirectory=/home/ubuntu/compass,不是 ~/nautilus-compass**——scp 到 nautilus-compass 再 restart compass = 改了个没人加载的文件,restart 后行为纹丝不动(踩过,第一轮修复无效就是这么来的)。改 v0.9 行为必须 patch `/home/ubuntu/compass/`;两分支文件已分叉,不能整文件覆盖,只能函数级 patch。

## 遗留

- ~~nginx 443 的 `/v9/` `/v1/` 全量代理路径~~ **8/30 当晚已删**(用户拍板;备份 `/etc/nginx/sites-enabled/compass.bak-20260830-dev9`;公网四连验证:v1/v9→nginx 404、/mcp/→401 未误伤、落地页 200)。残余代理路径:/metrics(8770 无鉴权 200,低危信息泄露)、/.well-known/agent.json(a2a card,公开属协议惯例)、/a2a/(8770 无此路由=死代理)。
- 8770 服务本体与 9877 TCP 仍按 9/15 计划停;iptables 8770 直连 DROP 保持双层。
- 8770 无凭证=401 后,任何还在用 header 方式的旧客户端会断——近 48h 无流量,若有僵尸工具突然 401,答案在此。
- 12 个内部全权 token scoped 迁移仍挂账(9/15 目标)。

关联 [[security-workbuddy-token-scoping-20260830]] · LOOP_STATE P1(8770 退役 9/15)
