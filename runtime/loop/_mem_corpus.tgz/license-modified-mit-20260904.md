---
name: license-modified-mit-20260904
description: "2026-09-04 用户拍板 license 从 MIT 切 Kimi 式 Modified MIT(MIT+商标+托管 100 付费用户上限),窗口期论+客户分层论证支撑,遗留律师复核"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-04T14:40:32.132Z
---

2026-09-04 用户在四选一(MIT/FSL/Modified MIT/AGPL)中拍板 **b2 Kimi 式 Modified MIT**,当日执行完毕(commit c51b112):LICENSE=MIT 原文+附加 A1 商标保护("nautilus-compass"/"Nautilus"/"Compass" 名字+logo)/A2 托管服务月付费用户>100 须商业授权(自部署/内部部署/个人/研究/非托管分发永久免费)/A3 版权方豁免;历史版本保持纯 MIT(git 历史不重写)。全链路 14 处同步:README×3、launch post ×2、position paper ×2、package.json、npm/package.json、.claude-plugin/plugin.json、pyproject(license 字段+删 OSI classifier)、anchors_compass_marketing.json。

**Why**:决策链=①MIT 下"商业授权双许可"是伪命题,要牌必须改 base license;②窗口期=第①层传播开始前(零采用者=零反弹),发布后再改=HashiCorp 式背信;③"企业自部署≠云端收入死"客户分层论证(hosted 客户=懒人市场,自部署企业=B 路径入口,唯一威胁=第三方托管套壳);④用户选 b2 不选 FSL:语气更 MIT、国内开源圈熟(Kimi K2 先例)、可设免费额度——FSL 的 2 年自动转 MIT 信任锚没要。

**How to apply**:①A2 措辞与 100 付费用户额度系作者起草,**对外商用执法前必须律师复核**;②SPDX 无标准标识,各卡统一 `LicenseRef-Modified-MIT`,别回填 "MIT";③新增发布物料/卡文件时 license 字样写 "Modified MIT";④商标注册动作(名字两连撞前科)仍是待办。详见 docs/marketing/business_plan_20260904.md §2。关联 [[propagation-layer-order-20260904]] [[benchmark-naming-licensing-20260902]]。
