---
name: p0-full-verdict-20261002
description: "P0-full 定谳 F2 大幅 PASS(BGE 82.94%>14B 67.74%),P1 走 BGE 轻量件(用户拍板);两探针 bug 教训(fill_diagonal 屏蔽金标对=检索评测经典陷阱)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 202e18d7-9c37-49e6-9407-62ade2b030d8
  modified: 2026-10-02T14:18:55.300Z
fact_status: inferred
---

2026-10-02 晚 P0-full 全链闭环:可达性预检抓 v0 数据簇级模板缺陷(十判据簇 1428/1454 effect 全同→hit@5 结构上限 3-4%)→ 锚点 v0.1 回源重构(1454/1454 零未匹配,sha16=e710a70105df50e7,判据库 v0=10 条落地)→ A100 提取(q14 88 秒)→ 定谳:**F2 PASS——BGE-m3 hit@5=82.94% 反超 Qwen3-14B 67.74%(随机 0.34%)**。用户拍板:**P1(锚点+逆跳步)首选 BGE 轻量件**,14B 增量价值另找任务面(P2 监督建桥等)。

**Why(两探针教训,均可复发)**:
1. 🔴 检索评测探针陷阱:`sims[i,i]=-1e9` 屏蔽金标对后仍判"命中 i"——**hit@5 数学恒 0,却呈现为干净的 RED 读数**(本日从 a2v4 抄进 p0_full_eval,连错两处;A2-v4 的 0.0 读数作废)。检索任务的池含金标,"排除自身"只适用于去重/近重复任务。
2. 🔴 预注册判据档必须写"可达性预检的**计算过程**"而非断言:v2 档 F2"5% 远低于天花板"是断言,漏算簇内不可分;F1b 同构组口径(最大组 ≤25)才是正确度量。

**How to apply**:
- 以后写 hit@k 评测:金标在池内不屏蔽;先手算结构上限(同构组分布)再定门槛
- "红灯先证伪自己"本日两次兑现:0.0/RED 先查探针再信数据
- turbo 腿待修:Qwen3.8-14B-Turbo=Qwen3.5 架构(qwen3_5 类),transformers 4.57.6 不识别;venv --system-site-packages 装最新版报 SyntaxError(疑系统 python 版本低,待 pin 兼容版);GPU 被 G1 第六跑占(30.8G),等空窗
- 工件:A100 /root/vdd2/p0_full/out/{effect,cause}_q14.npy+meta;判据档 docs/metering/P0_FULL_PREREG_V2_20261002.md §5-6
- 关联 [[judge-corpus-p2-baseline-20260930]](judge 自报三陷阱同族)、[[rsibench-adoption-20261002]](同日里程碑)
