---
name: nacre-align-sla-tier-inflight-20261006
description: 用户三拍板(10/6 深夜):7B 先攒语料 3000 再对拍/assay-bench 查重红灯(Genentech 硬撞)/NACRE 对齐底稿+SLA 分档两函在途(10104/10105)
metadata: 
  node_type: memory
  type: project
  originSessionId: 44761907-86fe-49f8-b0ef-fc3ff9c0567b
  modified: 2026-10-06T13:14:34.842Z
fact_status: inferred
---

2026-10-06 深夜 R265(commit b45464b0),用户三拍板落地:

1. **7B 缓跑**(J3 追记):先攒语料至 ~3000 条(现 1162+errata 33/200+P3 活水)再以现成阶梯框架对拍 1.7B vs 7B。理由:14B 三实验已证容量非瓶颈,1162 条喂 7B 同样过参数化。
2. **元基准改名 assay-bench → 红灯搁置**(J5 追记):Genentech **AssayBench 硬撞**(arXiv 2605.10876,"An Assay-Level Virtual Cell Benchmark for LLMs and Agents",GitHub+项目页全套)+PyPI `assaybench` v0.2.1 被占(同类基因排序 benchmark)。候选双通道快查:**caliber-bench/proctor-bench 较净**,verdict-bench(GitHub 27 撞)/litmus-bench 弃。改名与否挂 NACRE 对齐会拍,10/12 上线前零成本窗。查重五通道法=GitHub API+PyPI json+HF api+arXiv api+WebSearch。
3. **两函在途等回执**:SLA 分档修正(**函 10104**,trace SLA-TIER-1006,deadline 10/7 12:00:L1 免费 24h/实测 25 单 20min,L2 48h,L3 维持 5 工作日);NACRE 对齐底稿(**函 10105**,trace NACRE-ALIGN-D1,deadline 10/7 18:00,docs/soul/NACRE_ALIGNMENT_DRAFT_20261006.md 四议题:定义机制化/部件归位表/双榜分工+命名/两外壳叙事,签署栏 platform+v5)。

**Why**:用户纠偏"compass 是长期记忆项目,评测定义错了+5 个工作日不是 AI 时代效率+NACRE 体系和架构没逐个对齐"——compass 定义口径已校准:**compass 本体=agent 长期记忆/记忆仲裁;判分评测=组织商业动作挂 Nautilus 平台品牌;验证方法学软件形态=assay**。三层不互换,对外文本一律用此分层。

**How to apply**:①明早守 10104/10105 回执+白皮书收卷 12:00+BYZ 归档通报;②元基准命名在用户拍 caliber-bench 前先跑五通道终核(HF/arXiv/网搜补全);③NACRE 对齐结论回填两外壳 v1.5(白皮书 v1.5 勘误窗 10/7 12:00 开)。关联 [[nacre-codename-decided-20261006]] [[judgments-j1-j7-settled-20261006]] [[benchmark-naming-licensing-20260902]]。
