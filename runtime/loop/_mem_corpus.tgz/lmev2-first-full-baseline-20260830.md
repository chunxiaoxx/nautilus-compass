---
name: lmev2-first-full-baseline-20260830
description: LME-V2 small tier 451 题首次全量基线——web 19.6%/ent 12.8%(doubao 口径一致 e2e500);短板=static/dynamic unknown 55-67% 检索适配未调优;evidence 在 vtf/_compass_lmev2_out
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-29T23:20:04.195Z
---

# LME-V2 首次全量基线(2026-08-30 · GPU 651799)

**数字(N5② evidence · commit 已入库)**:451 题 = web 240(**19.6%** overall / 26.8% 实答)+ enterprise 211(12.8% / 17.4%)。拒答率 ~28%。分类型(web 实答):procedure 52.4% > gotchas 46.7% >> dynamic 17.6% > static 11.7%;static/dynamic 的 **unknown 率 55-67% = 检索未召回**(多 session haystack 的 chunk/路由适配未调优),非 reader 拒答癖。

**口径**:reader+judge = doubao-seed-2-0-pro-260215 @ ARK(与 e2e 500 同款 subject,营销一个故事);compass_chunk_hybrid bge-m3 cuda。**绝对数不可与 e2e 500(42.6%,LME-M 单 haystack)直接比**——LME-V2 多 session 结构不同,此为首次未调优基线。

**固化位置**:`vtf/_compass_lmev2_out/`(README+aggregated_metrics+run_args·per_question.jsonl 在 tar 包内未入库)· 复跑命令在 TRANSFER_RUNBOOK。

**诚实营销策略(待用户拍)**:N5④ 营销帖主打 e2e 500 定案数字+优化故事;LME-V2 以"新基准线已建立(19.6%→优化中)"提及,勿把未调优基线当卖点。

**技法**:blockelite SFTP stat 与 listdir 行为不一致(get 报 ENOENT 但文件可见)——绕法=exec 通道 `base64 -w0 <file>` 流拉回。关联 [[lmev2-pipeline-smoke-proven-20260830]]。
