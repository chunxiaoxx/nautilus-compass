---
name: daemon-auth-and-hf-offline-20260901
description: "8/31-9/1 安全债清偿:本地 9876 daemon v3.0.10 token 鉴权(新写客户端必带 token)+ BGE 加载\"client has been closed\"死循环根因=代理断流须 HF_HUB_OFFLINE=1 + 云端 12 token 收窄 9 个剩 3 等报备"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-04T03:11:39.653Z
---

# daemon 9876 鉴权 + HF offline + 云端 token 收窄(2026-09-01)

## 1 · 本地 9876 token 鉴权(daemon v3.0.10 · commit c1c4a9e)

- 规则:`ping` 免鉴权(探活依赖 daemon_start.ps1/sh),其余 action(recall/drift/status/ingest/score/shutdown)一律 `hmac.compare_digest` 比对 token;无/错 token 回 `{"ok":false,"error":"auth_failed"}`。
- token 文件:`~/.claude/.cache/compass_daemon_token`(64 hex·0600·首次启动自动生成;`COMPASS_DAEMON_TOKEN_FILE` 可覆盖)。
- **新写 9876 客户端必须在请求 JSON 带 `"token"` 字段**(从上述文件读);已改齐:compass_hud_wrapper(plugins+ops 同步)、stop_hook(plugins+repo 同步,含 8/30 os import 差异收编)、ops/compass_status.sh、daemon.py CLI stop。
- 客户端 token 缺失时 daemon DENY + HUD 显示"服务未响应"——看到这个先查 token 文件而不是重启 daemon。
- **9/1 下午抓到漏改客户端 #1:本地 stdio 桥 `~/.claude/plugins/nautilus-compass/mcp_server.py`(Claude Code 的 nautilus-compass MCP server)直连 9876 不带 token → 上鉴权后 MCP "Connection closed"**。已修:`daemon_call` 自动读 token 文件附上。repo 的 mcp_server.py 是云端 TCP 版(连云端无鉴权 daemon),不需此修。
- **9/1 晚批量补齐漏网客户端(commit 572d5d0,7 处 auto-attach token)**:goal_heartbeat(recall·19:18 起每小时红灯根因=18:31 daemon 经 SessionStart hook 重启鉴权生效)、mid_session_hook(PreToolUse drift·每工具调用被 DENY=工具级 drift 防线静默失效半天)、recall.py(SessionStart both)、doctor.py、recall_fallback.py、recall_usefulness_exp.py、mcp_stdio_to_cloud(recall/drift/thread_recall·workbuddy 桥)。ping 类探活免鉴权不需改。⚠️ 教训再证:**daemon.log auth_failed 行是系统性探测器**(实抓 drift/both 两类,人工 grep 永远漏)。
- **watchdog 缺位实锤+复活(commit ce85540)**:旧 watchdog 计划任务 6/29 起就不存在(非 Disabled),forward_watchdog.log 停在 6/29——8/31 daemon 静默死 4.4h 的完整根因=零守望。v2:补本地 daemon ping 探活+死拉起段、删明文 token 硬编码(违反 token 不进 git,只从 COMPASS_CLOUD_TOKEN env 读)、无 env 时 forward 探活降级 TCP connect 防误报;计划任务 compass-watchdog 每 5min 已注册并验证首跑双绿。
- TDD:`tests/test_daemon_auth.py` 8 绿;⚠️ shutdown 不测带 token 的(handle_conn 会 os._exit 杀 pytest)。

## 2 · BGE 加载死循环病签名(本机代理断流时)

症状:`Cannot send a request, as the client has been closed.` + 每 recall 触发 "loading BGE model" → ~42s 后失败 → 无限重试。根因:SentenceTransformer 初始化 hub 在线检查走系统代理(127.0.0.1:10808),代理上游断时 httpx client 关闭。**修复:daemon v3.0.10 默认 `HF_HUB_OFFLINE=1`+`TRANSFORMERS_OFFLINE=1`(模型已缓存本地;setdefault 可外部覆盖)。** 再见此签名先查代理和这两个 env。

## 3 · 云端 12 token 收窄(9/1 完成 9 个,剩 3 等报备)

- 已收窄(值不变·数组→dict `["tools.read","tools.write","read:*","write:C--Users-chunx"]`,零打断):v5/v6/kairos/v7_telegram/v7_souls_fusion/my-agent/super_agent/fde_dialog/hr_dialog。备份 `/etc/compass/tokens.json.bak-20260901`,改后必须 `sudo systemctl restart compass-mcp-tcp`(无热加载)。
- 剩 3 等框报备(9/15):compass_dialog/platform_dialog/v5_dialog——跨框 ingest_obs(对方) 写入面,收窄前须各框确认。
- **已知边界**:写工具不带 project 参数(如 feedback_log)→ DENY(-32001),fail-soft 客户端无感;误伤回滚备份+restart。
- 留痕:`docs/SECURITY_TOKEN_SCOPE_20260901.md`(只记前缀+scope 不含值)。

## 4 · 2026-09-04 补:9876 探活必须走 socket JSON,curl HTTP 探=必假阴性

- 本地 9876 是**裸 TCP JSON 行协议**(daemon.py:1700/1782),不是 HTTP 服务。`curl http://127.0.0.1:9876/ping` 会把 HTTP 请求文本喂给 JSON 解析器:要么超时假阴性,要么"Received HTTP/0.9"怪错(那其实是 daemon 在答 json-parse 错误)。
- 正确探针(照 audit_kpi.py:121):`python -c "import socket;s=socket.socket();s.settimeout(5);s.connect(('127.0.0.1',9876));s.sendall(b'{\"action\":\"ping\"}\n');print(s.recv(256))"` → 期待 `{"ok": true, "pong": true, ...}`。ping 免 token。
- 事故实例:9/4 recall hook 报 daemon DOWN,我用 curl 探了三轮全假阴性,误坐实"两个昨日实例死锁"后 taskkill(方向对——端口确被占、BGE 召回确实不可用——但判据糙)。官方 socket 探针一发 pong。杀前该先用正确探针对每个 PID 逐个验。
- 另:启动到可服务要 ~2.5min(BGE 89s+anchors 27s+listen),刚启动 ping 拒连≠失败,等满 3min 再判。双实例同监听 9876(SO_REUSEADDR)会发生——治理时按 Win32_Process CommandLine 精确定位 PID。

关联 [[security-workbuddy-token-scoping-20260830]] · [[compass-daemon-pylibs-rootcause-20260830]]
