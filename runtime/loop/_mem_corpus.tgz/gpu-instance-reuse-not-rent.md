---
name: gpu-instance-reuse-not-rent
description: "GPU 实例复用纪律——连不上≠到期,先查实例列表 status;绝不随便新租(用户纠正:本来提供的就有)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-03T22:39:57.297Z
---

2026-08-28 用户纠正:"不要随便新租赁实例,本来提供的就有"“我已经退租你刚租的实例了,使用另一个现成磁盘的实例"。

**Why**:智星云实例 ssh gpu 连不上时,我误判"租期到期不可达"并连续新租 2 台(¥96 沉没,其中 1 台容器启动失败自动结束无法退费)。实际实例列表里 650640 一直 status=1 活着(V5 在用),另有 650957 付费期内停机可开机复用。SSH 不通的原因多是端口映射变化/容器重启/sshd 初始化慢,不是实例没了。

**How to apply**:
1. `ssh gpu` 失败 → 先跑 `python3 -m ai_galaxy_compute instances` 读 status/due_h,确认实例真死再谈租新
2. 用户提供的 SSH 地址/IP 过期≠实例到期,端口会变,用 connect 拿新端口
3. 新租任何实例前必须先问用户(钱包纪律);status=0 但 due 有效的实例 = 控制台可开机复用,CLI 无 start 命令
4. 部署脚本一律走国内源(pypi.org 在机房被墙 SSL 握手失败:清华 pip 源 + ModelScope + hf-mirror),详见 [[lmev2-deploy-playbook]]

**2026-08-28 补(共享盘调研)**:智星云三机制防重复部署:①自定义镜像(控制台 更多→创建,~3min)= 冗余选项;②共享盘(多副本冗余,跨实例挂载,放 /root/models 大件);③租用时勾"保留磁盘"。

**🔴 2026-08-31 用户策略修正(覆盖上条"必做镜像"结论):不买自定义镜像,保磁盘即保环境。**用户原话:"自定义镜像没有用,还要花钱,只要一直保存磁盘,就不会再重新搭建环境了"。实测成立:652509 纯保留盘恢复,环境原样起来;保留盘 DiskReleaseTime=0 无回收倒计时(¥0.40/天级),镜像 = 重复付费的冗余。GPU 资产策略 = 用时租、退租保盘、恢复即用;空盘(无环境的试探机)释放省钱。

**2026-09-04 补(密码轮换红灯)**:SSH 认证失败(AuthenticationException)≠实例死。先查 `get_instance_list` status(Status=1=活着),再 `get_connection_info(Container_name)` 重取密码——ssh_url query 里 `password=<base64>` 解码即新密码,实例重启后密码会轮换。vtf/gpu_ssh.py 默认值跟随现役实例走,改默认值+commit 防新会话/cron 环境丢 env 后再断。今日案例:654686 活着,默认密码还是旧机 zoh3Eich → 换 pei9teiL 即通。

**2026-08-31 实价参考(智星云,¥/h/卡,quote 探明)**:4090=1.65 · 4090PLUS=2.53 · A40=2.20(48G 但带宽窄,推理不如 4090)· A100 PCIE 40G=2.75(吞吐 ~2x,总账可反更省)· A100 SXM 80G=8.00(留给 V5 蒸馏线)。评测线(vLLM 小模型+bge)性价比首选 4090/4090PLUS;A100 PCIE 40G 是升级位。cu12x 环境跨 sm_80/89 通用,保留盘跨 GPU 型号恢复无需重装。
