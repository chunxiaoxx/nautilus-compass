---
name: pypi-311-published-20260906
description: PyPI 3.1.1 发布定案(9/6)——三重独立验证绿·构建配方 --no-isolation·403=截断 token 教训·README 补 pip Quickstart
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-08T14:24:02.492Z
---

PyPI `nautilus-compass 3.1.1` 2026-09-06 发布定案:

**验证(三重,非自报)**:①pypi.org/project/nautilus-compass/3.1.1/ → 200;②JSON API latest=3.1.1;③`pip download --index-url https://pypi.org/simple/ nautilus-compass==3.1.1` 真实拉下 wheel。

**发布前事实纠偏**:包早已存在到 3.0.1(作者 chunxiaoxx,自家非抢注)——README L22 的 PyPI badge 一直是活的,3.1.1 上去后 latest 自动指新。

**配方**:
- 构建:Store Python 的 `python -m build` 隔离 venv 有 bug(executable missing)→ 用 **`python -m build --no-isolation`**(当前环境需 setuptools+wheel)。
- 上传:`TWINE_USERNAME=__token__ TWINE_PASSWORD=… python -m twine upload dist/*` 走 socks5h://127.0.0.1:10808 代理(需 pysocks)。
- **403 Forbidden 教训**:用户第一次贴的 token 被截断(95 字符,真 token ~175)——上传 100% 后 403 = token 无效,先怀疑 token 截断/无效,别怀疑流程。
- 包结构:top-level `nautilus_compass`(116 py 文件,sdk/middleware/storage/proof/drift/recall/judges 子包)+ `gep`;6 个 console_scripts(nautilus-compass/compass-mcp/compass-a2a/compass-drift-history/compass-session-search/compass-session-writer)。
- README Quickstart 已补 pip 安装小节(commit 已推)。

**Why**: 9/8 发布的安装通道之一;PyPI 凭证曾是用户侧阻塞项,已清。
**3.1.2 补发(同日)**:3.1.1 的 PyPI 页 description 仍是 EvoMap 时代旧文案(retrieval-hit 80% / e2e 26.7%,与 75.4% 主叙事矛盾)→ 3.1.2 纯元数据刷新(description 换新口径);**发版必查四处版本**(pyproject/package.json/.claude-plugin/plugin.json/mcp_server.py SERVER_VERSION,3.1.1 才终结的三轨漂移别再犯);PyPI JSON API latest 有 ~分钟级缓存延迟,twine 成功后立刻查会回旧值,以 /project/<pkg>/<ver>/ 页面 200 + simple index 有包为准。
**How to apply**: 下次发版直接 `build --no-isolation` + twine env 配方;token 一律让用户整段复制(说"只显示一次,创建时直接全选复制")。相关:[[gmail-verify-production-20260906]] [[launch-sprint-status-20260905]]
**9/8 补案·第五处对齐点**:仓首页 Releases 卡片只认「有 Release 的 tag」——9/6 只 twine 没打 tag/建 Release,GitHub 门面停在 v3.0.0 直到发布夜被用户发现才补(`git tag v3.1.2 && git push origin v3.1.2 && gh release create`,notes 含 hosted/MCP-HTTP/e2e/对打/$3.50)。发版清单升级为五连:四处版本号 → PyPI → **git tag → GitHub Release**,缺一即「deploy 完了但没验证版本号」变体。
