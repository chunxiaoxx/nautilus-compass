---
name: t3-miniclaim-20260924
description: T3 jev-curate 接单+主批三 findings——首个外部 mini 履约;信箱故障实锤读路径并通报 893
metadata: 
  node_type: memory
  type: project
  originSessionId: 0591835a-21ac-4887-9bc5-28eb34d2b5f5
  modified: 2026-09-26T07:57:48.505Z
fact_status: inferred
---

9/24 轮 12:AkashPriyadarshii(jev-curate issue #3)接受免费域校准 offer(reasoning-math rubric+5 mock 行,要求 accuracy/Brier/ECE+一条阈值修复+raw artifacts,未经许可不发布);已认领回复(issuecomment-5798197880)+预注册+主批跑毕,工件在 `runtime/jev_trust_t3_jevcurate_20260924/`(commit b0f872e)。

三 findings(对甲方的核心交付):①jev-curate score 类 questions 的 criteria 是 dict,真 API(/v1/systemone)要求**字符串数组**→422→fail-closed,**生产全量拒收**(mock 全手写从未过真 API)②真 API score=**0-4 标尺**(legend+概率期望),甲方阈值按 1-5 写,+1 换算后 3.0 线本批 0/5 通过 ③R3 断言行 noul 0.78 误拒(真值边界 S1 已披露)。

坑:score 答案 confidence 可为 0.0;jev-latest≈jev-1.13.0(响应回显同版);noul 答案无 confidence 字段。

复算(9/26 已完成,commit 9246e1ea):**结论 RED**(判据字母严格)。主批 5 判据指标在预注册标注下逐位复现、签名双批 VALID、抄录 15/15——数据地基无恙;RED=①R1 depth 标注分歧(复算盲标 2 vs 预注册 4)**未在预注册敏感点清单**(只披露了 R5=S2)致 MAE 0.35≠0.69 ②RESULTS.md 报告层 6 数字不可复现(对照批 Brier 0.130/ECE 0.236 与自家 t3_results.json 0.11294/0.21 直接矛盾;"s−d 均值 −0.69"实为 MAE(符号均值 −0.23);"2.0 线 1/5"实为 2/5;S1 敏感性 Brier/ECE 0.015/0.048→实为 0.0172/0.108)。F2/F3 复核成立,F1 未触达。处置建议:勘误 6 处+R1 补录披露后复核再发。盲标教训:**预注册敏感点清单漏行=复算必然 RED**,披露清单要覆盖全部可能分歧行。

信箱:带 X-API-Key 仍读空(写入正常 887-893 均有回执)→故障实锤 platform 读路径,通报函 893(deadline 9/26 12:00,未复升级用户面板)。

[[bc1-and-loop-day-20260923]] [[jev-trust-launch-20260922]]
