---
name: hf-org-nautilus-compass-20261007
description: "HF org 实际名=nautilus-compass(非 nautilus-org,404);全权限 token 双框各一份;10/8 死线件完成;org token 入库制式与 revoke 处置"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 44761907-86fe-49f8-b0ef-fc3ff9c0567b
  modified: 2026-10-06T16:39:32.264Z
fact_status: inferred
---

2026-10-07 凌晨(commit b7282eea):**HF org 授权(10/8 死线件)完成**。

- **org 实际名=nautilus-compass**(hf.co/nautilus-compass 200 实测;用户口语记的"nautilus-org"是 404 不存在——建 org 时 slug 自动落了 compass 尾)。后续所有 HF 引用/上传一律用 `nautilus-compass`,勿写成 nautilus-org。
- **token 双份制**:用户为 org 生成全权限 fineGrained token 两份,platform 对话框先同步一份,compass 一份;compass 侧入库=`~/.claude/.cache/compass_hf_org_token.env`(0600,变量 HF_TOKEN_ORG/HF_ORG);个人 token(chunxiaox)另存 `compass_hf_token.env`。凭据永不入仓不回显。
- **验证配方**:`curl -H "Authorization: Bearer $HF_TOKEN" https://huggingface.co/api/whoami-v2` 看 orgs 列表;org 成员 API(/organizations/<name>/members)对 fineGrained token 可能 404,以页面状态码+whoami orgs 为准。
- 泄漏处置:HF 设置页 Access Tokens 即时 revoke;全权限 token 最小化暴露面。
- 后续挂载:判分器模型卡+caliber-bench 样例包(10/12 开业件)上 nautilus-compass org。

关联 [[nacre-align-sla-tier-inflight-20261006]] [[platform-mail-script-boundary]](凭据入库同制式)。
