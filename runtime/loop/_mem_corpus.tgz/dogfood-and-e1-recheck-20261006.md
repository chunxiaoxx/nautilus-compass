---
name: dogfood-and-e1-recheck-20261006
description: "灯下黑排查抓到云端daemon瘫痪19h(LRU churn根因,drop-in修复+probe第六源)+E1复算U态照报(主判维度零翻转)+七判断J1-J7落定+三厂商意向信号"
metadata: 
  node_type: memory
  type: project
  originSessionId: 44761907-86fe-49f8-b0ef-fc3ff9c0567b
  modified: 2026-10-06T07:53:48.129Z
fact_status: inferred
---

2026-10-06 午后三线战果(commit 链 01255ed0→b12a86c9):

**1. 灯下黑排查(用户令"检查全组织吃狗粮避免灯下黑")**——现行抓获:**云端 compass daemon 瘫痪 19h 无人察觉**:daemon.log 30.3 万行中 19.5 万(64%)=overload 拒连。根因链=云端 projects 356>COMPASS_ENTRIES_CACHE_MAX_PROJ 256→每次 recall 触发 LRU trim 逐出+重 embed(churn 复活)→CPU 106%+inflight 32 满→拒连。**为何无人知**:本地 hook 走本机 daemon、判分走信箱/A100——云端通道无内部消费者。修复=systemd drop-in `COMPASS_ENTRIES_CACHE_MAX_PROJ=500`+restart(零改码),overload 停止;防再犯=probe.py 第六源(cloud-daemon 过载计数,基线 195013)。教训:**大文件传输一律 SFTP(echo 管道静默丢块)**;基础设施要有内部消费者否则坏了没人知。

**2. E1 复算 U 态照报**(判据档 PREFOR_E1_RECHECK,判分器勘正=Qwen2.5-VL-3B bf16 v4 同款):双包 898 题回跑,合并五维一致率 0.9601<97% 冻结门→**U 照报**;**主判维度 dim1/pos/neg 零翻转(逐位复现)**,缺口全在 dim2/dim3 软维度相邻档漂移;4bit 对照实验反证量化假设(0.8173 更差,且 0ab4e735 注释确认交卷=bf16)。回函 10055/10056。BENCH_PANEL 引用建议=主判维度可引,软维度标 U。

**3. 七判断 J1-J7 落定**(见 [[judgments-j1-j7-settled-20261006]])+**首批外部意向信号**:10/12 榜单收录邀请触达 6+ 厂商,OpenHands#18065(进 maintainer 决策队列)/Cline#14859(转 Linear CLINE-3560)/LobsterAI#2801 回应——**意向非确认**(bot triage 不计,10/26 裁决以 maintainer 人工确认/复算请求为准)。

**How to apply:** 云端 daemon 健康看 probe 第六源;大件传输 SFTP;E1 软维度同环境复跑(本地无 CUDA 不可行,如实挂);10/26 裁决日读数=外部复算请求/首单意向+厂商 maintainer 确认分级。相关:[[dogfood-and-e1-recheck-20261006]] [[benchmark-system-dual-domain-20261006]]
