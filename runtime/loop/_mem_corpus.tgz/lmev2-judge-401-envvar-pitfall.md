---
name: lmev2-judge-401-envvar-pitfall
description: LME-V2 judge 401 根因=启动时 source .ark_env(ARK_API_KEY)而非 judge.env(OPENAI_API_KEY)——harness 默认读 OPENAI_API_KEY;生成不受影响可 rejudge 补救
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-04T01:10:14.718Z
---

2026-09-04 cheap-tier web full run(654686)判分阶段全 401 "API key format is incorrect"。

**根因**:上游 harness 的 `--evaluator-api-key-env` 默认 `OPENAI_API_KEY`(evaluation/harness.py:221)。昨晚启动命令用了 `source /root/.ark_env`(只导出 `ARK_API_KEY`)→ judge 客户端拿空 key → 401。9/3 d12 成功是因为用了 HANDOFF 命令 `export $(cat /root/e2e/judge.env | xargs)`(judge.env 里变量名正是 `OPENAI_API_KEY`)。三个 env 文件(/root/.ark_env /root/e2e/judge.env /root/e2e/ark.env)是同一把 key(b8ed...),key 本身没坏。

**Why**:同一把 key 存在两套变量名封装,启动路径一换就踩;reader(本地 vllm)不依赖该 key,生成阶段零报错,401 要等判分阶段(生成全部完成后)才爆,滞后 ~11h 才发现。

**How to apply**:
1. GPU 机起 LME-V2 评测一律用 HANDOFF 命令(judge.env 导出 OPENAI_API_KEY);禁用 source .ark_env 路径
2. judge 阶段 401 时先验证 key 活性:export judge.env 后 openai 客户端打一发(本次 JUDGE-ALIVE OK)
3. 生成完成后判分报废 ≠ 全废:per_question.jsonl 每行含答案,judge 0 分垃圾可用 rejudge_run.py 全量重判(d12 双域成熟路径);生成阶段在内存/逐行落盘,**杀进程=丢未落盘答案**,别杀
4. 判分阶段不占 GPU(reader 已完),可与下一域生成并行接力
关联:[[lmev2-pipeline-smoke-proven-20260830]](六坑)·[[gpu-old-disk-restart-20260903]]
