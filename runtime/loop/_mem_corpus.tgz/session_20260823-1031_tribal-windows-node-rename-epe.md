---
name: tribal-windows-node-rename-eperm
description: 
type: discovery
concept: pattern
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# tribal-windows-node-rename-eperm

## 上下文


## 内容
Windows Node 踩坑双联(2026-08-23 happy 插件源码核实):① fs.rename 走 MoveFileExW,目标文件被 Defender/监视器瞬时持句柄(无 FILE_SHARE_DELETE)时报 ERROR_SHARING_VIOLATION→Node EPERM(errno -4048);POSIX rename 不管句柄,故只在 Windows 并发场景爆。修法:rename 重试(外部锁是瞬时的,5×100ms 递增)+兜底 copy+unlink;tmp 文件名带 pid+uuid 防撞。② execSync 派生进程在 Windows 必弹 conhost(windowsHide 对 execSync 无效);PowerShell Get-Command -ErrorAction SilentlyContinue 找不到命令也返回 0,checkCommand 恒真。修法:纯 Node 扫 PATH/PATHEXT,零进程派生。③ 每次启动无条件 read-modify-rename settings 是雷鸣群,deep-equal 即 no-op 可灭 8+ 调用点的写入风暴。
