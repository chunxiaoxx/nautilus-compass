---
name: mainline-anchor-20261008
description: 用户三点拍板——compass+assay+jev三位一体/NACRE创新模型=compass主线/评测燃料判分全归compass;串线困惑根因=主线定义演进非执行错误
metadata: 
  node_type: memory
  type: project
  originSessionId: 44761907-86fe-49f8-b0ef-fc3ff9c0567b
  modified: 2026-10-08T01:00:28.411Z
fact_status: inferred
---

2026-10-08 用户三点拍板,compass 主线边界锚定:

1. compass + assay + jev = 三位一体判断体系,全归 compass;
2. NACRE 创新模型架构(压缩×验证+因果倒置+assay+jev+原生记忆+技能内化)= compass 主线;
3. 基于 1 和 2 的评测、燃料、判分等 = 全部 compass 业务。

**推论**:harness 评测/判分/榜 = compass 主线自然延伸(非串线);v5 主线 = harness 执行+蒸馏(互补不冲突);前期"串线"困惑根因 = compass 主线定义在演进中(纯记忆→记忆+判断→六组件统一),非执行错误。

正本:docs/soul/MAINLINE_ANCHOR_20261008.md。关联 [[architecture-mainline-20261004]] [[pmf-mainline-agent-harness-20261005]]。
