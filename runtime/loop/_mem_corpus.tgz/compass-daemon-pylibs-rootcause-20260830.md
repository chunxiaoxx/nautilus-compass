---
name: compass-daemon-pylibs-rootcause-20260830
description: compass daemon 1322 次 recall 失败根因=启动脚本注入 PYTHONPATH=C:\pylibs 旧库快照;HUD 丢失/报错同源;修=移除注入改用 site-packages
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-29T18:05:29.081Z
---

# compass daemon 长期报错根因 · PYTHONPATH=C:\pylibs(2026-08-30 修复)

**现象**:HUD COMPASS 丢失不稳定 + "compass 一直报错" + `daemon.log` 累计 **1322 次** `conn handler fail: Could not import module 'PreTrainedModel'`,每次请求触发 BGE 加载→秒挂。

**根因链**:
1. `daemon_start.ps1` / `daemon_start.sh` 启动命令注入 `PYTHONPATH=C:\pylibs`(2026-08-23 的"torch 短路径防 WinError 206"修复)
2. `C:\pylibs` 是 2026-07 时代的整套旧库快照(旧 transformers/st/torch),**优先于 site-packages**
3. 旧 transformers 的 lazy import 炸(`import_utils.py` `_LazyModule.__getattr__` 兜底,cause 被 daemon except 吃掉只见表面文本)
4. → daemon 永远加载不出 BGE → 所有 recall/drift/HUD 失败;HUD wrapper 每次冷启动连不上 → "HUD 总是丢失"

**修复**(2026-08-30):两个启动脚本移除 pylibs 注入。前提已成立:Store Python site-packages 现有 torch 2.11.0+cpu + transformers 5.16.1 + sentence-transformers 6.0.0(后两者为对齐 GPU 机在产组合本日升级),BGE-m3 实测 LOAD_OK。修后 TCP 实测 `{"ok": true, recall:[gpu-e2e-rootcause-chain…]}`。`C:\pylibs` 目录保留不删(回滚容易)。

**排查技法(可复用)**:
- 报错文本先 grep 库源码找出处 → 发现是 lazy getattr 的**兜底报错,真 cause 在 `from e` 里被吃**
- 对照实验逐步消差:HF_ENDPOINT/离线模式/device 判定/解释器路径全同 → 剩 env 差异 → diff 启动脚本发现 PYTHONPATH 注入
- `netstat -ano | grep :9876` + `Get-Process StartTime` 判"监听者是不是刚启动的新进程"(重启后必须核时间,防连到旧进程得出假结论)

**关联**:本机性能差(RAM 80%/CPU 100%/5 会话并行)放大了故障感知;另发现过双 daemon 同抢 9876(Windows 允许双 bind,僵尸实例白吃 916MB),已杀。
