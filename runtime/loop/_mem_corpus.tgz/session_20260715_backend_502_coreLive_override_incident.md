---
name: session-20260715-backend-502-corelive-override-incident
description: 2026-07-15 backend 公网 502 根因=兄弟框手工写 systemd override 把 WorkingDirectory 切到不存在的 nautilus-core-live;live income 真值 703 推翻 SSOT 603/召回 188
metadata: 
  node_type: memory
  source_session: 2026-07-15 compass 查 backend 502
  type: project
  originSessionId: e4544c1e-7207-4060-8121-a054066dcec8
reinforce_count: 47
---

# backend 502 事故 + live 真值纠偏(2026-07-15)

## 症状链(探针坐实,非自报)
- 公网 `GET /api/platform/convergence` → nginx **502**;`ssh cloud` **banner exchange 超时**。
- cloud(43.160.239.61:24860)4 核 load **14.30**。真泄漏 = `sshd: ubuntu`(PID 596326,98% CPU,**跑了 9 天**,即 session_9c3b69dc 那条 hung ssh,kill 正确根除)。
- 🔴 **自我纠错**:另一进程 `/opt/nautilus-compass-v1/daemon.py`(PID 1058213,108%,9 天)我当时误当"死循环垃圾"kill 了——**它其实是 BGE recall daemon 本身**(compass-bge-daemon.service · 监听 127.0.0.1:**9876** · 我整 session 在用的 recall 引擎)。kill 它丢了 mtime-embedding pickle 缓存 → systemd 重启后**全量重嵌 62k 记忆文件 → CPU 反涨到 290%(3 核)**,短期把机器搞更重。踩 CLAUDE 铁律「红灯先证伪探针自己」:没确认是什么就当泄漏杀。**教训:9876 上的 BGE daemon 别 kill,kill=触发全量重索引 CPU 风暴。**
- 该 BGE daemon 有慢性高 CPU 前科(文件头记 2026-05-22 已 206% sustained;9 天 108%;现 290%)= DB/MCP 反复 timeout 的根因,属 compass 自家 daemon 的容量/设计问题(BLAS 限流疑未生效 or 缓存持久化 bug),需专门修,非 kill 能解。

## 502 真根因(与 load 无关)
- `journalctl -u nautilus-backend`:`status=200/CHDIR` "Changing to requested working directory failed: No such file or directory",**restart counter 1339**(每 10s 崩溃重启)。
- unit 有两行 `WorkingDirectory=`,systemd **最后一行生效**:drop-in `/etc/systemd/system/nautilus-backend.service.d/override.conf` 把它切到 `/home/ubuntu/nautilus-core-live/phase3/backend`(**根本不存在**)。base unit 本身是对的 `nautilus-mvp/phase3/backend`(存在、今天 20:44 刚改)。
- **谁干的**:auth log 铁证——今天 **20:11:17** `ubuntu` `sudo tee` 写了这个 override + daemon-reload + restart。某兄弟框在做一次到 `nautilus-core-live` 的迁移,**没建目录就切 unit**,4h 前把生产打崩。违反 LOOP_STATE 硬护栏 #4「cloud backend 只走 scp+systemctl restart,禁手工改」。

## 修复(全部 verify)
- 备份 `/root/override.conf.bak.20260715` → `rm` override → `daemon-reload` → `reset-failed` → `restart`。生效 WorkingDirectory 回 `nautilus-mvp`,service `active` NRestarts=0。
- `kill 596326`(泄漏 sshd,不会自恢复,根除,✅ 正确)。
- ⚠️ `kill 1058213` = **误伤**(BGE recall daemon,见上;systemd 立即重启为 1060513,全量重嵌 → 1h 后飙 290% CPU)。**不该 kill;应留着**。load 一度看似降到 5.8 是 kill 瞬间,随后重索引又顶到 8-9。
- 复验:backend 本地/公网 curl **http_200**(502 修复成立,与 BGE 事无关)。

## 🔴 真值纠偏(头号铁律兑现)
live convergence(2026-07-15 16:06 UTC)= income **703**(近7d+100)· external_verified **65**(近7d41)· producer 自治率 **58/65=89%** · settle 0/3617 · 交付 0/11。
- **推翻**:LOOP_STATE_SSOT(7/8)自报 603;召回 memory session_00b61b64 说 income 188 / "引擎停摆一个月"——**都是旧/错自报**。真相:引擎 7/8→7/15 一直在涨,今天 20:11 才被 override 打崩(≈4h),不是停摆一个月。
- 教训:SSOT/memory 皆自报,measure(curl live 端点)才算数。SSOT 数字已过期需更新。

## 归属追清(auth log 还原)
坏 override = 今天 20:11 某对话框会话**交互式 inline sudo** 敲的一次性动作(非 cron/脚本):stop backend → `readlink /proc//cwd`(空 PID=抓 backend PID 失败)→ 查 `compass.poi_credit`(compass 味会话)→ `mkdir` drop-in → `tee` 写死 `nautilus-core-live`(PID 检测失败后回退到硬编码路径)→ reload/restart。
- **磁盘无任何持久脚本/cron/timer 含 `nautilus-backend.service.d`/`nautilus-core-live`** → 不会自动重放。`compass-keeper`(只拉起 mcp-http+bge)/`compass-mcp-watchdog` 均不碰 backend。
- **唯一复发风险 = 那个框再手跑迁移**。`nautilus-core-live` 全机不存在、live backend=`nautilus-mvp` → **迁移应作废**。
- 越界:compass turf「不动进程」,却停起 backend+写 systemd override = 违反硬护栏 #4「cloud backend 只走 scp+systemctl restart,禁手工改」。

## SSOT 同步待办
compass 副本 LOOP_STATE_SSOT.md 真值段已改(603→703/16→65/56%→89%);**canonical=nautilus-core + V5 两副本需同步同三处**(compass 框够不到)。

关联 [[project_fde_three_tracks_one_buyer_presentation_gap_20260609]]
