---
name: judge-pipeline-first-card-20261009
description: "判读管线首夜全链信用闭环——首卡delivered→平台独立复现通过(#10727)→判例入册delta_0006(语料2258)·sha口径LF固化·派单制信箱函·L1/L2分界"
metadata: 
  node_type: memory
  fact_status: measured
  type: project
  originSessionId: 5a6ae1c6-f5d4-4f54-a33a-73a088959318
  modified: 2026-10-08T12:53:08.598Z
---

# 判读管线首夜全链(10/8-9 · 判分机构身份首次实弹)

- **全链**:platform 派单函([派单·assay] 前缀,#10713)→compass 接单判读(SOP 六步)→nautilus-l1-0002 出卡(criteria_sha16 随卡 live)→**平台独立复现通过(#10727,verdict/sha16 逐项命中)**→delivered 关单→判例入册 delta_0006(语料 2257→2258,merged_sha16=93dccd83)——出卡→复核→归档→语料棘轮+1 一体。
- **sha 口径已固化**:.gitattributes 判分资产类(*.jsonl/*.json/docs/metering/**/docs/cases/**)`text eol=lf`;**新登记一律 LF 口径**(git blob 字节=GitHub raw=cloud checkout 三处一致);API 历史锚 b81eca84=Windows 工作树口径,LF 等价=5c8e0a7c(双口径注)——平台复核报"旧 sha"先怀疑口径分裂再怀疑版本。
- **派单制**:POST 受理→自动 [派单·assay] 信箱函(trace_id=assay-dispatch-<单号> 幂等);is_smoke 四字段口径过滤读数(12 单 11 smoke=此前"积压红灯"大头为测试噪音);判读岗开轮查信箱前缀即接单。
- **L1/L2 分界(10722 确认)**:L1 榜单收录级机器判读=v5(四门零裁量);L2 深度判读=compass(人工+判据,SLA 24h/48h/5d);争议复核通道归 compass 判读岗(独立背书)。
- **4096 重算验收口径已冻结**(S6_RECOMPUTE_ACCEPTANCE):五门审计表形态门+单一 REPEATABLE READ 快照+零"部分通过";冲正复算 RED 假警报防范=输入源核验(10730 磁盘令后 preds 正本=runtime/loop/_r181_board30/preds_arm_a.json,round1_merged.json 四桶是计数非 id 列表——对照先找 per-instance 报告 django_report_a.json)。

相关:[[judging-evidence-tiers-20261003]] [[first-card-credit-loop]] [[s6-disk-final-and-batch-guard-20261009]]
