---
name: commit-attribution-rule-20260923
description: "用户纠正——commit 署名必须是 chunxiaoxx,禁止 Co-Authored-By 尾注(Claude/Happy 都不加)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5103bb42-025f-4754-adcf-4ff0f2b7218d
  modified: 2026-09-23T01:09:44.759Z
fact_status: inferred
---

commit 署名纪律(2026-09-23 用户纠正,发现 GitHub 上各仓提交署名显示为 claude 而非 chunxiaoxx)。

**Why**:两层原因——①nautilus-compass repo 级 git config 曾被设为 `nautilus-platform-saas-dialog <saas-dialog@nautilus.social>`(平台迁移期多框身份),该邮箱不关联 GitHub 账号→主作者灰色无名;②`Co-Authored-By: Claude <noreply@anthropic.com>` trailer 被 GitHub 渲染成 Claude 官方头像徽章,视觉上抢走主署名。用户全局规则(git-workflow.md)早已写明「Attribution disabled globally」,加尾注本就违规。

**How to apply**:
- 所有仓 commit 主署名=`chunxiaoxx <chunxiaoxx@gmail.com>`(nautilus-compass repo config 2026-09-23 已修;新仓/临时 fork 工作目录开工先 `git config user.name/user.email`)
- **任何 commit 不加 Co-Authored-By 尾注**(Claude/Happy 都不加),PR body 里的生成器致谢行也不加
- **历史已全量重写**(2026-09-23 用户批准执行):filter-repo+mailmap 把 saas-dialog 及全部人名变体统一为 chunxiaoxx(1340 commits/35 分支/29 tags,bot 保留),mirror push 强推;双镜像备份在 `C:\Users\chunx\Projects\nautilus-compass-mirror-backup.git` 与 `D:\backup-git-20260923\`;**2026-09-23 前所有旧 commit sha 已失效**(新历史 7a24ab3 起),旧 sha 溯源走备份;声明档 docs/plans/HISTORY_REWRITE_NOTE_20260923.md。配方:mirror clone 上跑(工作仓不动)+push --all/--tags(mirror push 会撞 GitHub 只读 refs/pull 被拒,heads 其实已推上)+本地换轨用 update-ref 不碰工作区+服务器 fetch+checkout landing/。墙面验证锚审计=全指外部仓不受影响。
