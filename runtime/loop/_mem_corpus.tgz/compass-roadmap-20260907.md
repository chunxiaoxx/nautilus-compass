---
name: compass-roadmap-20260907
description: "compass 四层路线图用户拍板(9/7)——仲裁器定位对句·VerifyPack v0.2 立项(#46/#47)·记忆门三件套 9/15·QC 判据定标;flywheel 两函复算排 9/9-9/10"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-07T17:12:27.019Z
---

2026-09-07 用户拍板 compass 方向定案(roadmap 已升级 **v2 四维度系统版**:算子/理论/工具链/生态×三 Phase 总览矩阵+统一时间轴,同文件;+ 2026-09-07-verifypack-v02.md):

**四层同心圆**:①圆心=具身数据+第三方数据有效性验证(flywheel 信件流已在发生)②仲裁器产品化(声称→复算→签名→结算;对句「Aegis arbitrates actions, we arbitrate memories — and what their data is worth」)③记忆介质+检索科学(现役)④标准/度量衡(七算子/判据库/NautilusMem)。

**三件产品**:①VerifyPack v0.2 立项(#47,9 月内,DoD=batch001 端到端跑通新协议:build/verify/receipt/check+ed25519)②记忆门三件套 9/15(fact_status/查重合并/沿链)③QC 判据定标(flywheel 掌形三元组,200 条批次后)。

**不做**:动作门 policy engine(Aegis 已占)。

**已还信**:platform keeper 回执(不采纳其 patch,自修 mtime 版理由表)+flywheel 两函 ack(复算排 9/9-9/10,#46)。

**Why**: 方向锚业务的第一个产品化动作;flywheel batch001=真实需求样本。
**+RSI 前瞻层(同日追加拍板)**:roadmap §2.4——RSI 五环瓶颈在验证+选择(=验证基础设施=②层顶点);组织自改进三级(L2 现在/L3 目标);四条设计=改动仲裁/分层权限/每步可审计/外部锚不可拆;**9/15 三件套升级为首个 RSI 试验环(#48),预注册判据四条已冻结**(fact_status 100%/查重零误合并对照/沿链 100%+P95≤1.2×/全局回归门含三 fact hit@3 不降)。

**+仲裁栈设计图纸(同日第四拍板,docs/plans/2026-09-07-arbitration-stack-design.md)**:五层栈(L0 VerifyPack 原语/L1 判据语言/L2 验证方网络/L3 回执哈希链/L4 结算声誉)×七算子仲裁化(**核心洞见:忘=共识函数——decay 从时间函数升级为共识函数,PoS for memory**);三不同构=创新点(判分卫生学=概率世界共识协议/判据库中心化是护城河/trustless 不可能→对外只说 PKI 式信任最小化);三 Phase 挂外部采信判据,Phase 3=外部第一采信分水岭;不做代币化/去中心化/大爆炸。头脑风暴已发三框(9/10 22:00 回函,六开放问题正本 verifypack-mvp-brainstorm.md)。

**How to apply**: 9/9-9/10 先做 #46(复算),产出反哺 #47 spec;9/15 窗口执行 #48(RSI 试验环:判据已冻结,流程=实现→回归→非实现者复算→合入);商业模型等 batch001 复评再定(先协议后生意)。相关:[[aegis-compass-competitor-20260907]] [[memory-audit-seven-operators-20260907]]
