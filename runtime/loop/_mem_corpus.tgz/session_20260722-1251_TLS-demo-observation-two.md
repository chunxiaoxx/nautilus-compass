---
name: TLS demo · observation two
description: reader will fetch this via resources/read
type: feature
concept: pattern
drift: green
drift_signals: []
agent_type: custom
user_id: u_local
ingested_via: mcp
proof_of_recall: not_attempted
declaration_type: none
tier: working
decay_rate: 0.5
promote_after: 1_access
reinforce_count: 0
---

# TLS demo · observation two

## 上下文
reader will fetch this via resources/read

## 内容
Proves end-to-end: ingest (tools.write scope) → resources/read (resources.read scope) over the same mTLS socket family · peer identity checked by CA.
