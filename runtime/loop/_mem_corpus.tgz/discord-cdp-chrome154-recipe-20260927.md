---
name: discord-cdp-chrome154-recipe-20260927
description: Chrome154 下 Discord CDP 发帖配方四坑(placeholder 撞类名/Enter 唯一通道=CDP text\r/nav 废 context/f-string 拼 JS 大括号)与 9224 重启配方
metadata: 
  node_type: memory
  type: project
  originSessionId: d0c2a295-24b5-4f89-91ae-92a6be183219
  modified: 2026-09-26T10:42:51.165Z
fact_status: inferred
---

2026-09-27 BC1 发布日,scripts/post_discord.py(9/24 Chrome153 实证配方)在 Chrome 154 全线失效,四根因全勘误后回写仓(commit fc2c1311),实证 GREEN(BC1 帖上墙 show-and-tell,msgId 1553355737218945064):

1. **placeholder 撞类名**:Discord 改版后 placeholder DIV 也带 `slateTextArea` 类,`querySelector('[class*=slateTextArea]')` 抓到 placeholder(`isContentEditable=false`)→ focus 漂到按钮 → `Input.insertText` 落空;且"residue≤25=已发"的判据把没插进去(占位符"Message #show-and-tell"恰 20 字)误判成发送成功。修:选择器 `div[role=textbox][class*=slateTextArea]`,插入后按目标长度验长。
2. **Enter 唯一有效通道 = CDP `Input.dispatchKeyEvent {type:"keyDown", text:"\r"}` + keyUp**;JS `dispatchEvent(KeyboardEvent)` 在 154 失效(153 曾有效)。
3. **发帖脚本勿内嵌 Page.navigate**:nav 后旧 execution context 报废,evaluate 持续 `EXC:Uncaught` 超过 16s;先 `cdp_tool.py nav` 到位再跑发帖脚本(脚本只校验 location)。
4. **f-string 拼 JS 的 `{{}}` 转义连翻两次车**(多/少一个大括号=SyntaxError 只报"Uncaught"无细节,exceptionDetails.description 才有真相);JS 片段一律普通字符串拼接,大括号直书。读回比对要剥 markdown(`**` 渲染后消失)。

**9224 重启配方**(窗口被关后,profile 在 `%LOCALAPPDATA%/Temp/discord-chrome-profile`):`"C:/Program Files/Google/Chrome/Application/chrome.exe" --remote-debugging-port=9224 --user-data-dir=<profile> --proxy-server=socks5://127.0.0.1:10808 https://discord.com/channels/@me`;登录态判据=title「Discord|好友」+ 未跳 /login + serverNav DOM(轮 24 法)。完整记录:runtime/assay_bc1_20260927/DISCORD_POST_RECORD.md。

关联 [[bc1-launch-eve-20260926]] [[examhall-charter-20260916]]。
