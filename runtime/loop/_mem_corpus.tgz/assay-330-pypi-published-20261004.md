---
name: assay-330-pypi-published-20261004
description: "PyPI 3.3.0 发布(10/4,发版五连全闭环)+nautilus_compass 根目录映射包布局坑(新增子包必走 package-dir 映射,tests/CLI 未安装环境用 importlib 文件加载)"
metadata: 
  node_type: memory
  type: project
  originSessionId: c62a754e-c031-437d-a37a-0d217fbf3144
  modified: 2026-10-04T11:42:02.388Z
fact_status: inferred
---

PyPI `nautilus-compass 3.3.0` 2026-10-04 发布定案(3.2.0 后 24 天空窗结束):

**内容**:nautilus_compass.assay 子包(verdict schema v2 校验正本+challenge 八件/errata 勘误提交侧 schema)+tools/verdict_schema_v2.py 薄壳化+版本五处对齐(修复 3.2.0 起版本同步测试就红的漂移)。

**🔴 布局坑(本次踩两次)**:`nautilus_compass` 是**根目录映射包**(pyproject package-dir `"nautilus_compass" = "."`,sdk/middleware/judges 等全是根目录映射子包)——repo 里**没有** nautilus_compass/ 目录。新增子包两要:①目录放根(如 assay/)+pyproject packages 加 `nautilus_compass.assay`+package-dir 加映射;②未安装环境下 tests/CLI **不能** `import nautilus_compass`(需 repo 父目录在 sys.path 才成立)——用 importlib.util.spec_from_file_location 按文件路径加载同源文件(tools 薄壳与 tests/test_assay.py 均此法)。

**发版配方增量**(承 [[pypi-311-published-20260906]] 五连):token 不落盘不进 keyring/.pypirc,每次发布向用户现取(贴 chat,长度预验:截断=95,正常 ~175-179);twine 走 socks5h://127.0.0.1:10808;上传后三重验证(项目页 200/simple index/JSON API)+**本地 wheel sha256 与 PyPI simple 对照逐位一致**(本次 ecdb2b21)。

**Why**: 判分机构产品面 pip 可用=M1 直通车供给侧;布局坑不记必三踩。
**How to apply**: 动 nautilus_compass 包结构前先看 pyproject package-dir;发版走五连清单+token 现取。
