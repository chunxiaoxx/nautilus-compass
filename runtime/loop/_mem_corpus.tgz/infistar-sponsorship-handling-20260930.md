---
name: infistar-sponsorship-handling-20260930
description: "首封商务赞助来函(Infistar·API网关)处置定案——用户拍板开放对接,四条款框架+30天计量预注册,反客为主=赞助方转被测方"
metadata: 
  node_type: memory
  type: project
  originSessionId: e01698b5-ca0c-4d79-8423-11cb0e107d82
  modified: 2026-09-30T04:00:31.572Z
fact_status: inferred
---

2026-09-30 nautilus-compass 首封商务赞助来函:Infistar(infistar.ai,多模型 API 网关/中转站),README 入口来函,现金赞助+API 额度换展示位与教程共建。

**尽调红旗**:首页同时宣称"100% official channel"+"低至官方价 3%"——自相矛盾(官方渠道撑不起 97% 折扣),主体信息不透明。

**用户拍板**:开放对接(拒绝了我的 A 方案建议——用户是商务负责人,执行其决策但把红旗转成条款)。

**四条款框架**(回函 189b04b4,runtime/letters/reply_infistar_sponsorship_20260930.md):
1. 中性展示位(禁背书表述+注明"不代表推荐"),首期 3 个月
2. API 额度先行 30 天实测,数据是教程事实基础;数据不佳→教程不发+合作终止+如实告知
3. 教程以实测为底+独立性声明
4. 独立性条款书面确认后生效(评测结论与赞助隔离,含不利数据)

**Why**:独立验证实验室的信任资产=立身之本;条款把风险转成条件,且对方最缺的恰是第三方验证(3% 价格宣称最需独立实测)——反客为主,赞助方变 Assay 被测方。

**How to apply**:30 天计量方案已预注册(docs/metering/INFISTAR_GATEWAY_METERING_PLAN_20260930.md,J1-J7 冻结;J3 身份指纹矛盾=FAIL 且保留公开权);runner tools/infistar_meter.py 骨架+dryrun 过。启动三条件:对方给 base_url+key(env 不落盘)+模型清单+计费文档,24h 内首轮。判据只许更严;收工非实现者复算。若 J3 FAIL(偷换模型),Assay 保留公开权——用户安全优先于合作协议。

**回函已发 9/30 12:0x**:对方实际在 Gmail 等(非平台信箱)——outreach@infistar.cc,原函 9/28+跟进 9/30 09:02。实质回函 Gmail id 1a0f077c7a1ac625(thread 1a0e587304a2ca83),=四条款+新增价值互换段(30 天实测报告→PASS 可升级"Assay Verified Gateway"认证+复检订阅,即计量方案 §八 L1/L2/L3)。快照 runtime/letters/SENT_gmail_infistar_20260930.md(fab05b57)。坑:9/30 09:03 用户手回那封是**空正文误发**(只带对方引文),信中已声明"以此封为准"。待对方三项:主体信息/报价+额度形态/两条款书面确认→齐备即出协议文本+启动 J1 首轮。

相关:[[verification-commercialization-20260915]] [[license-modified-mit-20260904]]
