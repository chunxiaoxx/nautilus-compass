---
name: sec-incident-a100-pw-20261008
description: A100 root 密码 PUBLIC 仓泄漏 6 天事故闭环(机内 chpasswd 轮换=免控制台路径);push 冻结纪律与解冻判据;凭据入 .cache/a100_env
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 44761907-86fe-49f8-b0ef-fc3ff9c0567b
  modified: 2026-10-07T15:55:30.519Z
fact_status: inferred
---

2026-10-08 凌晨闭环(R312-R315,commit 62db81cb→82e5c932):README 更新途中抓出 **A100 root 密码在 PUBLIC 仓 40 文件泄漏 ~6 天**(自 919d06a9)。

**处置链(全实测)**:当前树脱敏 43 文件(→A100_PW_ENV 占位)→真凭据迁 `~/.claude/.cache/a100_env`(0600)→**机内 `echo root:新密|chpasswd` 轮换**(免控制台!隧道走密钥认证不受影响)→旧密作废=历史泄漏无害化→push 解冻(62 commit 常规推送,非 force)。B(filter-repo 历史清除)后经用户明示批准补做(R316):python -m git_filter_repo 全史替换+force push,远端/cloud 零残留,三层闭环(树脱敏+轮换+史清除)。

**Why**:用户"不要等靠要"——轮换不必等控制台,root 在手机内 chpasswd 即可;"死密无害"判据(js2 先例)让历史清除失去必要性,push 冻结随之解除。

**How to apply**:①发现凭据入仓:先树脱敏→凭据迁 .cache→**优先机内轮换**(比历史重写便宜两个量级)→再评估历史清除;②push 冻结是标准应急动作,解冻判据=泄漏凭据已死;③A100 新凭据在 .cache/a100_env(source 使用),会话内生成不回显不入仓;④泄漏源教训:ops 脚本常量带密码,写脚本时一律 env 化。关联 [[day-log-1007-judge-discipline]]。
