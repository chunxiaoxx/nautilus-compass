---
name: outreach-channels-20260911
description: 推广渠道定案 9/11——awesome 列表选目标先查生命体征(wong2 关门/appcypher 归档)+dev.to 评论 API 已废+GCM token 轮换坑+直邮三封台账
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-11T16:02:48.887Z
fact_status: inferred
---

# 推广渠道 9/11 定案(经验)

**选 awesome 列表先查生命体征,star 数会骗人**:appcypher/awesome-mcp-servers(5.7k★)实际 2026-08-01 已 archive 只读;wong2/awesome-mcp-servers(8k★)PR+Issues 全关(纯手动维护)。fork+分支+entry 全推好才发现门是死的,浪费两轮。提交前必查:`archived`/`has_issues`/`has_discussions`/最近 `pushed_at`。主力=punkpeye #14065(27k★,open 等 merge)。

**Why:** 两列表的 fork 分支/内容/PR 文案全就位后,用户网页点开才发现「所有者已禁用 PR」和「已归档」——API 的 REST 404 无法区分「禁用」和「token 权限」,网页提示才是权威。

**How to apply:**
- GitHub API 写不了第三方 PR 的根因分层:GCM 的 gho_ token 是 GitHub App user-to-server,有 contents write 无 pulls write(GraphQL CreatePullRequest FORBIDDEN/REST 404);自家 repo 实测能到业务层=账号没被 flag。
- `git credential fill` 在 Chrome 重启后会轮换返回空;兜底=`gh auth token`(同一 gho_ 前缀,稳定可用)。
- dev.to `POST /api/comments` 已废(V0/V1 Accept 都 404),写评论唯一路=用户网页贴(草稿给全文)。
- Chrome 136+ 默认 profile 禁 CDP 调试口,浏览器自动化对「用户已登录会话」不可行(独立 data-dir 无登录态);不要为它搞 cookie 解密(app-bound encryption 挡死)。
- compare 链接 head 只能 `owner:branch` 两段式,带 repo 名的三段式=空页无按钮。
- 直邮三封台账:Trajko(9/10 发→礼貌 ack 闭环)/Di Wu+Haitao Li(9/11 发,等回);再触达 Di Wu 间隔≥2 周。

相关:[[hn-submit-pipeline-20260910]] [[devto-operations-20260908]] [[gmail-rest-fallback-recipe-20260910]]
