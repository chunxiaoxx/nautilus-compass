---
name: income-flatline-rootcause-20260824
description: "8/24 compass 深挖 income 斜率下降根因——非渐降而是 8/22 起停摆:8/23 生产端零提交,8/24 新 g2b1 producer(9000010)verdict 无 trajectory 指针→auto-verify runnable=0→external_verified 不翻→铸币门闭"
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-08-24T15:39:31.829Z
---

# income 停摆读数(2026-08-24 · 8/26 用户纠偏后修正)

## ⚠️ 结论修正(8/26 用户澄清)

**income 8/22 起停摆是用户主动停的**——genopt 自产变体族铸币 = B=0 空转的自己印发铸币厂,已被有意关掉。本 memory 原判"producer 断链,球在 V5 修 trajectory 指针"是**误诊**(故意关闸当断链)。教训:探针读数对 ≠ 定性对;**income 指标已废弃,不再作为收敛指标看**。8/24 的 g2b1 verdict 是 V5 新真燃料线(见 `_OUTBOUND_FROM_V5_TO_PLATFORM_20260825_g2b1_qc_full86.md`:86 题四仓一致性自检 71 OK,双门 starter 必败/fix 必过)。

## 原始读数(仍有效,留作基线)

- 日铸币(agent_transactions INCOME/fde_external_verified):8/7-8/21 恒定 7-10 条/日(364-664),族构成恒定 bin_packing_ffd×3 + cache_lru×3 + tsp_tsplib×2 每日节奏。**7d delta 3348→2220 的差主要是滚动窗口边界效应,此前无真下滑。**
- 8/22 verdict 21 条后断崖;8/23 零;8/24 05:00 起新 producer 起写 **g2b1-\*-ark_glm** verdict(producer_agent_id=9000010,evidence_schema=g2b1-exec-run-v1)。
- 8/24 的 g2b1 verdict:部分 overall_pass=true 但 **artifacts 只有 turns/tokens 元数据,无 trajectory 路径指针**。
- auto-verify(genopt-auto-verify.timer 10min 轮,本身健康)每轮打 `unverified=200 runnable=0`:runner 判 runnable 需 artifacts 指向 ~/genopt_live 下存在的 task_dir+trajectory 文件 → 200 条(含旧积压+新 g2b1)全不可运行 → external_verified 恒 false → income 入账门(fde_verdict.py:external_verified False→True 唯一入账)闭死。
- 附:agents 表查不到 9000009/9000010(PK 口径待核,可能注册表字段不同,未深挖)。

## 判定

1. **verify 门是对的**(护栏有牙齿):无完整解指针=不铸币,正是 LOOP_STATE 铁律 5"轨迹必须带完整解+sha256,preview 一律拒"。
2. **球在生产端(V5 turf)**:g2b1 producer(nautilus-v5-runtime)须把 trajectory 落到 verifier 可达路径(~/genopt_live 或等价)并在 artifacts 带指针——即"runner 存完整解"老合约(fake_success_produce)在新 schema 复发。
3. 8/23 全零是 producer 停机日(8/22-23 V5 侧在跑蒸馏 L4a,资源/重启疑似挤掉),未深挖。

## 探针配方(复用)

```
ssh cloud → PGPASSWORD=nautilus2024 psql -h localhost -U nautilus_user -d nautilus_production
日铸币: agent_transactions WHERE type='INCOME' GROUP BY created_at::date
断链定位: fde_verdicts 按 created_at::date 数 total/ext_v/pass
verify 健康: journalctl -u genopt-auto-verify | grep runnable
```

关联 [[convergence-state-snapshot-20260821]] [[v3-launch-closure-20260824]]
