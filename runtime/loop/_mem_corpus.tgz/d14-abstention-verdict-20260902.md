---
name: d14-abstention-verdict-20260902
description: "d14 刀4(abstention gate)定案未过门:误拒答 92/89 题大越界(门≤1/≤2)但 95% 是 d12 本来也错的题·打掉仅 5/2;终局干净口径 web 40.0%/ent 38.4%(d12 重判现役,36.7/40.3 作废);判分口径污染链定谳"
metadata:
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-02T10:35:45.414Z
---

# d14 刀4 定案 + 终局口径(2026-09-02 · commit c671474)

## 终局数字(营销/README 唯一可用)

**web 40.0% / ent 38.4%** = d12 全量重判干净口径(156 题 LLM 重判,judge=low reasoning/16384 tokens/doubao-seed-2-0-pro-260215/ARK coding plan)。旧 36.7/40.3 是 judge 4096 被 reasoning 吃满的污染口径,作废。

## d14 五判据 3 PASS/2 FAIL → 刀4 未过门

误拒答(non-abst 题 boxed=拒答且判 0):web 92/ent 89 题(门 ≤1/≤2)。**但归因反转**:这批题 95%(87/87)d12 本来也错,d12 答对被打掉的仅 web 5/ent 2 题——与判据④分数差精确吻合。刀4 真正的病 = 错题表达方式从"错误作答"塌缩成"拒答"(118 错题中 78%),行为模式不可接受。ent abstention 71.4% vs 门 75% 只差 1 题(judge 噪声级)。格式污染实为 0(初查 11/16 嫌疑样本全是拒答,非格式坏)。

## 探针三陷阱(证伪自己三连)

1. **全文 grep "access" 会命中题目正文话题**(web 题大量涉及访问日志)——136/87 假命中;必须只看 `response_parsed_boxed`。
2. **拒答模板≠误拒答**:abstention 题(该拒答的)出模板且 score=1.0 是正确行为。判据①只数 non-abst 且判 0。
3. **"格式污染"嫌疑样本要先看答案语义**:boxed 是拒答→判 0 正确→归判据①,不是格式污染。

重启 abstention 方向需在 patch 层做 non-abst 分流(快照覆盖率评分),全局放开拒答必翻车——预注册再议。

关联 [[d13-judge-retry-verdict-20260831]] · [[lmev2-three-knives-tuning-20260830]] · [[lmev2-first-full-baseline-20260830]]
