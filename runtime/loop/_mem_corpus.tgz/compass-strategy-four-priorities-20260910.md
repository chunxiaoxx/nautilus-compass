---
name: compass-strategy-four-priorities-20260910
description: 战略四优先级用户拍板(9/10):9/15 三件套合入→batch002 全流程→判据库 v0→paper2 双速异构;协同拼图=flywheel 判数据·compass 判可信;反剧场主尺=首个外部复算请求
metadata: 
  node_type: memory
  type: project
  originSessionId: 803cee4f-6f04-4ee0-92fd-3ce055d70a29
  modified: 2026-09-09T16:52:53.409Z
fact_status: inferred
---

# COMPASS 战略四优先级(2026-09-10 用户拍板)

四优先级(序=执行序),落档 `docs/plans/2026-09-10-compass-strategy-four-priorities.md`:
1. **9/15 记忆门三件套合入**(RSI 环第一闭,材料全齐)→ 2. **batch002 全流程**(flywheel 200 条掌形批次,第一个对外样本)→ 3. **判据库 v0**(flywheel 五族判据+G1 装进 compass,判据必须可执行)→ 4. **paper2 融合双速异构**(盲区定理,G1 报告归档 9/28 后成稿)。

定位句(七算子审计推导):不做第七个记忆产品,做「决定什么是事实」的仲裁层。
协同拼图:**flywheel 判数据(判定器生产端),compass 判「判数据这件事可信」(验证制度端)**——拼图非重叠。
不做:动作门(Aegis 占)/代币化/大爆炸重写。

**Why:** 用户问「COMPASS 怎么发展+如何与 flywheel 协同」,基于七算子审计/第一性原理/flywheel P3 纲领综合作答后,用户明示「我同意你的优先级建议」。

**How to apply:**
- 排期冲突时按此序;新机会先问「对四优先级哪个有贡献」,0 贡献默认不做([[compass-roadmap-20260907]] 圆心一致)。
- 反剧场主尺:每阶段验收不看件数,看首个自家四框之外的复算请求何时出现(候选:Trajko quant 场景/dev.to 判分卫生学人群)。
- 相关:[[memgate-trio-implemented-20260909]] [[verifypack-v02-built-20260909]] [[memory-audit-seven-operators-20260907]]
