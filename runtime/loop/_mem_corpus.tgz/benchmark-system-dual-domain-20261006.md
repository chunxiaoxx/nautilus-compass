---
name: benchmark-system-dual-domain-20261006
description: 用户拍板基准评测体系双域分工——flywheel=具身数据域;compass+agent 框(v5)=agent 域 unipat;体系地图 v1 落档(agent 域五层全 sha 锚)
metadata:
  node_type: memory
  type: project
  originSessionId: 44761907-86fe-49f8-b0ef-fc3ff9c0567b
  modified: 2026-10-06T01:03:01.525Z
fact_status: inferred
---

2026-10-06 上午用户三连令落定的战略拍板:基准评测体系=**组织整体能力**的承载,双域分工——flywheel 对话框=具身数据的基准评测;compass+agent 对话框(v5)=紧紧围绕 agent 领域 unipat 做基准评测体系;**"我们已经做了大量的工作"**(体系叙事必须收编已有资产,不从零讲起)。

**Why:** 起因是 rsi-bench Issue #4(信号衰减/effective-gain gate 提案)发出后用户升级指令:外挂他人基准只算引流,自有基准体系才是产品;且与 PMF 主线第一件事(自建基准集)合流。

**How to apply:** 正本 docs/benchmarks/BENCHMARK_SYSTEM_MAP_V1_20261006.md(agent 域五层:L0 判据协议底座/L1 题集/L2 判分器/L3 榜单/L4 认证商业——全部已有工作 sha 锚入图)+SELF_BENCH_CHARTER_V0(自建基准子件:信号衰减轨+判分器保真轨,种子=E1 金标 898/anchor 1454/L3 全工件/25 题回归集)。两域接缝=同底座(schema v2.1/三态/证据分层)+同榜单纪律+互不代判(flywheel 判数据质量,compass 判可信)。命名待用户拍(signal-decay-bench 查重全净)。后续评测线取件先对照五层地图归位,新资产入图。

相关:[[pmf-mainline-agent-harness-20261005]] [[day-log-20261006-morning-benchmark-system]]
