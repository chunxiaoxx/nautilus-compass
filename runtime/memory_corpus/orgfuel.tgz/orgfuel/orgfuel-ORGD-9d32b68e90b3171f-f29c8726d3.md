---
name: orgfuel-ORGD-9d32b68e90b3171f-f29c8726d3
description: "[## 四 · 硬标准对照(可查实物)] | 硬标准 | 实物坐标 | |---|---| | 八判例全部可复算 | C"
metadata:
  type: reference
  source: org_fuel:docs
  pf_id: ORGD-9d32b68e90b3171f
  corpus: orgfuel-v2
  sm_verdict: unparsed
---

[## 四 · 硬标准对照(可查实物)] | 硬标准 | 实物坐标 |
|---|---|
| 八判例全部可复算 | CASEBOOK_V1 各案"复算"段(A100 正本路径+部署/拉回脚本) |
| verdict 结构校验 | `tools/verdict_schema_v2.py`(v2.1 含 gap_report 可选校验) |
| 证据分层纪律 | `docs/metering/JUDGING_EVIDENCE_TIERS_20261003.md` |
| 判据白名单门源码 | `tools/p3_delta.py`(label_origin 四类白名单) |
| 判例集 | `docs/cases/CASEBOOK_V1.md`(v1,8 案,公开 demo 版) |
| 判读管线实例 | E1·J2 席位双包交卷(OOD 400+主包 498,六轮迭代全档在仓) |
