---
name: orgfuel-ORGD-c5f0c02a9ce6616c-bfdf18f7e6
description: "[## 8. 判绩账(回填段)] - **2026-10-05 非实现者复算:PASS-with-erratum**(独"
metadata:
  type: reference
  source: org_fuel:docs
  pf_id: ORGD-c5f0c02a9ce6616c
  corpus: orgfuel-v2
  sm_verdict: unparsed
---

[## 8. 判绩账(回填段)] - **2026-10-05 非实现者复算:PASS-with-erratum**(独立上下文复算人,md5 校验后原始 JSONL 本地重算;G=7170892d…/B=599c76a6…):
- 16 项对表 15 项逐位一致(两臂 J1 0.85/0.825、J2 0.925/0.925、ΔJ1=+0.0250/ΔJ2=0.0000、degenerate 0/0、ep 分布、act_state_norm 双臂配对同值 0.072213~0.112599);
- **勘误一项 [实测]**:G 臂 ratio 中位数判读函声称 1.9863,复算=**1.9861**(40 帧偶数,中位=第 20/21 位 1.9859/1.9863 均值;原始 G summary 实物亦为 1.9861)。成因 [推断]:判读函 G 臂误取上中位(median_high),而同函 B 臂(1.7857)用的是均值中位——**两臂口径不一致**,本报告统一口径为偶数均值中位;差 0.0002,不改变任何方向性结论(G>B 胜负关系任何约定下不变);
- 勘误追补不改史:原判读函底稿(runtime/loop/_r57_mail_g1_differential.md)保持原样,以此账为准;
- 复算人原始材料留档:C:\Users\chunx\AppData\Local\Temp\indep_recompute_g1\(material_G/B.jsonl)。
