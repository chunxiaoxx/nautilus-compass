import{j as t}from"./vendor-query-DpQlrvK0.js";import{N as e}from"./vendor-react-CWDEq2w3.js";const a=()=>t.jsx(e,{to:"/login",replace:!0});export{a as default};
//# sourceMappingURL=AgentRegisterPageV2-DIaS7ubv.js.map
