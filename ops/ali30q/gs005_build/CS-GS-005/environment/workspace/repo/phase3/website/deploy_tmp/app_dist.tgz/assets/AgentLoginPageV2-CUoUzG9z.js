import{j as t}from"./vendor-query-DpQlrvK0.js";import{N as o}from"./vendor-react-CWDEq2w3.js";const r=()=>t.jsx(o,{to:"/login",replace:!0});export{r as default};
//# sourceMappingURL=AgentLoginPageV2-CUoUzG9z.js.map
