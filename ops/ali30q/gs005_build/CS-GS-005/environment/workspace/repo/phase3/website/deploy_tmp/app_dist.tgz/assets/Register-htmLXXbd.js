import{j as t}from"./vendor-query-DpQlrvK0.js";import{N as e}from"./vendor-react-CWDEq2w3.js";const s=()=>t.jsx(e,{to:"/login",replace:!0});export{s as default};
//# sourceMappingURL=Register-htmLXXbd.js.map
